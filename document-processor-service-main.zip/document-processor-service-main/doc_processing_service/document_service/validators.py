import re
from rest_framework.exceptions import ValidationError


def validate_regex_patterns(value):
    """
    Validate that each pattern in the regex_patterns list is a valid regex.
    """
    for pattern in value:
        try:
            re.compile(pattern)
        except re.error:
            raise ValidationError(f"Invalid regex pattern: {pattern}")
    return value



def validate_file_extension(value):
    """
    Validate that each extension in the allowed_extensions list is a valid file extension.
    """
    for extension in value:
        if not extension.startswith('.'):
            raise ValidationError(f"Invalid file extension: {extension}")
    return value