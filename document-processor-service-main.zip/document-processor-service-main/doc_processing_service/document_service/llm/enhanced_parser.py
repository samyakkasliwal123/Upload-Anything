import json
import logging
import base64
import asyncio
from typing import Optional
from openai import AsyncOpenAI
from configuration import Config
from doc_processing_service.services.openai_client_singleton import OpenAIClientSingleton


class EnhancedLLMDataParserClassifier:
    """Enhanced LLM parser that can handle different file types directly - ASYNC OPTIMIZED"""
    
    def __init__(self, model_choice, model_temp, schema, base_prompt):
        self.model = model_choice
        self.temperature = model_temp
        # Use singleton client instead of creating new instance
        self.client = None  # Will be initialized lazily
        self.base_prompt = base_prompt
        self.schema = schema
    
    async def _get_client(self) -> AsyncOpenAI:
        """Get the singleton OpenAI client."""
        if self.client is None:
            self.client = await OpenAIClientSingleton.get_client()
        return self.client

    async def return_schema_from_file(self, file_bytes: bytes, file_extension: str, password: Optional[str] = None):
        """Process different file types directly with LLM"""
        
        if file_extension.lower() in ['.pdf']:
            return await self._process_pdf(file_bytes, password)
        elif file_extension.lower() in ['.jpg', '.jpeg', '.png', '.bmp']:
            return await self._process_image(file_bytes)
        elif file_extension.lower() in ['.xls', '.xlsx', '.csv']:
            return await self._process_excel(file_bytes, password, file_extension)
        elif file_extension.lower() in ['.json']:
            return await self._process_json(file_bytes, password)
        elif file_extension.lower() in ['.txt']:
            return await self._process_text(file_bytes)
        else:
            # Fallback: try to process as text
            return await self._process_text(file_bytes)

    async def _process_pdf(self, file_bytes: bytes, password: Optional[str] = None):
        """Process PDF files by first extracting text content"""
        # Use existing PDF processor to extract text, then send to LLM
        from document_service.processor import PDFProcessor
        
        # Get text content from PDF
        text_content = await PDFProcessor().process(file_bytes, password, '.pdf')
        
        return await self._process_text_content(text_content)

    async def _process_image(self, file_bytes: bytes):
        """Process image files with vision-capable LLM - async"""
        # Determine image format
        image_format = "jpeg"  # default
        if file_bytes.startswith(b'\x89PNG'):
            image_format = "png"
        elif file_bytes.startswith(b'BM'):
            image_format = "bmp"
        
        messages = [
            {
                "role": "system",
                "content": self.base_prompt
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Please analyze this image document and extract the required information:"
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/{image_format};base64,{base64.b64encode(file_bytes).decode()}"
                        }
                    }
                ]
            }
        ]
        
        return await self._make_llm_call(messages)

    async def _process_excel(self, file_bytes: bytes, password: Optional[str] = None, file_extension: str = '.xlsx'):
        """Process Excel files by first extracting text content"""
        # Use existing Excel processor to extract text, then send to LLM
        from document_service.processor import ExcelProcessor
        
        # Get text content from Excel
        text_content = await ExcelProcessor().process(file_bytes, password, file_extension)
        
        return await self._process_text_content(text_content)

    async def _process_json(self, file_bytes: bytes, password: Optional[str] = None):
        """Process JSON files by first extracting content"""
        from document_service.processor import JSONProcessor
        
        # Get text content from JSON
        text_content = await JSONProcessor().process(file_bytes, password, '.json')
        
        return await self._process_text_content(text_content)

    async def _process_text(self, file_bytes: bytes):
        """Process text files - async"""
        try:
            text_content = file_bytes.decode('utf-8')
            return await self._process_text_content(text_content)
        except UnicodeDecodeError:
            # Try other encodings
            for encoding in ['latin-1', 'cp1252', 'iso-8859-1']:
                try:
                    text_content = file_bytes.decode(encoding)
                    return await self._process_text_content(text_content)
                except UnicodeDecodeError:
                    continue
            
            # If all fail, use error handling
            text_content = file_bytes.decode('utf-8', errors='replace')
            return await self._process_text_content(text_content)

    async def _process_text_content(self, text_content: str):
        """Process extracted text content with LLM - async"""
        messages = [
            {
                "role": "system",
                "content": self.base_prompt
            },
            {
                "role": "user",
                "content": f"Document content:\n{text_content}\n\nPlease analyze this document and extract the required information."
            }
        ]
        
        return await self._make_llm_call(messages)

    async def _make_llm_call(self, messages):
        """Make the actual LLM API call with structured output and optimizations - FULLY ASYNC"""
        client = await self._get_client()
        try:
            # Try structured outputs first with optimized parameters
            response = await client.beta.chat.completions.parse(
                model=self.model,
                messages=messages,
                response_format=self.schema,
                temperature=self.temperature
            )
            return response.choices[0].message.parsed
        except Exception as e:
            # Fallback to regular completion
            logging.warning(f"Structured outputs failed, falling back to regular completion: {e}")
            
            response = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature
            )
            
            # Try to parse the response as JSON
            try:
                parsed_json = json.loads(response.choices[0].message.content)
                return self.schema(**parsed_json)
            except Exception as parse_error:
                logging.error(f"Failed to parse response as JSON: {parse_error}")
                raise parse_error