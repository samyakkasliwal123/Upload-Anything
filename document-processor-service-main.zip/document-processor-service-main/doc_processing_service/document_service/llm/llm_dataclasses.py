from pydantic import BaseModel, Field
from typing import List, Literal, Union
from enum import Enum
from datetime import datetime

from document_service.text_choices import DocumentCategory, DocumentSubCategory


class TaxDocumentClassification(BaseModel):
    """Contains the tax document type and reason for classification"""
    reasonForClassification: str
    docType: DocumentCategory
    docTypeSub: DocumentSubCategory


# TODO: Implement these schema classes when requirements are defined
class SchemaForm16(BaseModel):
    """Placeholder for Form 16 schema - to be implemented"""
    pass

class SchemaForm26AS(BaseModel):
    """Placeholder for Form 26AS schema - to be implemented"""
    pass

class SchemaAnnualIncomeStatement(BaseModel):
    """Placeholder for Annual Income Statement schema - to be implemented"""
    pass

class SchemaHomeLoanInterestCertificate(BaseModel):
    """Placeholder for Home Loan Interest Certificate schema - to be implemented"""
    pass

class SchemaNPS(BaseModel):
    """Placeholder for NPS schema - to be implemented"""
    pass


class SimpleAddress(BaseModel):
    TownCityDistrict: Union[str, None] = Field(description="The town, city, or district of the address")
    FullAddress: Union[str, None] = Field(description="The full address of the location")
    StateInIndia: Union[Literal[
        "DELHI", "ANDAMANANDNICOBARISLANDS", "ANDHRAPRADESH", "ARUNACHALPRADESH", "ASSAM", "BIHAR",
        "CHANDIGARH", "CHHATISHGARH", "DADRANAGARHAVELI", "DAMANDIU", "GOA", "GUJARAT", "HARYANA",
        "HIMACHALPRADESH", "JAMMUKASHMIR", "JHARKHAND", "KARNATAKA", "KERALA", "LADAKH", "LAKHSWADEEP",
        "MADHYAPRADESH", "MAHARASHTRA", "MANIPUR", "MEGHALAYA", "MIZORAM", "NAGALAND", "ORISSA",
        "PONDICHERRY", "PUNJAB", "RAJASTHAN", "SIKKIM", "TAMILNADU", "TELANGANA", "TRIPURA",
        "UTTARANCHAL", "UTTARPRADESH", "WESTBENGAL", "StateoutsideIndia"
    ], None] = Field(description="The state in India - use exact enum values like UTTARPRADESH, KARNATAKA, MAHARASHTRA, etc.")
    Country: Union[Literal[
        "India", "USA", "Canada", "Australia", "UK", "Germany", "France", "Japan", "China"
    ], None] = Field(description="The country of the address")
    PinCode: Union[str, None] = Field(description="The postal code or zip code of the address")

class Address(BaseModel):
    TownCityDistrict: str = Field(description="The town, city, or district of the address (e.g., NOIDA, MUMBAI, BANGALORE). Intelligently extract from available address information.")
    FlatDoorBlockNumber: str = Field(description="The flat, door, or unit number (e.g., FLAT-901, DOOR-123). If not explicitly mentioned, use building number or first part of address.")
    PremiseBuildingVillageName: str = Field(description="The building, premise, or complex name (e.g., SUPERTECH CAPETOWN CAPE GOLD). If not available, use street name or area name.")
    RoadStreetPostOffice: str = Field(description="The road, street name, or post office (e.g., MG ROAD, MAIN STREET). If not available, use locality or area information.")
    AreaLocality: str = Field(description="The area, locality, or sector (e.g., SECTOR-74, KORAMANGALA, BANDRA). If not available, use district or broader area information.")
    StateInIndia: Literal[
        "DELHI", "ANDAMANANDNICOBARISLANDS", "ANDHRAPRADESH", "ARUNACHALPRADESH", "ASSAM", "BIHAR",
        "CHANDIGARH", "CHHATISHGARH", "DADRANAGARHAVELI", "DAMANDIU", "GOA", "GUJARAT", "HARYANA",
        "HIMACHALPRADESH", "JAMMUKASHMIR", "JHARKHAND", "KARNATAKA", "KERALA", "LADAKH", "LAKHSWADEEP",
        "MADHYAPRADESH", "MAHARASHTRA", "MANIPUR", "MEGHALAYA", "MIZORAM", "NAGALAND", "ORISSA",
        "PONDICHERRY", "PUNJAB", "RAJASTHAN", "SIKKIM", "TAMILNADU", "TELANGANA", "TRIPURA",
        "UTTARANCHAL", "UTTARPRADESH", "WESTBENGAL", "StateoutsideIndia"
    ] = Field(description="The state in India - use exact enum values like UTTARPRADESH for Uttar Pradesh, KARNATAKA for Karnataka, MAHARASHTRA for Maharashtra, etc.")
    Country: Literal[
        "India", "USA", "Canada", "Australia", "UK", "Germany", "France", "Japan", "China"
    ] = Field(description="The country of the address. Default to 'India' for Indian addresses.")
    PinCodeOrZipCode: str = Field(description="The postal code or zip code of the address. Extract from available information or use a reasonable default for the area.")


class HouseOccupancy(str, Enum):
    """Enum for house occupancy type"""
    SELF_OCCUPIED = "SelfOccupied"
    LET_OUT = "LetOut"
    DEEMED_LET_OUT = "DeemedLetOut"


class InvestmentTypeEnum(str, Enum):
    """Enum for investment types under 80C"""
    NOT_INITIALIZED = "NotInitialized"
    LIC_PREMIUM = "LICPremium"
    PUBLIC_PROVIDENT_FUND = "PublicProvidentFund"
    EMPLOYEE_PROVIDENT_FUND = "EmployeeProvidentFund"
    FIXED_DEPOSITS = "FixedDeposits"
    ELSS_MUTUAL_FUNDS = "ELSSMutualFunds"
    TUITION_FEES = "TutionFees"
    PRINCIPAL_ON_HOME_LOAN = "PrincipalOnHomeLoan"
    ULIP_PREMIUM = "ULIPCertificate"
    NATIONAL_SAVINGS_CERTIFICATE = "NSCCertificate"
    SUKANYA_SAMRIDHI_YOJANA = "SukanyaSamridhi"
    OTHERS = "Others"


class SchemaHomeLoanInterest(BaseModel):
    """Schema for Home Loan Interest Certificate data extraction - House Property"""
    LoanAccountNumber: Union[str, None] = Field(default=None, description="The loan account number")
    BorrowerName: Union[str, None] = Field(default=None, description="Name of the primary borrower (first person mentioned in the certificate)")
    BorrowerPan: Union[str, None] = Field(default=None, description="PAN number of the primary borrower")
    BankName: Union[str, None] = Field(default=None, description="Name of the lending bank/institution")
    HouseAddress: Union[Address, None] = Field(default=None, description="Address of the house property")
    FinancialYearOfConstructionCompletion: Union[int, None] = Field(default=None, description="Financial year when construction was completed")
    LoanTakenFrom: Union[Literal["B", "I"], None] = Field(default=None, description="Source of the loan - determine if loan is from a Bank or Institution. Output 'B' if the loan is from a scheduled commercial bank (names ending with 'Bank' like HDFC Bank, ICICI Bank, SBI, Canara Bank, Axis Bank, etc.), output 'I' if the loan is from housing finance companies, NBFCs, or other non-banking financial institutions (like HDFC Ltd, LIC Housing Finance, etc.)")
    DateOfSanction: Union[str, None] = Field(default=None, description="Date when the loan was sanctioned. This is not the date of statement generation, but the date when the loan was approved or sanctioned by the bank or institution. The date should be in the format YYYY-MM-DD, for example, 2023-04-01. if day is not available then it should be the first date of the month, for example, if the loan was sanctioned in April 2023, then the date should be 2023-04-01. If the month is not available then it should be the first month of the financial year, for example, if the loan was sanctioned in FY 2023-24 but the month is not available then the date should be 2023-04-01")
    LoanAmount: Union[float, None] = Field(default=None, description="Original loan amount sanctioned")
    LoanOutstanding: Union[float, None] = Field(default=None, description="Outstanding loan amount as on FY end")
    InterestPaidPreConstruction: Union[float, None] = Field(default=None, description="Interest paid during pre-construction period")
    InterestPaidPostConstruction: Union[float, None] = Field(default=None, description="Interest paid post construction")
    PrincipalPrepayment: Union[float, None] = Field(default=None, description="Principal prepayment amount made during the financial year")
    PrincipalAmount: Union[float, None] = Field(default=None, description="Total principal amount paid during the financial year (should include both regular principal component and principal prepayment)")
    FinancialYear: Union[int, None] = Field(default=None, description="Financial year for which the certificate is issued. If Assessment Year is present then it should be the financial year for which the assessment is done. For example, if the assessment year is 2023-24, then the financial year will be 2023")
    PropertyType: Union[HouseOccupancy, None] = Field(default=HouseOccupancy.SELF_OCCUPIED, description="Type of property occupancy - SelfOccupied, LetOut, or DeemedLetOut")


class SchemaEducationLoanInterest(BaseModel):
    """Schema for Education Loan Interest Certificate data extraction - Section 80E"""
    LoanAccountNumber: Union[str, None] = Field(default=None, description="The education loan account number")
    BorrowerName: Union[str, None] = Field(default=None, description="Name of the primary borrower (student or parent)")
    BorrowerPan: Union[str, None] = Field(default=None, description="PAN number of the primary borrower")
    BankName: Union[str, None] = Field(default=None, description="Name of the lending bank/institution")
    InstitutionName: Union[str, None] = Field(default=None, description="Name of the educational institution")
    LoanTakenFrom: Union[Literal["B", "I"], None] = Field(default=None, description="Source of the loan - determine if loan is from a Bank or Institution. Output 'B' if the loan is from a scheduled commercial bank (names ending with 'Bank' like HDFC Bank, ICICI Bank, SBI, Canara Bank, Axis Bank, etc.), output 'I' if the loan is from housing finance companies, NBFCs, or other non-banking financial institutions")
    DateOfSanction: Union[str, None] = Field(default=None, description="Date when the education loan was sanctioned. The date should be in the format YYYY-MM-DD, for example, 2023-04-01. if day is not available then it should be the first date of the month, for example, if the loan was sanctioned in April 2023, then the date should be 2023-04-01. If the month is not available then it should be the first month of the financial year, for example, if the loan was sanctioned in FY 2023-24 but the month is not available then the date should be 2023-04-01")
    LoanAmount: Union[float, None] = Field(default=None, description="Original education loan amount sanctioned")
    LoanOutstanding: Union[float, None] = Field(default=None, description="Outstanding loan amount as on FY end")
    InterestUnderSection80E: Union[float, None] = Field(default=None, description="Interest paid on education loan eligible for Section 80E deduction")
    FinancialYear: Union[int, None] = Field(default=None, description="Financial year for which the certificate is issued. If Assessment Year is present then it should be the financial year for which the assessment is done. For example, if the assessment year is 2023-24, then the financial year will be 2023")


class SchemaMedicalInsurance(BaseModel):
    """Schema for Medical Insurance Policy/Health Card data extraction - Section 80D"""
    InsurerName: Union[str, None] = Field(default=None, description="Name of the insurance company/insurer")
    PolicyNumber: Union[str, None] = Field(default=None, description="Medical insurance policy number or health card number")
    HealthInsuranceAmount: Union[float, None] = Field(default=None, description="Health insurance premium amount paid eligible for Section 80D deduction")
    PolicyHolderName: Union[str, None] = Field(default=None, description="Name of the policy holder")
    PolicyHolderPAN: Union[str, None] = Field(default=None, description="PAN number of the policy holder")
    FinancialYear: Union[int, None] = Field(default=None, description="Financial year for which the premium is paid")
    PolicyType: Union[str, None] = Field(default=None, description="Type of medical insurance policy (Individual, Family, Senior Citizen, etc.)")
    
    # Section 80D specific flags for deduction calculation
    IsPolicyForSelf: Union[bool, None] = Field(default=None, description="True if the policy covers the taxpayer (self) or spouse, False if it covers parents/dependent parents")
    IsPolicyForParents: Union[bool, None] = Field(default=None, description="True if the policy covers parents or dependent parents, False if it covers self/spouse")
    IsSelfOrSpouseSeniorCitizen: Union[bool, None] = Field(default=None, description="True if the taxpayer (self) or spouse is 60 years or above (senior citizen), False otherwise")
    AreParentsSeniorCitizen: Union[bool, None] = Field(default=None, description="True if parents are 60 years or above (senior citizen), False otherwise")
    
    # Additional beneficiary information
    CoveredMembers: Union[str, None] = Field(default=None, description="List or description of family members covered under the policy (e.g., 'Self, Spouse, 2 Children' or 'Father, Mother')")
    RelationshipToPolicyHolder: Union[str, None] = Field(default=None, description="Relationship of covered members to the policy holder (e.g., 'Self', 'Parents', 'Family', 'Spouse')")


class SchemaNPS(BaseModel):
    """Schema for National Pension System (NPS) Documents - Section 80CCD"""
    PRAN: Union[str, None] = Field(default=None, description="Permanent Retirement Account Number (PRAN)")
    SubscriberName: Union[str, None] = Field(default=None, description="Name of the NPS subscriber")
    SubscriberPAN: Union[str, None] = Field(default=None, description="PAN number of the subscriber")
    EmployeeContribution80CCD1: Union[float, None] = Field(default=None, description="Employee contribution under Section 80CCD(1) - up to 10% of salary or Rs. 1.5 lakh")
    EmployerContribution80CCD2: Union[float, None] = Field(default=None, description="Employer contribution under Section 80CCD(2) - up to 14% of salary for government employees or 10% for others")
    AdditionalContribution80CCD1B: Union[float, None] = Field(default=None, description="Additional voluntary contribution under Section 80CCD(1B) - up to Rs. 50,000")
    TotalNPSContribution: Union[float, None] = Field(default=None, description="Total NPS contribution amount during the financial year")
    EmployerName: Union[str, None] = Field(default=None, description="Name of the employer (for corporate NPS)")
    FinancialYear: Union[int, None] = Field(default=None, description="Financial year for which the contribution is made")
    StatementPeriod: Union[str, None] = Field(default=None, description="Statement period or contribution period")


class SchemaDeductionUsSec80G(BaseModel):
    DoneeName: Union[str, None] = Field(description="The name of the person or organization receiving the donation")
    DonationAmountCash: Union[float, None] = Field(description="The donation amount made in cash")
    DonationAmountNonCash: Union[float, None] = Field(description="The donation amount made in online or non-cash forms")
    DoneePan: Union[str, None] = Field(description="The PAN number of the person or organization receiving the donation")
    # DeductionLimit: Union[Literal[
    #     "NoLimit", "SubjectToIncome"
    # ], None] = Field(description="The limit on deduction for the donation")
    # QualifyingPercentage: Union[Literal[
    #     "50", "100"
    # ], None] = Field(description="The qualifying percentage for the donation")
    DoneeAddress: Union[SimpleAddress, None] = Field(description="The address of the person or organization receiving the donation")
    UserPan: Union[str, None] = Field(description="The PAN number of the user making the donation")
    FinancialYear: Union[str, None] = Field(description="The financial year in which the donation was made, for instance if the donation was made on or before 31st March 2023, the financial year will be 2023, if the donation was made on or after 1st April 2023, the financial year will be 2024")


# Enhanced Schema80CInvestment for all Section 80C document types
class Schema80CInvestment(BaseModel):
    """Schema for all Section 80C Investments and Deductions"""
    InvestmentType: Union[InvestmentTypeEnum, None] = Field(default=InvestmentTypeEnum.OTHERS, description="Type of Section 80C investment")
    DocumentNumber: Union[str, None] = Field(default=None, description="Document number (Policy number, Account number, Folio number, Certificate number, etc.)")
    Amount: Union[float, None] = Field(default=None, description="Investment/Premium/Contribution amount eligible for Section 80C deduction")
    FinancialYear: Union[int, None] = Field(default=None, description="Financial year for which the investment is claimed")
    IsEligibleFor80C: Union[bool, None] = Field(default=True, description="Whether the investment is eligible for Section 80C deduction")

    class Config:
        use_enum_values = False

class SchemaDeductions(BaseModel):
    DeductionsUsSec80G: Union[List[SchemaDeductionUsSec80G], None] = Field(default=None, description="List of deductions under section 80G")
    DeductionsUsSec80C: Union[List[Schema80CInvestment], None] = Field(default=None, description="List of deductions under section 80C including home loan principal")
    DeductionsUsSec24B: Union[List[SchemaHomeLoanInterest], None] = Field(default=None, description="Home loan interest information")
    DeductionsUsSec80E: Union[List[SchemaEducationLoanInterest], None] = Field(default=None, description="Education loan interest information under section 80E")
    DeductionsUsSec80D: Union[List[SchemaMedicalInsurance], None] = Field(default=None, description="Medical insurance premium information under section 80D")
    NPS: Union[List[SchemaNPS], None] = Field(default=None, description="NPS contributions under section 80CCD")


class SchemaBasicAmountHead(BaseModel):
    amount: Union[float, None] = Field(description="Amount")
    name: Union[str, None] = Field(description="Description of the amount")
    date: Union[str, None] = Field(description="Date of the transaction. If the date is not available, but the period is available, then the date should be in the format YYYY-MM-DD, for example, if the period is 1st April 2023 to 31st March 2024, then the date should be the first date in the financial year, 2023-04-01")

class SchemaOtherIncome(BaseModel):
    SavingsBankInterestIncome: Union[List[SchemaBasicAmountHead], None] = Field(default=None, description="List of savings bank interest income")

class SchemaCommonModel(BaseModel):
    Deductions: Union[SchemaDeductions, None] = Field(default=None, description="Deductions information")
    OtherIncome: Union[SchemaOtherIncome, None] = Field(default=None, description="Other income information")


class UnifiedClassificationAndDataSchema(BaseModel):
    """
    Unified schema that combines document classification with SchemaCommonModel.
    This allows a single LLM call to both classify the document and extract all relevant data.
    """
    # Classification fields (always required)
    reasonForClassification: str = Field(description="Reason for classifying the document into the chosen category")
    docType: DocumentCategory = Field(description="The main document category")
    docTypeSub: DocumentSubCategory = Field(default=DocumentSubCategory.NOT_INITIALIZED, description="The document subcategory if applicable")
    
    # Data extraction using existing common model structure
    extractedData: Union[SchemaCommonModel, None] = Field(default=None, description="Extracted document data in common model format")
