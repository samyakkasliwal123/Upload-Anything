import json
from typing import Any
from document_service.text_choices import DocumentCategory, Product
from .llm_dataclasses import (SchemaAnnualIncomeStatement, SchemaBasicAmountHead, SchemaCommonModel,
                              SchemaDeductionUsSec80G, SchemaDeductions, SchemaNPS, SchemaForm16, SchemaForm26AS,
                              SchemaHomeLoanInterest, SchemaEducationLoanInterest, SchemaMedicalInsurance, Schema80CInvestment, SchemaOtherIncome, InvestmentTypeEnum)

ITR_DOCUMENT_TYPE_MAPPER = {
    DocumentCategory.DOC_80_G: SchemaDeductionUsSec80G,
    DocumentCategory.SAVINGS_BANK_INTEREST: SchemaBasicAmountHead,
    DocumentCategory.DOC_HOME_LOAN_INTEREST_CERTIFICATE: SchemaHomeLoanInterest,
    DocumentCategory.DOC_EDUCATION_LOAN_INTEREST_CERTIFICATE: SchemaEducationLoanInterest,
    DocumentCategory.DOC_MEDICAL_INSURANCE_POLICY: SchemaMedicalInsurance,
    DocumentCategory.DOC_FORM_16: SchemaForm16,
    DocumentCategory.DOC_FORM_26_AS: SchemaForm26AS,
    DocumentCategory.DOC_ANNUAL_INFORMATION_STATEMENT: SchemaAnnualIncomeStatement,
    # Section 80C Document Types
    DocumentCategory.DOC_LIFE_INSURANCE_PREMIUM: Schema80CInvestment,
    DocumentCategory.DOC_ELSS_MUTUAL_FUND: Schema80CInvestment,
    DocumentCategory.DOC_PPF_STATEMENT: Schema80CInvestment,
    DocumentCategory.DOC_ULIP_CERTIFICATE: Schema80CInvestment,
    DocumentCategory.DOC_EPF_STATEMENT: Schema80CInvestment,
    DocumentCategory.DOC_NSC_CERTIFICATE: Schema80CInvestment,
    DocumentCategory.DOC_SUKANYA_SAMRIDHI: Schema80CInvestment,
    DocumentCategory.DOC_NPS_STATEMENT: SchemaNPS,
}

PRODUCT_DATACLASS_MAPPER = {
    Product.ITR: ITR_DOCUMENT_TYPE_MAPPER
}


def get_llm_dataclass(product: Product, document_type: DocumentCategory):
    product_dataclasses = PRODUCT_DATACLASS_MAPPER.get(product)
    return product_dataclasses.get(document_type)


def _create_80g_deduction(data: dict) -> SchemaCommonModel:
    """Create common model for 80G deduction"""
    deduction = SchemaDeductionUsSec80G(**data)
    return SchemaCommonModel(Deductions=SchemaDeductions(DeductionsUsSec80G=[deduction]))


def _create_savings_bank_interest(data: dict) -> SchemaCommonModel:
    """Create common model for savings bank interest"""
    savings_bank_interest = SchemaBasicAmountHead(**data)
    return SchemaCommonModel(OtherIncome=SchemaOtherIncome(SavingsBankInterestIncome=[savings_bank_interest]))


def _extract_interest_amount(data: dict) -> float:
    """Extract interest amount with fallback logic"""
    return (data.get('Section24bDeduction') or
            data.get('InterestPaidPostConstruction') or
            data.get('InterestComponent') or
            data.get('InterestPayable'))


def _extract_principal_amount(data: dict) -> float:
    """Extract principal amount with fallback logic, including prepayment"""
    principal_component = data.get('PrincipalAmount', 0) or data.get('PrincipalComponent', 0)
    principal_prepayment = data.get('PrincipalPrepayment', 0)
    
    # If PrincipalAmount is already calculated by LLM (includes prepayment), use it
    if data.get('PrincipalAmount'):
        return data.get('PrincipalAmount')
    
    # Otherwise, calculate total principal (component + prepayment)
    return (principal_component or 0) + (principal_prepayment or 0)


def _create_home_loan_deduction(data: dict) -> SchemaHomeLoanInterest:
    """Create home loan interest deduction from certificate data"""
    return SchemaHomeLoanInterest(
        LoanAccountNumber=data.get('LoanAccountNumber'),
        BorrowerName=data.get('BorrowerName'),
        BorrowerPan=data.get('BorrowerPan'),
        BankName=data.get('BankName'),
        HouseAddress=data.get('HouseAddress') or data.get('PropertyAddress'),
        FinancialYearOfConstructionCompletion=data.get('FinancialYearOfConstructionCompletion'),
        LoanTakenFrom=data.get('LoanTakenFrom'),
        DateOfSanction=data.get('DateOfSanction'),
        LoanAmount=data.get('LoanAmount'),
        LoanOutstanding=data.get('LoanOutstanding'),
        InterestPaidPreConstruction=data.get('InterestPaidDuringPreConstruction'),
        InterestPaidPostConstruction=_extract_interest_amount(data),
        PrincipalPrepayment=data.get('PrincipalPrepayment'),
        PrincipalAmount=_extract_principal_amount(data),
        FinancialYear=data.get('FinancialYear'),
    )


def _create_80c_investment(data: dict) -> Schema80CInvestment:
    """Create 80C investment from certificate data"""
    return Schema80CInvestment(
        InvestmentType=InvestmentTypeEnum.PRINCIPAL_ON_HOME_LOAN,
        DocumentNumber=data.get('LoanAccountNumber'),
        Amount=_extract_principal_amount(data),
        FinancialYear=data.get('FinancialYear'),
    )


def _create_home_loan_common_model(data: dict) -> SchemaCommonModel:
    """Create common model for home loan certificate"""
    home_loan_deduction = [_create_home_loan_deduction(data)]

    # Create 80C investment if principal amount exists
    investments_80c = []
    principal_amount = _extract_principal_amount(data)
    if principal_amount:
        investments_80c.append(_create_80c_investment(data))
    
    return SchemaCommonModel(
        Deductions=SchemaDeductions(
            DeductionsUsSec80C=investments_80c,
            DeductionsUsSec24B=home_loan_deduction
        )
    )


def _create_education_loan_deduction(data: dict) -> SchemaEducationLoanInterest:
    """Create education loan interest deduction from certificate data"""
    return SchemaEducationLoanInterest(
        LoanAccountNumber=data.get('LoanAccountNumber'),
        BorrowerName=data.get('BorrowerName'),
        BorrowerPan=data.get('BorrowerPan'),
        BankName=data.get('BankName'),
        InstitutionName=data.get('InstitutionName'),
        LoanTakenFrom=data.get('LoanTakenFrom'),
        DateOfSanction=data.get('DateOfSanction'),
        LoanAmount=data.get('LoanAmount'),
        LoanOutstanding=data.get('LoanOutstanding'),
        InterestUnderSection80E=data.get('InterestUnderSection80E') or data.get('InterestPaid') or data.get('InterestAmount'),
        FinancialYear=data.get('FinancialYear'),
    )


def _create_education_loan_common_model(data: dict) -> SchemaCommonModel:
    """Create common model for education loan certificate"""
    education_loan_deduction = [_create_education_loan_deduction(data)]
    
    return SchemaCommonModel(
        Deductions=SchemaDeductions(
            DeductionsUsSec80E=education_loan_deduction
        )
    )


def _create_medical_insurance_deduction(data: dict) -> SchemaMedicalInsurance:
    """Create medical insurance deduction from policy/health card data"""
    return SchemaMedicalInsurance(
        InsurerName=data.get('InsurerName'),
        PolicyNumber=data.get('PolicyNumber'),
        HealthInsuranceAmount=data.get('HealthInsuranceAmount') or data.get('PremiumAmount') or data.get('Amount'),
        PolicyHolderName=data.get('PolicyHolderName'),
        PolicyHolderPAN=data.get('PolicyHolderPAN'),
        FinancialYear=data.get('FinancialYear'),
        PolicyType=data.get('PolicyType'),
        # Section 80D specific flags
        IsPolicyForSelf=data.get('IsPolicyForSelf'),
        IsPolicyForParents=data.get('IsPolicyForParents'),
        IsSelfOrSpouseSeniorCitizen=data.get('IsSelfOrSpouseSeniorCitizen'),
        AreParentsSeniorCitizen=data.get('AreParentsSeniorCitizen'),
        CoveredMembers=data.get('CoveredMembers'),
        RelationshipToPolicyHolder=data.get('RelationshipToPolicyHolder'),
    )


def _create_medical_insurance_common_model(data: dict) -> SchemaCommonModel:
    """Create common model for medical insurance policy/health card"""
    medical_insurance_deduction = [_create_medical_insurance_deduction(data)]
    
    return SchemaCommonModel(
        Deductions=SchemaDeductions(
            DeductionsUsSec80D=medical_insurance_deduction
        )
    )


def _create_nps_common_model(data: dict) -> SchemaCommonModel:
    """Create common model for NPS documents"""
    nps_data = SchemaNPS(**data)
    return SchemaCommonModel(Deductions=SchemaDeductions(NPS=[nps_data]))


def _create_80c_investment_common_model(data: dict) -> SchemaCommonModel:
    """Create common model for Section 80C investments"""
    investment = Schema80CInvestment(
        InvestmentType=data.get('InvestmentType', InvestmentTypeEnum.OTHERS),
        DocumentNumber=data.get('DocumentNumber'),
        Amount=data.get('Amount'),
        FinancialYear=data.get('FinancialYear'),
        IsEligibleFor80C=data.get('IsEligibleFor80C', True)
    )
    return SchemaCommonModel(Deductions=SchemaDeductions(DeductionsUsSec80C=[investment]))


# Document type to processor mapping
DOCUMENT_PROCESSORS = {
    DocumentCategory.DOC_80_G: _create_80g_deduction,
    DocumentCategory.SAVINGS_BANK_INTEREST: _create_savings_bank_interest,
    DocumentCategory.DOC_HOME_LOAN_INTEREST_CERTIFICATE: _create_home_loan_common_model,
    DocumentCategory.DOC_EDUCATION_LOAN_INTEREST_CERTIFICATE: _create_education_loan_common_model,
    DocumentCategory.DOC_MEDICAL_INSURANCE_POLICY: _create_medical_insurance_common_model,
    DocumentCategory.DOC_NPS_STATEMENT: _create_nps_common_model,
    # Section 80C Document Processors - all use the same function
    DocumentCategory.DOC_LIFE_INSURANCE_PREMIUM: _create_80c_investment_common_model,
    DocumentCategory.DOC_ELSS_MUTUAL_FUND: _create_80c_investment_common_model,
    DocumentCategory.DOC_PPF_STATEMENT: _create_80c_investment_common_model,
    DocumentCategory.DOC_ULIP_CERTIFICATE: _create_80c_investment_common_model,
    DocumentCategory.DOC_EPF_STATEMENT: _create_80c_investment_common_model,
    DocumentCategory.DOC_NSC_CERTIFICATE: _create_80c_investment_common_model,
    DocumentCategory.DOC_SUKANYA_SAMRIDHI: _create_80c_investment_common_model,
}

def wrap_llm_modeled_data_common_model(extracted_data: Any, document_type: DocumentCategory) -> SchemaCommonModel:
    """
    Transform extracted document data into a common model structure.
    
    Args:
        extracted_data: JSON string of extracted document data
        document_type: Type of document being processed
        
    Returns:
        SchemaCommonModel: Standardized model with deductions and income data
    """
    data = json.loads(extracted_data)
    processor = DOCUMENT_PROCESSORS.get(document_type)
    
    if processor:
        return processor(data)
    
    # Return empty common model for unsupported document types
    return SchemaCommonModel()