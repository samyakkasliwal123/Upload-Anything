from llama_index.core.program import FunctionCallingProgram
from llama_index.core.prompts import ChatPromptTemplate, ChatMessage
from llama_index.llms.openai import OpenAI as llamaOpenAI
from configuration import Config
from openai import OpenAI as OpenAI


class LLMDataParserClassifier:
    def __init__(self, model_choice, model_temp, schema, base_prompt):
        self.llmModel = llamaOpenAI(model=model_choice, api_key=Config.OPENAPI_KEY, temperature=model_temp)
        self.prompt = ChatPromptTemplate(
            message_templates=[
                ChatMessage(
                    role="system",
                    content=(
                        base_prompt
                    ),
                ),
                ChatMessage(
                    role="user",
                    content=(
                        "Document content:\n"
                        "{currentDocumentContent}\n"
                        "OUTPUT:\n"
                    ),
                ),
            ]
        )
        self.program = FunctionCallingProgram.from_defaults(
            llm=self.llmModel,
            output_cls=schema,
            prompt=self.prompt,
            verbose=True
        )

    def return_schema_from_document(self, document_content, **kwargs):
        return self.program(currentDocumentContent=document_content, **kwargs)
    
    # Keep backward compatibility
    def return_schema_from_ocr(self, ocr_output, **kwargs):
        return self.return_schema_from_document(ocr_output, **kwargs)


class OpenAIDataParserClassifier:
    def __init__(self, model_choice, model_temp, schema, base_prompt):
        self.model = model_choice
        self.temperature = model_temp
        self.client = OpenAI(
            api_key=Config.OPENAPI_KEY,
        )
        self.base_prompt = base_prompt
        self.schema = schema

    def return_schema_from_document(self, document_content):
        messages = [
            {
                "role": "system",
                "content": self.base_prompt
            },
            {
                "role": "user",
                "content": f"Document content:\n{document_content}\nOUTPUT:\n"
            }
        ]
        
        # Use the latest structured outputs API with proper schema format
        try:
            response = self.client.beta.chat.completions.parse(
                model=self.model,
                messages=messages,
                response_format=self.schema,
                temperature=self.temperature
            )
            return response.choices[0].message.parsed
        except Exception as e:
            # Fallback to regular completion if structured outputs fail
            import logging
            logging.warning(f"Structured outputs failed, falling back to regular completion: {e}")
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature
            )
            
            # Try to parse the response as JSON and create schema instance
            import json
            try:
                parsed_json = json.loads(response.choices[0].message.content)
                return self.schema(**parsed_json)
            except Exception as parse_error:
                logging.error(f"Failed to parse response as JSON: {parse_error}")
                raise parse_error
    
    # Keep backward compatibility
    def return_schema_from_ocr(self, ocr_output):
        return self.return_schema_from_document(ocr_output)
