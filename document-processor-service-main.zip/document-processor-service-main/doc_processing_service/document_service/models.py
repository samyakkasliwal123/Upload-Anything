import uuid
from django.db import models
from pydantic import BaseModel
from typing import List, Set, Any, Optional
from enum import Enum

from doc_processing_service.document_service.text_choices import Product, DocumentSubCategory, DocumentCategory
from doc_processing_service.temporal_service.workflows.workflow_status import Status


class WorkspaceNode(BaseModel):
    id: str
    nodeType: str = "WORKSPACE"
    productAssociated: List[str] = ['CONSUMER_ITR']
    name: str


class WorkSpace(BaseModel):
    workspaceNode: WorkspaceNode
    canManage: bool


class FetchWorkSpaceResponse(BaseModel):
    workspaces: List[WorkSpace]


class UserRole(str, Enum):
    DIY_USER = "DIY_USER"
    ASSISTED_USER = "ASSISTED_USER"
    CA = "CA"
    RELATIONSHIP_MANAGER = "RELATIONSHIP_MANAGER"


class Permission(BaseModel):
    name: str


class PermissionType(str, Enum):
    READ = "READ"
    WRITE = "WRITE"


class UserPermissions(BaseModel):
    name: UserRole
    permissions: List[Permission]

    assistedRoles: Set[UserRole] = {
        UserRole.DIY_USER,
        UserRole.ASSISTED_USER,
        UserRole.CA,
        UserRole.RELATIONSHIP_MANAGER
    }


class User(BaseModel):
    externalId: uuid.UUID
    username: str
    is_authenticated: bool = False


class SessionDetails(BaseModel):
    SessionId: str = ""
    ValidTill: str = "0001-01-01"


class UserProfileDetails(BaseModel):
    pass  # Empty for now, can be extended as needed


class CachedUserDetails(BaseModel):
    """Model for cached user details from Redis EntityUser pattern."""
    userId: uuid.UUID
    username: str
    userProfileDetails: UserProfileDetails = UserProfileDetails()
    sessionDetails: SessionDetails = SessionDetails()


class DocumentMetadata(BaseModel):
    DataAssignmentSectionIndex: Optional[int] = None

class DocumentRequestData(BaseModel):
    DocumentId: str
    DocumentName: str
    ScopeId: str
    DocumentCategory: Optional[str] = None
    DocumentSubCategory: Optional[str] = None
    DocumentS3Url: str
    DocumentS3BucketName: str
    DocumentPassword: str
    DocumentData: Optional[str] = None
    UserExternalId: str
    UserSessionId: Optional[str] = None
    Metadata: Optional[DocumentMetadata] = None

class NextActivityDetails(BaseModel):
    parser_activity_name: Optional[str] = None
    parser_activity_request_data: Optional[Any] = None
    parser_task_queue: Optional[str] = None
    notify_task_queue: Optional[str] = None
    classified_type: Optional[str] = None
    notify_activity_name: Optional[str] = None
    notify_activity_request_data: Optional[DocumentRequestData] = None
    llm_transformed_data: Optional[Any] = None


class WorkflowStatusResponse(BaseModel):
    workflow_id:    Optional[str]
    workflow_status: Optional[str]
    current_activity: Optional[str]
    is_processing_completed: Optional[bool]
    document_name: Optional[str]
    document_id: Optional[int]
    llm_classified: Optional[bool]
    status: Optional[str]
    llm_parsed: Optional[bool]
    classified_section: Optional[str]
    classified_subsection: Optional[str]
    given_section: Optional[str]
    classified_section_redirect_path: Optional[str]
    product_document_external_id: Optional[str]
    product_status_response: Any
    s3_url: Optional[str]


class Form26AsParserRequestData(BaseModel):
    DocumentId: str
    DocumentName: str
    ScopeId: str
    DocumentS3Url: str
    DocumentPassword: str
    UserExternalId: str
    DocumentS3BucketName: str


class ValidateDocumentResponse(BaseModel):
    document_id: Optional[int] = None
    status: Optional[Status] = None
    validated_meta_data: Optional[dict] = None
    validated_password: Optional[str] = None
    error: Optional[str] = None

class ValidateDocumentRequest(BaseModel):
    meta_data: dict
    file_extension: str
    file_bytes: bytes

class DocumentTypeConfiguration(models.Model):
    document_category = models.CharField(choices=DocumentCategory.choices(), max_length=128)
    document_subcategory = models.CharField(choices=DocumentSubCategory.choices(),max_length=128,blank=True)
    product = models.CharField(choices=Product.choices(), max_length=100)
    regex_patterns = models.JSONField(blank=True, null=True)
    parser_activity = models.CharField(max_length=64, blank=True)
    notify_activity = models.CharField(max_length=64, blank=True)
    redirection_url = models.CharField(max_length=500, blank=True)
    allowed_extensions = models.JSONField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def document_type_value(self):
        return DocumentCategory[self.document_category].value

    @property
    def document_subtype_value(self):
        if self.document_subcategory:
            return DocumentSubCategory[self.document_subcategory].value
        return DocumentSubCategory.NOT_INITIALIZED.value

    @property
    def product_value(self):
        return Product[self.product].value

    class Meta:
        db_table = 'document_type_configuration'
        unique_together = ['document_category','document_subcategory', 'product']
        indexes = [
            models.Index(fields=['document_category', 'product'],
                         name='doc_product_idx'),
        ]


class Document(models.Model):
    document_id = models.AutoField(primary_key=True)
    user_id = models.UUIDField()  # Foreign key to User
    workflow_id = models.CharField(max_length=200, db_index=True)
    product = models.CharField(choices=Product.choices(), max_length=100)
    scope = models.CharField(max_length=100)
    section = models.CharField(max_length=100)
    document_type_configuration = models.ForeignKey(DocumentTypeConfiguration,
                                                    on_delete=models.PROTECT, null=True)
    llm_classified = models.BooleanField(default=False)
    llm_parsed = models.BooleanField(default=False)
    status = models.CharField(max_length=50, default="PENDING")
    s3_url = models.URLField(max_length=500)
    document_name = models.CharField(max_length=500, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    extracted_data = models.BinaryField(null=True, blank=True)
    product_document_external_id = models.CharField(max_length=200, null=True)
    deleted = models.BooleanField(default=False)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def document_category(self):
        if self.document_type_configuration:
            return self.document_type_configuration.document_type_value
        return None

    @property
    def document_subcategory(self):
        if self.document_type_configuration:
            return self.document_type_configuration.document_subtype_value
        return None

    @property
    def redirection_url(self):
        if self.document_type_configuration:
            return self.document_type_configuration.redirection_url
        return None
