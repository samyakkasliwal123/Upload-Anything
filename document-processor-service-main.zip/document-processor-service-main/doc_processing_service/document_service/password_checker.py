import binascii
import hmac
from abc import ABC, abstractmethod
from hashlib import sha256
from io import BytesIO
import logging
import base64

from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad
from pypdf import PdfReader
from pypdf.errors import WrongPasswordError, FileNotDecryptedError
import msoffcrypto
from msoffcrypto import exceptions

class PasswordChecker(ABC):
    @abstractmethod
    def is_password_protected(self, file_data: bytes) -> bool:
        pass

    @abstractmethod
    def is_password_correct(self, file_data: bytes, password: str) -> bool:
        pass


class DefaultPasswordChecker(PasswordChecker):
    def is_password_protected(self, file_data: bytes) -> bool:
        return False

    def is_password_correct(self, file_data: bytes, password: str) -> bool:
        return True


class PDFPasswordChecker(PasswordChecker):
    def is_password_protected(self, file_data: bytes) -> bool:
        try:
            reader = PdfReader(BytesIO(file_data))
            if not reader.is_encrypted:
                return False

            # If it's encrypted but we can still read it without a password,
            # it means it only has permission restrictions but no user password
            try:
                # Try to access some content to verify we can read without password
                if len(reader.pages) > 0:
                    # We can access content without a password, so it's not password-protected
                    # (it only has permission restrictions)
                    return False
            except FileNotDecryptedError:
                # If we get a FileNotDecryptedError, it means it requires a password to be accessed) has not been successfully decrypted
                return True

            # If we can't determine, default to considering it encrypted
            return True
        except Exception as e:
            logging.info(f"[password-checker] Error checking PDF password: {e}")
            return False

    def is_password_correct(self, file_data: bytes, password: str) -> bool:
        try:
            PdfReader(BytesIO(file_data), password=password)
            return True
        except WrongPasswordError:
            return False
        except Exception as e:
            logging.info(f"[password-checker] Error validating PDF password: {e}")
            return False


class OfficePasswordChecker(PasswordChecker):
    def is_password_protected(self, file_data: bytes) -> bool:
        try:
            file = BytesIO(file_data)
            doc = msoffcrypto.OfficeFile(file)
            return doc.is_encrypted()
        except Exception as e:
            logging.info(f"[password-checker] Error checking Office File password: {e}")
            return False

    def is_password_correct(self, file_data: bytes, password: str) -> bool:
        try:
            file = BytesIO(file_data)
            doc = msoffcrypto.OfficeFile(file)
            doc.load_key(password=password)
            return True
        except exceptions.InvalidKeyError:
            return False
        except Exception as e:
            logging.info(f"[password-checker] Error validating Office File: {e}")
            return False


class JSONPasswordChecker(PasswordChecker):
    def is_password_protected(self,file_data):
        """
        Checks if the provided file data is encrypted by validating its structure.

        :param file_data: The file data as a byte array.
        :return: True if the file is encrypted, False otherwise.
        """
        try:
            # Ensure the data is long enough to contain IV, salt, and content
            if len(file_data) < 64:
                return False  # Too short to be encrypted data

            # Decode the data as UTF-8
            encrypted_string = file_data.decode("utf-8").strip()

            # Validate IV and salt are hex strings
            iv = encrypted_string[:32]
            salt = encrypted_string[32:64]
            if not (len(iv) == 32 and len(salt) == 32):
                return False
            if not all(c in "0123456789abcdefABCDEF" for c in iv + salt):
                return False

            # Validate base64 encoded content
            encoded_content = encrypted_string[64:]
            try:
                base64.b64decode(encoded_content)
            except Exception:
                return False

            return True
        except Exception as e:
            raise ValueError(f"Error checking encryption: {e}")

    def is_password_correct(self, file_data: bytes, password: str) -> bool:
        try:
            encrypted_string = file_data.decode("utf-8")
            encoded_content = encrypted_string[64:]

            # Extract IV and salt from the encrypted string
            iv = binascii.unhexlify(encrypted_string[:32])
            salt = binascii.unhexlify(encrypted_string[32:64])

            # Extract the encrypted content
            encrypted = base64.b64decode(encoded_content)

            # Derive the encryption key using PBKDF2 with SHA-256
            key = PBKDF2(password, salt, dkLen=32, count=1000,prf=lambda p, s: hmac.new(p, s, sha256).digest())

            # Decrypt the data using AES (RijndaelManaged equivalent)
            cipher = AES.new(key, AES.MODE_CBC, iv)
            decrypted_data = cipher.decrypt(encrypted)

            # Remove PKCS7 padding
            plain_text = unpad(decrypted_data, AES.block_size).decode("utf-8")
            return True

        except Exception as e:
            logging.error(f"[password-checker] Error validating JSON password: {e}")
            return False


class PasswordCheckerFactory:
    _checkers = {
        ".pdf": PDFPasswordChecker,
        ".xlsx": OfficePasswordChecker,
        ".docx": OfficePasswordChecker,
        ".pptx": OfficePasswordChecker,
        ".doc": OfficePasswordChecker,
        ".ppt": OfficePasswordChecker,
        ".xls": OfficePasswordChecker,
        ".json": JSONPasswordChecker,
    }

    @staticmethod
    def get_password_checker(file_extension: str) -> PasswordChecker:
        return PasswordCheckerFactory._checkers.get(file_extension, DefaultPasswordChecker)()
