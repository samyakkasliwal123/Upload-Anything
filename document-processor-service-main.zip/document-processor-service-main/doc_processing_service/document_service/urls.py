from django.urls import path,include
from .views import FileUploadView, WorkflowStatusView, DocumentTypeConfigurationView, DocumentStatusView, \
    DocumentDeleteView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', include('django_prometheus.urls')),
    path('upload/', FileUploadView.as_view(), name='upload'),
    path('status/', WorkflowStatusView.as_view(), name='workflow-status'),
    path('status/document/<str:document_id>/', DocumentStatusView.as_view(), name='document-status'),
    path('document/<str:document_id>/', DocumentDeleteView.as_view(), name='document-delete'),
    path('document_type_configuration/<str:product>/<str:document_category>/',
         DocumentTypeConfigurationView.as_view({
             'get': 'retrieve',
             'put': 'update',
             'delete': 'destroy'
         }),
         name='document-type-configuration'),
    path('document_type_configuration/', DocumentTypeConfigurationView.as_view({
        'get': 'list',
        'post': 'create'
    }), name='document-type-configuration-list'),
]


urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
