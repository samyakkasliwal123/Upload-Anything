from rest_framework import serializers
from .models import Document, DocumentTypeConfiguration
from .validators import validate_regex_patterns, validate_file_extension


class DocumentTypeConfigurationSerializer(serializers.ModelSerializer):
    regex_patterns = serializers.ListField(
        child=serializers.CharField(),
        allow_empty=True,
        required=False,
        validators=[validate_regex_patterns, validate_file_extension]
    )

    class Meta:
        model = DocumentTypeConfiguration
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']


class DocumentSerializer(serializers.ModelSerializer):
    document_type_configuration = DocumentTypeConfigurationSerializer(read_only=True)

    class Meta:
        model = Document
        fields = '__all__'

class MetaDataSerializer(serializers.Serializer):
    password = serializers.CharField(required=False, allow_blank=True)
    section = serializers.CharField(required=False, allow_blank=True)
    pan = serializers.CharField(required=False, allow_blank=True)
    dob = serializers.CharField(required=False, allow_blank=True)
    index = serializers.IntegerField(required=False, allow_null=True)
