import io
import json
import logging
import os
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from time import perf_counter

from asgiref.sync import async_to_sync
from configuration import Config
from django.http import JsonResponse, HttpResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from document_service.helpers.temporal_workflow_utils import get_workflow_status
from document_service.models import DocumentTypeConfiguration, Document, WorkflowStatusResponse
from document_service.serializers import DocumentTypeConfigurationSerializer, MetaDataSerializer
from document_service.text_choices import DocumentCategory, Product
from permissions import MultipleScopePermissionCheck
from rest_framework.generics import get_object_or_404
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from services.aws_utils import get_presigned_url
from services.compression_utils import CompressionService
from services.documentdb_service import DocumentService
from services.redis_service import redis_client
from services.s3_client_pool import s3_client_pool
from services.s3_service import S3Service
from temporal_service.data_converter import EncryptionCodec
from temporal_service.workflows.process_document import DocumentProcessingWorkflow
from temporal_service.workflows.workflow_status import Status

from doc_processing_service.services.aws_utils import upload_file_stream
from doc_processing_service.temporal_service.management.commands.start_temporal_worker import WORKFLOW_TASK_QUEUE
from doc_processing_service.temporal_service.utils.client import TemporalClientSingleton

MAX_FILES_PER_UPLOAD = 25
MAX_FILES_IN_ZIP = 50

class FileUploadView(APIView):
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        uploaded_files = request.FILES.getlist('file')
        if len(uploaded_files) > MAX_FILES_PER_UPLOAD:
            return JsonResponse({"error": "Too many files uploaded at once."}, status=400)

        product = request.data.get('product')
        scope = request.data.get('scope')
        user_id = request.user.externalId
        user_sid = request.COOKIES.get('sid')
        meta_data = json.loads(request.data.get('meta_data', '{}'))

        normalized_meta = {
            os.path.basename(k): v for k, v in meta_data.items()
        }

        workflow_ids = self.process_all_files(
            uploaded_files, normalized_meta, product, scope, user_id, user_sid
        )

        return JsonResponse({
            "status": "Files uploaded and processing started",
            "workflow_ids": workflow_ids
        })

    def process_all_files(self, uploaded_files, meta_data, product, scope, user_id, user_sid):
        """
        Optimized file processing with async_to_sync for better performance.
        """
        workflow_ids = {}

        def handle_file_optimized(file_obj):
            """Optimized file handler with better error handling and resource management."""
            file_name = file_obj.name
            file_ext = os.path.splitext(file_name)[1].lower()
            file_metadata = meta_data.get(os.path.basename(file_name), {})

            try:
                if file_ext == '.zip':
                    return self._handle_zip_file(file_obj, file_name, file_ext, meta_data,
                                                product, scope, user_id, user_sid)
                else:
                    return self._handle_single_file(file_obj, file_name, file_ext, file_metadata,
                                                   product, scope, user_id, user_sid)
            except Exception as e:
                logging.error(f"Error processing file {file_name}: {e}")
                return {file_name: f"error-{uuid.uuid4()}"}

        # Optimize thread pool size - use smaller, fixed pool to reduce contention
        max_workers = min(50, max(8, len(uploaded_files) * 4))  # Increased to prevent thread pool saturation
        
        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Use submit instead of map for better error handling
                futures = [executor.submit(handle_file_optimized, file_obj) for file_obj in uploaded_files]
                
                # Collect results with timeout to prevent hanging
                results = []
                for future in futures:
                    try:
                        result = future.result(timeout=60)  # 60 second timeout per file
                        results.append(result)
                    except Exception as e:
                        logging.error(f"File processing timeout or error: {e}")
                        results.append({"error": str(e)})

        except Exception as e:
            logging.error(f"Thread pool execution failed: {e}")
            # Fallback to sequential processing
            results = [handle_file_optimized(file_obj) for file_obj in uploaded_files]

        # Merge all workflow IDs into one dict
        for result in results:
            if result:
                workflow_ids.update(result)

        return workflow_ids

    def _handle_zip_file(self, file_obj, file_name, file_ext, meta_data, product, scope, user_id, user_sid):
        """Handle ZIP file processing with optimized resource usage."""
        zip_bytes = file_obj.read()
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zip_ref:
            zip_infos = [zi for zi in zip_ref.infolist() if not zi.is_dir()]
            if len(zip_infos) > MAX_FILES_IN_ZIP:
                raise ValueError("ZIP contains too many files")

            inner_ids = {}
            for zip_info in zip_infos:
                extracted_name = os.path.basename(zip_info.filename)
                extracted_ext = os.path.splitext(extracted_name)[1].lower()
                extracted_meta = meta_data.get(extracted_name, {})
                s3_key = f"{product}/{scope}/{uuid.uuid4()}_zip_mumbai{extracted_ext}"

                # Extract file content from ZIP
                with zip_ref.open(zip_info) as extracted_file:
                    extracted_content = io.BytesIO(extracted_file.read())
                    upload_file_stream(extracted_content, s3_key)

                workflow_id = f"doc-processing-{uuid.uuid4()}"
                # Use async_to_sync with the singleton client
                client = async_to_sync(TemporalClientSingleton.get_client)()
                async_to_sync(client.start_workflow)(
                    workflow=DocumentProcessingWorkflow,
                    task_queue=WORKFLOW_TASK_QUEUE,
                    args=[
                        s3_key, user_id, extracted_name, extracted_ext,
                        product, scope, extracted_meta, user_sid
                    ],
                    id=workflow_id,
                    run_timeout=timedelta(seconds=60),
                )
                
                inner_ids[extracted_name] = workflow_id
            return inner_ids

    def _handle_single_file(self, file_obj, file_name, file_ext, file_metadata, product, scope, user_id, user_sid):
        """Handle single file processing with optimized S3 upload."""
        s3_key = f"{product}/{scope}/{uuid.uuid4()}_mumbai{file_ext}"
        
        start = perf_counter()
        # Reset file pointer to beginning
        file_obj.seek(0)
        upload_file_stream(file_obj, s3_key)
        logging.info(f"File {file_name} uploaded to S3 in {perf_counter() - start:.2f} seconds")

        start = perf_counter()
        workflow_id = f"doc-processing-{uuid.uuid4()}"
        
        # Use async_to_sync with the singleton client
        client = async_to_sync(TemporalClientSingleton.get_client)()
        async_to_sync(client.start_workflow)(
            workflow=DocumentProcessingWorkflow,
            task_queue=WORKFLOW_TASK_QUEUE,
            args=[
                s3_key, user_id, file_name, file_ext,
                product, scope, file_metadata, user_sid
            ],
            id=workflow_id,
            run_timeout=timedelta(seconds=60),
        )
            
        logging.info(f"Workflow {workflow_id} started for file {file_name} in {perf_counter() - start:.2f} seconds")
        return {file_name: workflow_id}


class WorkflowStatusView(APIView):
    permission_classes = [MultipleScopePermissionCheck]

    def get(self, request, *args, **kwargs):
        workflow_ids = request.GET.getlist('workflow_id')

        documents = Document.objects.filter(workflow_id__in=workflow_ids).select_related(
            'document_type_configuration'
        ).iterator()
        document_map = {doc.workflow_id: doc for doc in documents}

        def get_url(document):
            """Optimized URL generation without event loop blocking."""
            cache_prefix = "presigned_document_url_"
            # Use async_to_sync for Redis operations
            try:
                cached_url = async_to_sync(redis_client.get)(f"{cache_prefix}{document.s3_url}")
                if cached_url:
                    return cached_url
            except Exception as e:
                logging.warning(f"Redis cache lookup failed: {e}")
            
            # Use sync S3 client instead of asyncio.run() to avoid event loop blocking
            s3_client = None
            try:
                s3_client = s3_client_pool.get_client()
                s3_service = S3Service(s3_client)
                presigned_url = s3_service.generate_presigned_url_sync(
                    Config.S3_BUCKET_NAME,
                    document.s3_url
                )
                # Use async_to_sync for Redis caching
                try:
                    async_to_sync(redis_client.set_with_expiry)(f"{cache_prefix}{document.s3_url}", presigned_url, 150)
                except Exception as e:
                    logging.warning(f"Redis cache set failed: {e}")
                return presigned_url
            except Exception as e:
                logging.error(f"Failed to generate presigned URL: {e}")
                return ""
            finally:
                if s3_client:
                    s3_client_pool.return_client(s3_client)

        def is_processing_completed(document):
            """
            Check if document processing is completed based on document status column.
            Terminal states indicate processing completion (success or failure).
            """
            if not document:
                return False
            
            # Define terminal states from Status enum
            terminal_states = {
                Status.COMPLETED.name,
                Status.VALIDATION_FAILED.name,
                Status.FILE_UPLOADING_FAILED.name,
                Status.PASSWORD_REQUIRED.name,
                Status.PASSWORD_INCORRECT.name,
                Status.TEXT_EXTRACTION_FAILED.name,
                Status.CLASSIFYING_DOCUMENT_FAILED.name,
                Status.PARSING_DOCUMENT_FAILED.name,
                Status.UPDATING_DOCUMENT_FAILED.name,
                Status.TOO_BIG_FILE.name,
                Status.INVALID_FILE.name,
                Status.INVALID_META_DATA.name,
                Status.UPDATING_DOCUMENT_TO_PRODUCT_FAILED.name,
                Status.FAILED.name,
                Status.NOTIFY_FAILED.name
            }
            
            # Check if document status is in terminal states
            return document.status in terminal_states

        def process_workflow(workflow_id):
            """Optimized workflow processing using document status as current activity."""
            try:
                workflow_status = async_to_sync(get_workflow_status)(workflow_id)
            except Exception as e:
                logging.error(f"Failed to get workflow status for {workflow_id}: {e}")
                workflow_status = "UNKNOWN"
                
            document = document_map.get(workflow_id)
            # Use document status as current_activity, fallback to default if no document
            current_activity = document.status if document else Status.INITIATING.name
            
            response = WorkflowStatusResponse(
                workflow_id=workflow_id,
                workflow_status=workflow_status,
                current_activity=current_activity,
                is_processing_completed=is_processing_completed(document),
                document_name=document.document_name if document else None,
                document_id=document.document_id if document else None,
                llm_classified=document.llm_classified if document else None,
                status=document.status if document else None,
                llm_parsed=document.llm_parsed if document else None,
                classified_section=document.document_type_configuration.document_category
                                    if document and document.document_type_configuration else None,
                classified_subsection=document.document_type_configuration.document_subcategory
                                    if document and document.document_type_configuration else None,
                given_section=document.section if document else None,
                classified_section_redirect_path=(document.document_type_configuration.redirection_url
                                                  if document and document.document_type_configuration else None),
                product_document_external_id=document.product_document_external_id if document else None,
                product_status_response=json.loads(CompressionService.decompress_data_sync(document.extracted_data)) if document and document.extracted_data else None,
                s3_url=None
            )
            return response

        response_list = [process_workflow(wid) for wid in workflow_ids]
        response_json = [resp.model_dump() for resp in response_list]
        return JsonResponse(response_json, safe=False)


class DocumentStatusView(View):
    async def get(self, request, document_id, *args, **kwargs):
        document = await DocumentService.get_document(document_id)
        return JsonResponse({
            "document_id": document_id,
            "status": document.status,
            "parsed_data": json.dumps(document.extracted_data)
        })


@method_decorator(csrf_exempt, name='dispatch')
class DocumentDeleteView(View):
    async def delete(self, request, document_id, *args, **kwargs):
        await DocumentService.update_document(document_id, deleted=True)
        return HttpResponse(status=204)


class DocumentTypeConfigurationView(ModelViewSet):
    serializer_class = DocumentTypeConfigurationSerializer
    queryset = DocumentTypeConfiguration.objects.all()
    permission_classes = [AllowAny]

    def get_object(self):
        """Retrieve a DocumentTypeConfiguration instance based on document_category and product."""
        document_category = self.kwargs.get('document_category')
        product = self.kwargs.get('product')
        Product.validate(product)
        obj = get_object_or_404(DocumentTypeConfiguration, document_category=document_category, product=product)
        return obj
