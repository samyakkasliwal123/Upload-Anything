# doc_processing_service/document_service/classification.py
import time
from abc import ABC, abstractmethod
import re
from typing import Any

from document_service.text_choices import DocumentCategory
from document_service.llm.parser_classifier import LLMDataParserClassifier
from document_service.llm.llm_dataclasses import TaxDocumentClassification
from document_service.helpers.database_utils import filter_document_types
import logging
from document_service.llm.prompts import document_classification_template
from exceptions import LLMClassificationFailed


class DocumentClassifier(ABC):
    @abstractmethod
    def classify(self, extracted_text: str, product: str, file_extension: str) -> str:
        pass


class RegexClassifier(DocumentClassifier):
    async def classify(self, extracted_text: str, product: str, file_extension: str) -> tuple[Any, Any] | Any:
        """Async regex classification"""
        document_configurations = await filter_document_types(product)

        best_match = None
        highest_score = 0
        normalized_text = ' '.join(extracted_text.split())

        for config in document_configurations:
            if config.allowed_extensions and file_extension not in config.allowed_extensions:
                continue

            match_score = 0
            for pattern in config.regex_patterns:
                if re.search(pattern, normalized_text, re.IGNORECASE):
                    match_score += 1

                if match_score == 0:
                    continue

            # If any patterns matched, consider this config
            if match_score > highest_score and match_score >= 2:
                highest_score = match_score
                best_match = config.document_category, config.document_subcategory

        if best_match:
            return best_match

        return DocumentCategory.DOC_ADDITIONAL_DOC.name, ""# Default to additional doc if no match


class LLMClassifier(DocumentClassifier):
    async def classify(self, extracted_text: str, product: str, file_extension: str) -> tuple[Any, Any] | Any:
        """Async LLM classification to avoid blocking event loop"""
        import asyncio
        start_time = time.time()
        
        # Offload LLM call to thread pool to avoid blocking
        document_type_classification: TaxDocumentClassification = await asyncio.to_thread(
            lambda: LLMDataParserClassifier(
                "gpt-4o",
                0,
                TaxDocumentClassification,
                document_classification_template
            ).return_schema_from_document(extracted_text)
        )
        
        end_time = time.time()  # Record end time
        classification_duration = end_time - start_time  # Calculate duration
        logging.info(f"LLM classification took {classification_duration:.2f}s: {document_type_classification}")
        document_type = document_type_classification.docType
        document_subtype = document_type_classification.docTypeSub
        return document_type.name, document_subtype.name if document_subtype else ""


class DocumentClassificationContext:
    def __init__(self, classifier: DocumentClassifier):
        self.classifier = classifier

    async def classify_document(self, extracted_text: str, product: str, file_extension: str) -> tuple[Any, Any] | Any:
        """Async document classification"""
        return await self.classifier.classify(extracted_text, product, file_extension)
