import logging
import sentry_sdk
from datetime import timedelta

from temporalio.client import RPCError

from doc_processing_service.temporal_service.workflows.workflow_status import Status
from doc_processing_service.temporal_service.utils.client import TemporalClientSingleton


async def get_workflow_status(workflow_id):
    """
    Get workflow status from Temporal with optimized timeouts and error handling.
    """
    try:
        client = await TemporalClientSingleton.get_client()
        handle = client.get_workflow_handle(workflow_id)
        
        # Use shorter timeout for faster response
        result = await handle.describe(rpc_timeout=timedelta(seconds=2))
        
        return result.status.name
        
    except RPCError as e:
        logging.error(f"RPC error getting workflow status for {workflow_id}: {e}")
        sentry_sdk.capture_exception(e)
        # Return FAILED for RPC errors (workflow likely in failed state)
        return "FAILED"
        
    except Exception as e:
        logging.error(f"Unexpected error getting workflow status for {workflow_id}: {e}")
        sentry_sdk.capture_exception(e)
        # Return UNKNOWN for other errors
        return "UNKNOWN"
