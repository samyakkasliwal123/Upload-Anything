import base64
import uuid


def shortguid_to_string(short_guid):
    """
    Converts a short GUID back to a UUID string.
    """
    padding = '=' * (-len(short_guid) % 4)  # Add padding for Base64 decoding
    decoded_bytes = base64.urlsafe_b64decode(short_guid + padding)

    # Reorder the bytes to match GUID structure (little-endian fields)
    reordered_bytes = (
        decoded_bytes[3::-1] +   # Reverse the first 4 bytes
        decoded_bytes[5:3:-1] +  # Reverse the next 2 bytes
        decoded_bytes[7:5:-1] +  # Reverse the next 2 bytes
        decoded_bytes[8:]        # Leave the remaining bytes as is
    )

    # Convert bytes back to UUID
    guid = uuid.UUID(bytes=reordered_bytes)
    return str(guid)