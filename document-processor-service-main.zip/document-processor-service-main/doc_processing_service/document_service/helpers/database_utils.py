import asyncio
from services.documentdb_service import DocumentService


async def filter_document_types(product: str):
    """
    Filter document types based on the product.

    Args:
        product: The product to filter document types for.

    Returns:
        The filtered list of document types.
    """
    document_type_configs = await DocumentService.get_all_document_type_configs()
    return [
        config for config in document_type_configs
        if config.product == product and config.regex_patterns
    ]
