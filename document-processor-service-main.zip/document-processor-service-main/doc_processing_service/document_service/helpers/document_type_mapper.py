import os
from typing import Optional
import uuid

from configuration import Config
from temporal_service.activities.dataclasses import Metadata
from document_service.helpers.shortuuid_utils import shortguid_to_string
from document_service.models import Document, DocumentRequestData, Form26AsParserRequestData, DocumentMetadata


class DocumentTypeMapper:
    """Maps document types to their respective queue configurations."""

    @classmethod
    def prepare_parser_request(cls, document: Document, activity_name: str) -> dict:
        """
        Prepare the request message based on the document type and activity name, including any
        necessary attributes or metadata required for processing.

        Parameters
        ----------
        key
        """
        task_id = str(uuid.uuid4())
        request_data = {
            'Identifier': task_id,
            'UserKey': document.user_id,
            'ResponseQueueName': '',
        }

        activity_mapping = {
            "ParseForm16": {
                'Form16S3Url': document.s3_url,
                'BucketName': Config.S3_BUCKET_NAME,
                'isForm16A': False,
                'Password': document.password,
            },
            "ParseExcel": {
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url.split('/')[-1],
                        'S3FileName': document.s3_url,
                        'BrokerageType': document.document_type_configuration.document_subtype_value,
                        'FileExtension': "Pdf" if os.path.splitext(document.s3_url)[1] == '.pdf' else "Excel",
                        'FilePassword': document.password,
                    }
                ],
                'BucketName': Config.S3_BUCKET_NAME,
                'ParseUntilEmptyRowEncountered': False,
                'FileHeadType' : document.document_type_configuration.document_type_value,
            },
            "ParseAis": {
                'ReportId': document.document_id,
                'S3Url': document.s3_url,
                'Password': document.password,
                'EntityId': shortguid_to_string(document.scope.rsplit('_', 1)[0]),
                'FiscalYear': document.scope.rsplit('_', 1)[1],  # Add logic to determine fiscal year if needed
                'BucketName': Config.S3_BUCKET_NAME,
                'Extension': os.path.splitext(document.s3_url)[1],
                'UploadedFileName': document.s3_url.split('/')[-1],
                'UserExternalId': str(document.user_id),
            },
            "ParseVda": {
                # Add specific fields for ParseVda if needed
                'BucketName': Config.S3_BUCKET_NAME,
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url,
                        'Source': document.document_type_configuration.document_subtype_value,
                        'FilePassword': document.password,
                    }
                ],
            },
            "ParseBonds": {
                'BucketName': Config.S3_BUCKET_NAME,
                'FiscalYear': document.scope.rsplit('_', 1)[1],
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url,
                        'Source': document.document_type_configuration.document_subtype_value,
                        'FilePassword': document.password,
                    }
                ],
            },
            "ParseInvoiceDiscounting": {
                # Add specific fields for ParseInvoiceDiscounting if needed
                'BucketName': Config.S3_BUCKET_NAME,
                'FY': document.scope.rsplit('_', 1)[1],
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url,
                        'Source': document.document_type_configuration.document_subtype_value,
                        'FilePassword': document.password,
                    }
                ],
            },
            "ParseP2P": {
                # Add specific fields for ParseP2P if needed
                'BucketName': Config.S3_BUCKET_NAME,
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url,
                        'Source': document.document_type_configuration.document_subtype_value,
                        'FilePassword': document.password,
                    }
                ],
            },
            "ParseRsus": {
                # Add specific fields for ParseP2P if needed
                'BucketName': Config.S3_BUCKET_NAME,
                'FY': document.scope.rsplit('_', 1)[1],
                'Files': [
                    {
                        'ReportId': document.document_id,
                        'FileName': document.s3_url,
                        'Source': document.document_type_configuration.document_subtype_value,
                        'FilePassword': document.password,
                    }
                ],
            },
            "default": {
                # Default fields for other activities
            }
        }

        request_data.update(activity_mapping.get(activity_name, activity_mapping["default"]))

        return request_data

    @classmethod
    def prepare_notify_request(cls, document: Document, user_sid: str, metadata: Optional[Metadata] = None) -> DocumentRequestData:
        doc_metadata = None
        if metadata:
            doc_metadata = DocumentMetadata(DataAssignmentSectionIndex=metadata.data_assignment_index)
        request_data = DocumentRequestData(
            DocumentId=str(document.document_id),
            DocumentName=document.document_name,
            ScopeId=document.scope,
            DocumentCategory=document.document_type_configuration.document_type_value if document.document_type_configuration else None,
            DocumentSubCategory=document.document_type_configuration.document_subtype_value if document.document_type_configuration else None,
            DocumentS3Url=document.s3_url,
            DocumentS3BucketName=Config.S3_BUCKET_NAME,
            DocumentPassword=document.password,
            UserExternalId=str(document.user_id),
            UserSessionId=user_sid,
            Metadata=doc_metadata,
        )
        return request_data

    @classmethod
    def prepare_form_26_as_parser_request(cls, document: Document) -> Form26AsParserRequestData:
        request_data = Form26AsParserRequestData(
            DocumentId=str(document.document_id),
            DocumentName=document.document_name,
            ScopeId=document.scope,
            DocumentS3Url=document.s3_url,
            DocumentPassword=document.password,
            UserExternalId=str(document.user_id),
            DocumentS3BucketName=Config.S3_BUCKET_NAME,
        )
        return request_data
