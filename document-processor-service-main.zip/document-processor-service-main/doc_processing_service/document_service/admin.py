from django.contrib import admin
from .models import DocumentTypeConfiguration

@admin.register(DocumentTypeConfiguration)
class DocumentTypeConfigurationAdmin(admin.ModelAdmin):
    # List all fields except 'id'
    fields = [
        'document_category',
        'document_subcategory',
        'product',
        'regex_patterns',
        'parser_activity',
        'notify_activity',
        'redirection_url',
        'allowed_extensions',
        'created_at',
        'updated_at',
    ]

    # Read-only fields
    readonly_fields = ['created_at', 'updated_at']

    # Add search and filters
    search_fields = ['document_category', 'document_subcategory', 'product']
    list_filter = ['document_category', 'product', 'created_at']
    list_display = ['document_category', 'document_subcategory', 'product', 'created_at', 'updated_at']