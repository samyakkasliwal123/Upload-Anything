from django.db import migrations


def populate_document_type_configurations(apps, schema_editor):
    DocumentTypeConfiguration = apps.get_model('document_service', 'DocumentTypeConfiguration')
    configurations = configurations = [
        {"id": 1, "document_category": "DOC_FORM16", "document_subcategory": "", "product": "ITR", "regex_patterns": "[\"\\bform\\s*NO.\\s*16\\b\"]", "parser_activity": "ParseForm16", "notify_activity": "SaveDocumentProcessingStatus", "redirection_url": "", "created_at": "2024-12-09T11:32:00.104795Z", "updated_at": "2024-12-09T11:32:00.104831Z"},
        {"id": 2, "document_category": "MISCELLANEOUS", "document_subcategory": "", "product": "ITR", "regex_patterns": "[]", "parser_activity": "", "notify_activity": "SaveDocumentProcessingStatus", "redirection_url": "", "created_at": "2024-12-09T11:32:24.760941Z", "updated_at": "2024-12-09T11:32:24.760981Z"},
        {"id": 3, "document_category": "DOC_FORM26AS", "document_subcategory": "", "product": "ITR", "regex_patterns": "[\"\\bAnnual\\b\\s+\\bTax\\b\\s+\\bStatement\\b\"]", "parser_activity": "ParseForm26As", "notify_activity": "SaveDocumentProcessingStatus", "redirection_url": "tax-saving/taxes-paid", "created_at": "2024-12-09T11:32:47.535298Z", "updated_at": "2024-12-09T11:32:47.535332Z"},
        {"id": 4, "document_category": "DOC_ANNUAL_INFORMATION_STATEMENT", "document_subcategory": "", "product": "ITR", "regex_patterns": "[\"Annual Information Statement\"]", "parser_activity": "ParseAis", "notify_activity": "SaveDocumentProcessingStatus", "redirection_url": "tax-saving/other ", "created_at": "2024-12-09T11:32:58.688839Z", "updated_at": "2024-12-09T11:32:58.688874Z"},
        {"id": 5, "document_category": "DOC_CAPITAL_GAIN_STATEMENT", "document_subcategory": "Zerodha", "product": "ITR", "regex_patterns": "[\"Tradewise Exits from\"]", "parser_activity": "ParseExcel", "notify_activity": "SaveDocumentProcessingStatus", "redirection_url": "income-sources/", "created_at": "2024-12-12T08:30:39.314473Z", "updated_at": "2024-12-12T08:30:39.314519Z"}
    ]
    for config in configurations:
        DocumentTypeConfiguration.objects.create(**config)


def remove_document_type_configurations(apps, schema_editor):
    DocumentTypeConfiguration = apps.get_model('document_service', 'DocumentTypeConfiguration')
    DocumentTypeConfiguration.objects.all().delete()


class Migration(migrations.Migration):
    dependencies = [
        ('document_service', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(populate_document_type_configurations, remove_document_type_configurations),
    ]
