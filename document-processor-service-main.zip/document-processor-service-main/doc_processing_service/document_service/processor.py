import binascii
import csv
import hmac
import io
import logging
import json
import base64
import asyncio
from abc import ABC, abstractmethod
from hashlib import sha256
from io import BytesIO,StringIO
from typing import Any
from concurrent.futures import ProcessPoolExecutor

import boto3
import pandas as pd
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad

from configuration import Config
from exceptions import InvalidFileException
from document_service.password_checker import JSONPasswordChecker

logger = logging.getLogger(__name__)

# Memory-optimized process pool for CPU-intensive document processing
# Reduced from 16 to 4 workers to save memory (16 * 50MB = 800MB vs 4 * 50MB = 200MB)
_process_pool = ProcessPoolExecutor(max_workers=4)


class DocumentProcessor(ABC):
    @abstractmethod
    async def process(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """Async process method that returns extracted text content"""
        pass


class PDFProcessor(DocumentProcessor):
    async def process(self, file_bytes: bytes, password: str = "", file_extension: str = None) -> str:
        """
        Async PDF processing using process pool to completely avoid blocking the event loop.
        """
        # Run entire PDF processing in separate process
        return await asyncio.get_event_loop().run_in_executor(
            _process_pool,
            self._process_pdf_sync,
            file_bytes, password, file_extension
        )
    
    def _process_pdf_sync(self, file_bytes: bytes, password: str = "", file_extension: str = None) -> str:
        """Synchronous PDF processing - runs in separate process."""
        import pdftotext
        
        text_content = ""

        if not password:
            password = ""

        # Extract text using pdftotext
        try:
            with BytesIO(file_bytes) as pdf_stream:
                pdf = pdftotext.PDF(pdf_stream, password=password)
                text_content = "\n".join(pdf)
        except Exception as e:
            logger.warning(f"pdftotext failed: {e}")
            text_content = "No text detected in the PDF."

        return text_content.strip()


class ExcelProcessor(DocumentProcessor):
    async def process(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """
        Async Excel processing using process pool to avoid blocking the event loop.
        """
        # Offload CPU-intensive Excel processing to separate process
        return await asyncio.get_event_loop().run_in_executor(
            _process_pool,
            self._process_excel_sync,
            file_bytes, password, file_extension
        )
    
    def _process_excel_sync(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """
        Synchronous Excel processing - runs in separate process.
        """
        def process_excel():
            def decrypt_excel(data: bytes, pwd: str) -> BytesIO:
                import msoffcrypto
                decrypted = BytesIO()
                try:
                    office_file = msoffcrypto.OfficeFile(BytesIO(data))
                    office_file.load_key(password=pwd)
                    office_file.decrypt(decrypted)
                    decrypted.seek(0)
                    return decrypted
                except Exception as e:
                    raise ValueError(f"Failed to decrypt file: {str(e)}")

            buffer = BytesIO(file_bytes)
            text_parts = []

            try:
                # Attempt decryption if password is provided
                if password:
                    try:
                        buffer = decrypt_excel(file_bytes, password)
                    except Exception as e:
                        logger.error("Decryption failed", {"error": str(e)})
                        return f"Error reading file: {str(e)}"

                if file_extension and file_extension.lower() == '.csv':
                    buffer.seek(0)
                    file_contents = buffer.read()
                    text_parts.append("[File: CSV]")

                    # Convert the buffer to a CSV reader
                    csv_reader = csv.reader(io.StringIO(file_contents.decode('utf-8')))

                    # Read all rows from the CSV
                    rows = list(csv_reader)

                    # Get the first 50 rows and join them as a string
                    first_50_rows = '\n'.join([', '.join(row) for row in rows[:50]])

                    # Get the last 50 rows and join them as a string
                    last_50_rows = '\n'.join([', '.join(row) for row in rows[-50:]])

                    # Append first and last 50 rows to text_parts
                    text_parts.append("[First 50 rows]")
                    text_parts.append(first_50_rows)

                    text_parts.append("[Last 50 rows]")
                    text_parts.append(last_50_rows)

                else:
                    buffer.seek(0)
                    try:
                        from xlsx2csv import Xlsx2csv
                        x2c = Xlsx2csv(buffer, outputencoding="utf-8")
                        x2c._guess_types = False
                        x2c._dateformat = None

                        sheet_names = x2c.workbook.sheets
                        if not sheet_names:
                            raise Exception("No sheets found in the Excel file.")

                        for idx, sheet in enumerate(sheet_names):
                            sheet_name = sheet['name']
                            csv_output = StringIO()
                            x2c.convert(csv_output, sheetid=idx + 1)
                            csv_output.seek(0)

                            df = pd.read_csv(csv_output, dtype=str, header=None, on_bad_lines='skip', engine='python')
                            text_parts.append(f"[Sheet: {sheet_name}]")
                            text_parts.extend(self._extract_non_empty_rows(df))
                    except Exception as x2c_error:
                        raise x2c_error

            except Exception as e:
                from openpyxl import load_workbook
                try:
                    buffer.seek(0)
                    wb = load_workbook(buffer, data_only=True, read_only=True)
                    for sheet_name in wb.sheetnames:
                        ws = wb[sheet_name]
                        rows = list(ws.iter_rows(values_only=True))
                        df = pd.DataFrame(rows)
                        text_parts.append(f"[Sheet: {sheet_name}]")
                        text_parts.extend(self._extract_non_empty_rows(df))
                except Exception as e:
                    try:
                        import xlrd
                        book = xlrd.open_workbook(file_contents=file_bytes)
                        for sheet in book.sheets():
                            rows = [sheet.row_values(i) for i in range(sheet.nrows)]
                            df = pd.DataFrame(rows)
                            text_parts.append(f"[Sheet: {sheet.name}]")
                            text_parts.extend(self._extract_non_empty_rows(df))
                    except Exception as e:
                        logger.error("Failed to read Excel file.", {"error": str(e)})
                        return "Error reading file: Unable to process the Excel file."

            return "\n".join(text_parts).strip()
        
        # Call the sync method that contains the process_excel function
        return process_excel()

    def _extract_non_empty_rows(self, df: pd.DataFrame, max_rows: int = 20) -> list[str]:
        def clean_rows(rows):
            lines = []
            for row in rows.itertuples(index=False):
                line = " ".join(str(cell).strip() for cell in row if pd.notna(cell) and str(cell).strip())
                if line:
                    lines.append(line)
            return lines

        # Memory optimization: Process smaller chunks and cleanup immediately
        first = clean_rows(df.head(25))[:max_rows]  # Reduced from 50 to 25
        last = clean_rows(df.tail(25))[-max_rows:]  # Reduced from 50 to 25
        
        # Explicit cleanup of DataFrame to free memory
        del df
        import gc
        gc.collect()
        
        return first + [line for line in last if line not in first]



class TxtProcessor(DocumentProcessor):
    async def process(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """Process text files using process pool for consistency."""
        return await asyncio.get_event_loop().run_in_executor(
            _process_pool,
            self._process_text_sync,
            file_bytes, password, file_extension
        )
    
    def _process_text_sync(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """Synchronous text processing - runs in separate process."""
        try:
            buffer = BytesIO(file_bytes)
            return buffer.read().decode("utf-8")
        except Exception as e:
            logger.error(f"Text processing failed: {e}")
            return "Failed to process text file."


class JSONProcessor(DocumentProcessor):
    @staticmethod
    def decrypt_data(encrypted_data: bytes, password: str) -> str:
        encrypted_string = encrypted_data.decode("utf-8")
        encoded_content = encrypted_string[64:]

        # Extract IV and salt from the encrypted string
        iv = binascii.unhexlify(encrypted_string[:32])
        salt = binascii.unhexlify(encrypted_string[32:64])

        # Extract the encrypted content
        encrypted = base64.b64decode(encoded_content)

        # Derive the encryption key using PBKDF2 with SHA-256
        key = PBKDF2(password, salt, dkLen=32, count=1000, prf=lambda p, s: hmac.new(p, s, sha256).digest())

        # Decrypt the data using AES (RijndaelManaged equivalent)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted_data = cipher.decrypt(encrypted)

        # Remove PKCS7 padding
        plain_text = unpad(decrypted_data, AES.block_size).decode("utf-8")
        return plain_text

    async def process(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """Process JSON files using process pool to avoid blocking event loop."""
        return await asyncio.get_event_loop().run_in_executor(
            _process_pool,
            self._process_json_sync,
            file_bytes, password, file_extension
        )
    
    def _process_json_sync(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """Synchronous JSON processing - runs in separate process."""
        try:
            file_content = file_bytes

            # Check if the content is encrypted (by detecting specific patterns)
            if JSONPasswordChecker.is_password_protected(self, file_content):
                decrypted_content = self.decrypt_data(file_content, password)
                json_data = json.loads(decrypted_content)
            else:
                json_data = json.loads(file_content.decode("utf-8"))

            return json.dumps(json_data, indent=4)
        except Exception as e:
            logger.error(f"JSON processing failed: {e}")
            return "Failed to process JSON file."


class ImageProcessor(DocumentProcessor):
    async def process(self, file_bytes: bytes, password: str = None, file_extension: str = None) -> str:
        """
        Image processor that returns a placeholder text for images.
        Images are meant to be processed directly by LLM vision capabilities.
        """
        return f"[IMAGE FILE: {file_extension}] - This image file should be processed directly by LLM vision capabilities."


class DocumentProcessorFactory:
    @staticmethod
    def get_processor(file_extension: str) -> DocumentProcessor:
        file_extension = file_extension.lower()
        if file_extension == '.pdf':
            return PDFProcessor()
        elif file_extension in ['.xls', '.xlsx', '.csv']:
            return ExcelProcessor()
        elif file_extension == '.json':
            return JSONProcessor()
        elif file_extension == '.txt':
            return TxtProcessor()
        elif file_extension in ['.jpg', '.jpeg', '.png', '.bmp']:
            return ImageProcessor()
        else:
            raise InvalidFileException(f"No processor available for the extension: {file_extension}")
    
    @staticmethod
    def supports_text_extraction(file_extension: str) -> bool:
        """
        Check if a file extension supports traditional text extraction.
        Returns False for image files that should go directly to LLM.
        """
        file_extension = file_extension.lower()
        return file_extension not in ['.jpg', '.jpeg', '.png', '.bmp']