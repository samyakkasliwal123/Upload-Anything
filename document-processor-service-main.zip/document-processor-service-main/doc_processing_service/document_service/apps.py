from django.apps import AppConfig


class DocumentServiceConfig(AppConfig):
    name = 'document_service'
