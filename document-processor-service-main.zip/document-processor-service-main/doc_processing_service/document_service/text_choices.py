from enum import Enum
from rest_framework.exceptions import ValidationError


class CustomEnum(Enum):
    @classmethod
    def choices(cls):
        # Ensure that choices() returns a list of tuples
        empty = [(None, cls.__empty__)] if hasattr(cls, "__empty__") else []
        return empty + [(member.name, member.value) for member in cls]

    @classmethod
    def validate(cls, value):
        try:
            # Attempt to create an enum instance with the provided value
            cls(value)
        except ValueError:
            raise ValidationError(f"Invalid {cls.__name__}: {value}")


class DocumentCategory(CustomEnum):
    DOC_FORM_16 = "doc_Form16"
    DOC_FORM_26_AS = "doc_Form26AS"
    DOC_ANNUAL_INFORMATION_STATEMENT = "doc_annual_Information_statement"
    DOC_HOME_LOAN_INTEREST_CERTIFICATE = "doc_home_loan_interest"
    DOC_EDUCATION_LOAN_INTEREST_CERTIFICATE = "doc_education_loan_interest"
    DOC_ADDITIONAL_DOC = "doc_additional_doc"
    DOC_CAPITAL_GAIN_STATEMENT = "doc_capital_gain_statement"
    DOC_VDA_STATEMENT = "doc_trade_report_from_exchange"
    SAVINGS_BANK_INTEREST = "savings_bank_interest"
    DOC_INVOICE_DISCOUNTING = "doc_InvoiceDiscounting"
    DOC_80_G = "doc_80_g"
    DOC_BONDS = "doc_Bonds"
    DOC_P2P = "doc_P2P"
    DOC_TAX_CHALLAN = 'doc_copy_of_tax_challan'
    DOC_SCHEDULE_FSI = 'ScheduleFsi'
    DOC_SCHEDULE_FA = 'doc_details_of_income_earned_outside_india'
    DOC_TRADING_ACCOUNT_STATEMENT = 'doc_trading_account_statement'
    DOC_ESOPS_RSUS = 'doc_RSUs_ESOPs'
    DOC_SCHEDULEAL = 'ScheduleAl'
    DOC_SCHEDULEAL1 = 'ScheduleAl1'
    DOC_SCHEDULEAL2 = 'ScheduleAl2'
    DOC_UNLISTED_SHARES = 'UnlistedShares'
    DOC_LIFE_INSURANCE_PREMIUM = 'doc_life_insurance_premium'
    DOC_ELSS_MUTUAL_FUND = 'doc_elss_mutual_fund'
    DOC_PPF_STATEMENT = 'doc_ppf_statement'
    DOC_ULIP_CERTIFICATE = 'doc_ulip_certificate'
    DOC_EPF_STATEMENT = 'doc_epf_statement'
    DOC_NSC_CERTIFICATE = 'doc_nsc_certificate'
    DOC_SUKANYA_SAMRIDHI = 'doc_sukanya_samridhi'
    DOC_NPS_STATEMENT = 'doc_nps_statement'
    DOC_MEDICAL_INSURANCE_POLICY = 'doc_medical_insurance'

class DocumentSubCategory(CustomEnum):
    NOT_INITIALIZED = "NotInitialized"
    CAMS = "CAMS"
    CLEARTAX = "ClearTax"
    GROWW = "Groww"
    ICICI = "ICICI"
    KARVY = "KARVY"
    PAYTM = "Paytm"
    SHAREKHAN = "Sharekhan"
    UPSTOX = "Upstox"
    ZERODHA = "Zerodha"
    HDFC = "HDFC"
    MOTILAL = "Motilal"
    RELIANCE = "Reliance"
    AXIS = "Axis"
    IDBI = "IDBI"
    SBI = "SBI"
    KOTAK = "Kotak"
    IIFL = "IIFL"
    RELIGARE = "Religare"
    ANANDRATHI = "AnandRathi"
    SMCGLOBAL = "SMCGlobal"
    GEOJIT = "Geojit"
    INDMONEY = "INDMoney"
    FYERS = "Fyers"
    ANGELONE = "AngelOne"
    VESTED = "Vested"
    FIVE_PAISA = "FivePaisa"
    CLEARTAXUSSTOCKS = "ClearTaxUsStocks"
    EDELWEISS = "Edelweiss"
    DHAN = "Dhan"
    GROWWUSSTOCKS = "GrowwUsStocks"
    INDMONEYMUTUALFUNDS = "IndMoneyMutualFunds"
    YESBANK = "YesBank"
    ALICE_BLUE = "AliceBlue"
    VENTURA = "Ventura"
    MASTERTRUST = "MasterTrust"
    FUNDSINDIA = "FundsIndia"
    WINTWEALTH = "WintWealth"
    ABML = "ABML"
    BAJAJ = "Bajaj"
    NUVAMA = "Nuvama"
    GULLAK = "Gullak"
    SAMCO = "Samco"
    NIRMALBANG = "NirmalBang"
    SHOONYA = "Shoonya"
    FINVASIA = "Finvasia"
    DHANISTOCKS = "DhaniStocks"
    LKPSECURITIES = "LkpSecurities"
    STOCKAL = "Stockal"
    INDIANX = "Indianx"
    CHOICEEQUITYBROKING = "ChoiceEquityBroking"
    HDFCSKY = "HdfcSky"
    SWASTIKAINVESTMART = "SwastikaInvestmart"
    PROFITMARTSECURITIES = "ProfitmartSecurities"
    TRADEBULLSSECURITIES = "TradebullsSecurities"
    GRIP = "Grip"
    BINANCE = "Binance"
    COINSWITCH = "Coinswitch"
    KOINLY = "Koinly"
    TAPINVEST = "TapInvest"
    INDIAP2P = "IndiaP2P"
    CREDMINT = "CredMint"
    TWELVEPERCENTCLUB = "TwelvePercentClub"
    LENDBOX = "Lendbox"
    FIDELITY = "Fidelity"



class Product(CustomEnum):
    ITR = "ITR"
