import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(override=True)

class Config:
    ANALYTICS_TABLE_ID = os.getenv('ANALYTICS_TABLE_ID')
    ANALYTICS_URL = os.getenv('ANALYTICS_URL')
    AUTH_SERVICE_BASEURL = os.getenv('AUTH_SERVICE_BASEURL')
    AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
    AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
    AWS_REGION = os.getenv('AWS_REGION')
    S3_BUCKET_NAME = os.getenv('S3_BUCKET_NAME')
    REDIS_HOST = os.getenv('REDIS_HOST')
    REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
    RABBITMQ_HOST = os.getenv('RABBITMQ_HOST')
    RABBITMQ_PORT = os.getenv('RABBITMQ_PORT')
    RABBITMQ_USERNAME = os.getenv('RABBITMQ_USER', 'guest')
    RABBITMQ_PASSWORD = os.getenv('RABBITMQ_PASSWORD', 'guest')
    USER_SERVICE_BASEURL = os.getenv('USER_SERVICE_BASEURL')
    USER_SERVICE_API_TOKEN = os.getenv('USER_SERVICE_API_TOKEN')
    PARSING_WORKER_TASK_QUEUE = os.getenv('PARSING_WORKER_TASK_QUEUE')
    NOTIFY_WORKER_TASK_QUEUE = os.getenv('NOTIFY_WORKER_TASK_QUEUE')
    ITR_SERVICE_BASEURL = os.getenv('ITR_SERVICE_BASEURL')
    ITR_DOCUMENT_STATUS_CACHE_PREFIX = os.getenv('ITR_DOCUMENT_STATUS_CACHE_PREFIX', 'DocumentParsingStatus_')
    OPENAPI_KEY = os.getenv('OPENAPI_KEY')
    PAYLOAD_ENCRYPTION_KEY = os.getenv('PAYLOAD_ENCRYPTION_KEY')
    PAYLOAD_KEY_ID = os.getenv('PAYLOAD_KEY_ID')
    CURRENT_ENVIRONMENT = os.getenv('CURRENT_ENVIRONMENT', 'development')
    ADMIN_USER_NAME = os.getenv('ADMIN_USER_NAME', 'admin')
    ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', 'admin@clear.in')
    ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')
    TEMPORAL_HOST = os.getenv('TEMPORAL_HOST', 'localhost')
    TEMPORAL_PORT = os.getenv('TEMPORAL_PORT', 7233)
    TEMPORAL_SERVICE_ADDRESS = f"{TEMPORAL_HOST}:{TEMPORAL_PORT}"
    TEMPORAL_NAMESPACE = os.getenv('TEMPORAL_NAMESPACE', 'default')

    
    # Temporal Worker Configuration - Memory optimized to match vault settings
    TEMPORAL_THREAD_POOL_SIZE = int(os.getenv('TEMPORAL_THREAD_POOL_SIZE', 25))  # Memory optimized: reduced from 100 to 25
    TEMPORAL_MAX_CONCURRENT_ACTIVITIES = int(os.getenv('TEMPORAL_MAX_CONCURRENT_ACTIVITIES', 10))  # Match vault setting
    TEMPORAL_MAX_CONCURRENT_WORKFLOWS = int(os.getenv('TEMPORAL_MAX_CONCURRENT_WORKFLOWS', 5))  # Match vault setting
    TEMPORAL_MAX_ACTIVITY_TASK_POLLS = int(os.getenv('TEMPORAL_MAX_ACTIVITY_TASK_POLLS', 10))  # Match vault setting
    TEMPORAL_MAX_WORKFLOW_TASK_POLLS = int(os.getenv('TEMPORAL_MAX_WORKFLOW_TASK_POLLS', 10))  # Match vault setting
    
    # S3 and Database Pool Configuration
    S3_CLIENT_POOL_SIZE = int(os.getenv('S3_CLIENT_POOL_SIZE', 30))  # Increased for better S3 handling
    DB_CONNECTION_POOL_BUFFER = int(os.getenv('DB_CONNECTION_POOL_BUFFER', 20))  # Reserve connections for web requests
