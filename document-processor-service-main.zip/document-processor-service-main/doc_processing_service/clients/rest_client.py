import logging
import httpx
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from time import time
from typing import Any, Dict, Optional


def _log_and_profile(func):
    """Decorator to log and profile API calls."""
    def wrapper(*args, **kwargs):
        start_time = time()
        try:
            result = func(*args, **kwargs)
            elapsed = time() - start_time
            logging.info(f"Call to {func.__name__} took {elapsed:.2f}s")
            return result
        except Exception as e:
            logging.error(f"Error in {func.__name__}: {str(e)}")
            raise

    return wrapper
class RestClientOptions:
    def __init__(self, user_agent="python-httpclient-base", timeout=15, request_id_header="X-Request-Id",
                 default_connection_limit=2000, extra_headers=None):
        self.user_agent = user_agent
        self.timeout = timeout
        self.request_id_header = request_id_header
        self.default_connection_limit = default_connection_limit
        self.extra_headers = extra_headers or {}

    @classmethod
    def build_with_defaults(cls):
        return cls()
class BaseRestClient:
    def __init__(self, base_url: str, options: RestClientOptions = None):
        self.base_url = base_url
        self.options = options or RestClientOptions.build_with_defaults()

        # Create a requests session
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': self.options.user_agent})

        # Set a retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        # Add any extra headers
        for key, value in self.options.extra_headers.items():
            self.session.headers[key] = value


    def perform_api_call(self, method: str, endpoint: str, payload: Optional[Any] = None,
                         headers: Optional[Dict[str, str]] = None,
                         params: Optional[Dict[str, str]] = None) -> requests.Response:
        url = f"{self.base_url}{endpoint}"
        headers = headers or {}
        try:
            # Make the HTTP request
            response = self.session.request(method=method, url=url, json=payload, headers=headers, params=params,
                                            timeout=self.options.timeout)
            response.raise_for_status()  # Raise an error for bad responses
            return response
        except requests.RequestException as e:
            logging.error(f"Request failed for {url} with error: {str(e)}")
            raise

    @_log_and_profile
    def do_get(self, endpoint: str, params: Optional[Dict[str, str]] = None,headers: Optional[Dict[str, str]] = None) -> requests.Response:
        return self.perform_api_call("GET", endpoint, params=params,headers=headers)

    @_log_and_profile
    def do_post(self, endpoint: str, payload: Any, headers: Optional[Dict[str, str]] = None) -> requests.Response:
        return self.perform_api_call("POST", endpoint, payload=payload, headers=headers)

    @_log_and_profile
    def do_put(self, endpoint: str, payload: Any, headers: Optional[Dict[str, str]] = None) -> requests.Response:
        return self.perform_api_call("PUT", endpoint, payload=payload, headers=headers)

    @_log_and_profile
    def do_delete(self, endpoint: str, headers: Optional[Dict[str, str]] = None) -> requests.Response:
        return self.perform_api_call("DELETE", endpoint, headers=headers)

class AsyncBaseRestClient:
    def __init__(self, base_url: str, options: RestClientOptions = None):
        self.base_url = base_url
        self.options = options or RestClientOptions.build_with_defaults()

        # Create a shared httpx.AsyncClient
        self.session = httpx.AsyncClient(
            headers={"User-Agent": self.options.user_agent, **self.options.extra_headers},
            timeout=httpx.Timeout(self.options.timeout),
        )

    async def perform_api_call(
        self,
        method: str,
        endpoint: str,
        payload: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        url = f"{self.base_url}{endpoint}"
        headers = headers or {}

        try:
            response = await self.session.request(
                method=method, url=url, json=payload, headers=headers, params=params
            )
            response.raise_for_status()  # Raise for non-2xx status codes
            return response # Automatically parse JSON responses
        except httpx.HTTPStatusError as e:
            logging.error(f"HTTP error {e.response.status_code} for {url}: {e.response.text}")
            raise
        except Exception as e:
            logging.error(f"Request failed for {url}: {str(e)}")
            raise

    @_log_and_profile
    async def do_get(
        self, endpoint: str, params: Optional[Dict[str, str]] = None, headers: Optional[Dict[str, str]] = None
    ) -> Any:
        return await self.perform_api_call("GET", endpoint, params=params, headers=headers)

    @_log_and_profile
    async def do_post(
        self, endpoint: str, payload: Any, headers: Optional[Dict[str, str]] = None
    ) -> Any:
        return await self.perform_api_call("POST", endpoint, payload=payload, headers=headers)

    @_log_and_profile
    async def do_put(
        self, endpoint: str, payload: Any, headers: Optional[Dict[str, str]] = None
    ) -> Any:
        return await self.perform_api_call("PUT", endpoint, payload=payload, headers=headers)

    @_log_and_profile
    async def do_delete(
        self, endpoint: str, headers: Optional[Dict[str, str]] = None
    ) -> Any:
        return await self.perform_api_call("DELETE", endpoint, headers=headers)

    async def close(self):
        """Closes the httpx.AsyncClient."""
        await self.session.aclose()

