# doc_processing_service/authentication.py
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from document_service.models import User
from services.user_authentication_service import UserServiceHttpClient
from configuration import Config

class SessionIDAuthentication(BaseAuthentication):
    def authenticate(self, request) -> tuple[User, None]:
        session_id = request.COOKIES.get('sid')
        if not session_id:
            return None,None

        user_service = UserServiceHttpClient(Config.USER_SERVICE_BASEURL, Config.USER_SERVICE_API_TOKEN)
        user_info = user_service.get_user_from_session_id(session_id)

        if not user_info:
            raise AuthenticationFailed('Invalid session ID')

        return user_info,None