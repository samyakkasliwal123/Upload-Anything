import boto3
from botocore.config import Config as BotoConfig
from threading import Lock
import queue
import logging
from configuration import Config

logger = logging.getLogger(__name__)

class S3ClientPool:
    """
    Thread-safe S3 client pool to avoid connection overhead.
    Maintains a pool of pre-created S3 clients for reuse.
    """
    _instance = None
    _lock = Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        # Use configurable pool size with fallback
        self.pool_size = getattr(Config, 'S3_CLIENT_POOL_SIZE', 30)
        self.pool = queue.Queue(maxsize=self.pool_size)
        self._lock = Lock()
        
        # Pre-create clients with optimized configuration
        for _ in range(self.pool_size):
            client = self._create_client()
            self.pool.put(client)
        
        self._initialized = True
        logger.info(f"S3ClientPool initialized with {self.pool_size} clients")
    
    def _create_client(self):
        """Create a new S3 client with optimized configuration and transfer acceleration."""
        # Build configuration with transfer acceleration support
        config_params = {
            'max_pool_connections': 50,
            'retries': {
                'max_attempts': 3,
                'mode': 'adaptive'
            },
            'region_name': Config.AWS_REGION,
            # Enable connection reuse
            'tcp_keepalive': True,
            # Reduce connection timeout
            'connect_timeout': 5,
            'read_timeout': 10
        }
        
        # Enable transfer acceleration in production environment (matching aws_utils.py)
        if Config.CURRENT_ENVIRONMENT.lower() == "production":
            config_params['s3'] = {
                'use_accelerate_endpoint': True
            }
            logger.info("S3 Transfer Acceleration enabled for production environment")
        else:
            logger.debug(f"S3 Transfer Acceleration disabled for {Config.CURRENT_ENVIRONMENT} environment")
        
        return boto3.client(
            "s3",
            region_name=Config.AWS_REGION,
            aws_access_key_id=Config.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=Config.AWS_SECRET_ACCESS_KEY,
            config=BotoConfig(**config_params)
        )
    
    def get_client(self, timeout=5):
        """
        Get an S3 client from the pool.
        
        Args:
            timeout: Maximum time to wait for a client (seconds)
            
        Returns:
            boto3.client: S3 client instance
            
        Raises:
            queue.Empty: If no client is available within timeout
        """
        try:
            return self.pool.get(timeout=timeout)
        except queue.Empty:
            logger.warning(f"S3 client pool exhausted (pool size: {self.pool_size}), creating overflow client")
            # If pool is exhausted, create a new client with same configuration
            # This ensures consistent transfer acceleration settings
            return self._create_client()
    
    def return_client(self, client):
        """
        Return an S3 client to the pool.
        
        Args:
            client: S3 client to return to pool
        """
        try:
            # Only return to pool if there's space
            self.pool.put_nowait(client)
        except queue.Full:
            # Pool is full, let the client be garbage collected
            logger.debug("S3 client pool full, discarding client")
            pass
    
    def get_pool_size(self):
        """Get current number of available clients in pool."""
        return self.pool.qsize()
    
    def health_check(self):
        """Perform a health check on the pool."""
        available_clients = self.pool.qsize()
        logger.info(f"S3ClientPool health: {available_clients}/{self.pool_size} clients available")
        return {
            'available_clients': available_clients,
            'total_pool_size': self.pool_size,
            'pool_utilization': (self.pool_size - available_clients) / self.pool_size
        }

# Singleton instance
s3_client_pool = S3ClientPool()