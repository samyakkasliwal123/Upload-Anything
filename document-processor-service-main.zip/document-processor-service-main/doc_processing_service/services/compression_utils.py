import json
import asyncio
from gzip import compress
from typing import Any, Union


class CompressionService:
    """Utility class for handling data compression operations."""
    
    COMPRESSION_THRESHOLD = 1024  # Only compress if data is larger than 1KB
    
    @classmethod
    async def compress_data_async(cls, data: Any) -> bytes:
        """
        Compress data asynchronously. Only compresses if data size exceeds threshold.
        
        Args:
            data: Data to compress (will be JSON serialized)
            
        Returns:
            Compressed bytes or raw JSON bytes if below threshold
        """
        json_data = json.dumps(data)
        data_size = len(json_data.encode('utf-8'))
        
        if data_size > cls.COMPRESSION_THRESHOLD:
            # Use thread pool for compression to avoid blocking event loop
            return await asyncio.to_thread(
                lambda: compress(json_data.encode('utf-8'))
            )
        else:
            # For small data, compression overhead isn't worth it
            return json_data.encode('utf-8')
    
    @classmethod
    def compress_data_sync(cls, data: Any) -> bytes:
        """
        Compress data synchronously. Only compresses if data size exceeds threshold.
        
        Args:
            data: Data to compress (will be JSON serialized)
            
        Returns:
            Compressed bytes or raw JSON bytes if below threshold
        """
        json_data = json.dumps(data)
        data_size = len(json_data.encode('utf-8'))
        
        if data_size > cls.COMPRESSION_THRESHOLD:
            return compress(json_data.encode('utf-8'))
        else:
            return json_data.encode('utf-8')
    
    @classmethod
    async def decompress_data_async(cls, data: bytes) -> str:
        """
        Decompress data asynchronously. Handles both compressed and uncompressed data.
        
        Args:
            data: Data to decompress
            
        Returns:
            Decompressed string data
        """
        if not data:
            return ""
            
        try:
            # Try to decompress first (for data that was compressed)
            from gzip import decompress
            return await asyncio.to_thread(lambda: decompress(data).decode('utf-8'))
        except:
            # If decompression fails, assume it's raw JSON data
            try:
                return data.decode('utf-8')
            except:
                return ""
    
    @classmethod
    def decompress_data_sync(cls, data: bytes) -> str:
        """
        Decompress data synchronously. Handles both compressed and uncompressed data.
        
        Args:
            data: Data to decompress
            
        Returns:
            Decompressed string data
        """
        if not data:
            return ""
            
        try:
            # Try to decompress first (for data that was compressed)
            from gzip import decompress
            return decompress(data).decode('utf-8')
        except:
            # If decompression fails, assume it's raw JSON data
            try:
                return data.decode('utf-8')
            except:
                return ""