from typing import Optional
import asyncio

import aioboto3
from botocore.config import Config as S3Config
from configuration import Config
from services.s3_service import S3Service
from services.s3_client_pool import s3_client_pool
from contextlib import asynccontextmanager
import logging

@asynccontextmanager
async def get_s3_client():
    session = aioboto3.Session()
    s3_config = S3Config(
        s3={"use_accelerate_endpoint": Config.CURRENT_ENVIRONMENT.lower() == "production"}
    )
    client = await session.client(
        "s3",
        region_name=Config.AWS_REGION,
        aws_access_key_id=Config.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=Config.AWS_SECRET_ACCESS_KEY,
        config=s3_config
    ).__aenter__()
    try:
        yield client
    finally:
        await client.__aexit__(None, None, None)# This is the actual S3 client, now inside async context.

async def download_file(s3_key: str, workflow_id="") -> bytes:
    """
    Optimized file download with latency monitoring.
    """
    import time
    start_time = time.perf_counter()
    
    # Try pooled sync client first (avoids connection overhead)
    s3_client = None
    try:
        s3_client = s3_client_pool.get_client(timeout=0.5)
        s3_service = S3Service(s3_client)
        # Use sync method in thread pool to avoid blocking event loop
        result = await asyncio.to_thread(
            s3_service.download_file_bytes_sync,
            s3_key,
            Config.S3_BUCKET_NAME,
            workflow_id
        )
        
        duration = time.perf_counter() - start_time
        if duration > 2.0:
            logging.error(f"SLOW S3 DOWNLOAD: {s3_key} took {duration:.2f}s (workflow: {workflow_id})")
        
        return result
        
    except Exception as pool_error:
        logging.warning(f"Pooled S3 client failed, using async client: {pool_error}")
        # Fallback to async client (creates new connection)
        try:
            async with get_s3_client() as async_s3_client:
                s3_service = S3Service(async_s3_client)
                result = await s3_service.download_file_bytes(s3_key, Config.S3_BUCKET_NAME, workflow_id=workflow_id)
                
                duration = time.perf_counter() - start_time
                if duration > 2.0:
                    logging.error(f"SLOW S3 DOWNLOAD (fallback): {s3_key} took {duration:.2f}s (workflow: {workflow_id})")
                
                return result
        except Exception as e:
            duration = time.perf_counter() - start_time
            logging.error(f"Failed to download file from S3 after {duration:.2f}s: {e}")
            return b""
    finally:
        if s3_client:
            s3_client_pool.return_client(s3_client)


async def upload_file(file_bytes: bytes, s3_key: str) -> bool:
    try:
        async with get_s3_client() as s3_client:
            s3_service = S3Service(s3_client)
            return await s3_service.upload_file_bytes(file_bytes, s3_key, Config.S3_BUCKET_NAME)
    except Exception as e:
        logging.error(f"Failed to upload file to S3: {e}")
        return False
    # Note: s3_client is automatically closed by the context manager

def upload_file_stream(file_stream, s3_key: str) -> bool:
    """
    Upload file stream to S3 using pooled client for better performance.
    """
    s3_client = None
    try:
        s3_client = s3_client_pool.get_client()
        s3_service = S3Service(s3_client)
        return s3_service.upload_file_stream(file_stream, s3_key, Config.S3_BUCKET_NAME)
    except Exception as e:
        logging.error(f"Failed to upload file stream to S3: {e}")
        return False
    finally:
        if s3_client:
            s3_client_pool.return_client(s3_client)

async def get_presigned_url(s3_key: str) -> str:
    try:
        async with get_s3_client() as s3_client:
            s3_service = S3Service(s3_client)
            return await s3_service.get_presigned_s3_url(Config.S3_BUCKET_NAME, s3_key)
    except Exception as e:
        logging.error(f"Failed to generate presigned URL: {e}")
        return ""
    # Note: s3_client is automatically closed by the context manager