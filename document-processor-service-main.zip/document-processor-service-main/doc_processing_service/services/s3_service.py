import io
import logging
from typing import Optional

from botocore.exceptions import BotoCoreError, ClientError
from doc_processing_service.services.metrics.latency_tracker import LatencyTracker
from doc_processing_service.temporal_service.utils.metrics.decorator import temporal_metric


class S3Service:
    def __init__(self, s3_client):
        """
        Initialize the S3 service with a provided S3 client instance.
        :param s3_client: An initialized aioboto3 S3 client.
        """
        self.s3_client = s3_client
        self.logger = logging.getLogger(__name__)
        self.tracker = LatencyTracker("s3")

    async def upload_file_bytes(self, file_bytes: bytes, s3_key: str, bucket_name: str) -> bool:
        try:
            with self.tracker.track_async("upload_file_bytes"):
                file_obj = io.BytesIO(file_bytes)
                await self.s3_client.upload_fileobj(file_obj, bucket_name, s3_key)
                self.logger.info(f"File uploaded successfully to {bucket_name}/{s3_key}")
                return True
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to upload file to S3: {e}")
            return False

    def upload_file_stream(self, file_stream, s3_key: str, bucket_name: str) -> bool:
        try:
            with self.tracker.track("upload_file_stream"):
                self.s3_client.upload_fileobj(file_stream, bucket_name, s3_key)
                self.logger.info(f"File stream uploaded successfully to {bucket_name}/{s3_key}")
                return True
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to upload file stream to S3: {e}")
            return False

    @temporal_metric("s3.download_file_bytes", "Download file bytes from S3")
    async def download_file_bytes(self, s3_key: str, bucket_name: str, workflow_id: Optional[str]) -> bytes:
        try:
            file_obj = io.BytesIO()
            await self.s3_client.download_fileobj(bucket_name, s3_key, file_obj)
            self.logger.info(f"File downloaded successfully from {bucket_name}/{s3_key} for workflow {workflow_id}")
            file_obj.seek(0)
            return file_obj.read()
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to download file from S3: {e}")
            return b""

    @temporal_metric("s3.download_file_bytes_sync", "Download file bytes from S3 (sync)")
    def download_file_bytes_sync(self, s3_key: str, bucket_name: str, workflow_id: Optional[str]) -> bytes:
        try:
            file_obj = io.BytesIO()
            self.s3_client.download_fileobj(bucket_name, s3_key, file_obj)
            self.logger.info(f"File downloaded successfully from {bucket_name}/{s3_key} for workflow {workflow_id}")
            file_obj.seek(0)
            return file_obj.read()
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to download file from S3: {e}")
            return b""

    async def get_presigned_s3_url(self, bucket_name: str, s3_key: str) -> str:
        try:
            with self.tracker.track_async("get_presigned_s3_url"):
                url = await self.s3_client.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': bucket_name, 'Key': s3_key},
                    ExpiresIn=180,
                    HttpMethod='GET'
                )
                return url
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to generate presigned URL: {e}")
            return ""

    def generate_presigned_url_sync(self, bucket_name: str, s3_key: str) -> str:
        """Generate presigned URL synchronously to avoid event loop blocking."""
        try:
            with self.tracker.track("generate_presigned_url_sync"):
                url = self.s3_client.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': bucket_name, 'Key': s3_key},
                    ExpiresIn=180,
                    HttpMethod='GET'
                )
                return url
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to generate presigned URL: {e}")
            return ""

    async def delete_file(self, s3_key: str, bucket_name: str) -> bool:
        try:
            with self.tracker.track_async("delete_file"):
                await self.s3_client.delete_object(Bucket=bucket_name, Key=s3_key)
                self.logger.info(f"File deleted successfully from {bucket_name}/{s3_key}")
                return True
        except (BotoCoreError, ClientError) as e:
            self.logger.error(f"Failed to delete file from S3: {e}")
            return False