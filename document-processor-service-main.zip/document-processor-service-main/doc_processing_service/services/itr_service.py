import json
import logging
from typing import Optional
from clients.rest_client import BaseRestClient, RestClientOptions
from document_service.models import Document


class ItrServiceHttpClient(BaseRestClient):

    def __init__(self, base_url: str):
        options = RestClientOptions.build_with_defaults()
        options.timeout = 10
        super().__init__(base_url, options)

    async def notify_document_processing_status(self, document: Document) -> Optional[int]:
        if not document:
            raise ValueError("document cannot be null")

        headers = {"Content-Type": "application/json"}
        payload = {
            "document_id": str(document.document_id),
            "document_name": document.document_name,
            "scope_id": document.scope,
            "document_category": document.document_type_value,
            "document_s3_url": document.s3_url,
            "document_password": document.password,
            "document_data": json.dumps(document.extracted_data),
            "user_external_id": str(document.user_id)
        }

        response = self.do_post("/external/entities/documents", payload, headers)

        if response is None:
            logging.error("Network error in connecting to ITR Service")
            return None

        try:
            if response.ok:
                return response.json().get("reportId", "")
            else:
                logging.error(f"ITR service error status code: {response.status_code}")
                return None
        except json.JSONDecodeError:
            logging.error(f"Failed to parse JSON response: {response.text}")
            return None