import asyncio
import time
import logging
import psutil
import os
from typing import Dict, List
from dataclasses import dataclass
from collections import deque

logger = logging.getLogger(__name__)

@dataclass
class EventLoopMetrics:
    avg_lag_ms: float
    max_lag_ms: float
    cpu_percent: float
    memory_percent: float
    active_tasks: int
    pending_tasks: int
    timestamp: float

class EventLoopHealthMonitor:
    """
    Monitors event loop health and system resources to detect performance issues.
    """
    
    def __init__(self, sample_window: int = 60, check_interval: float = 1.0):
        self.sample_window = sample_window
        self.check_interval = check_interval
        self.lag_samples: deque = deque(maxlen=sample_window)
        self.metrics_history: deque = deque(maxlen=sample_window)
        self.process = psutil.Process(os.getpid())
        self.is_monitoring = False
        
        # Thresholds
        self.lag_warning_threshold = 50.0  # ms
        self.lag_critical_threshold = 100.0  # ms
        self.cpu_warning_threshold = 70.0  # %
        self.cpu_critical_threshold = 85.0  # %
        self.memory_warning_threshold = 80.0  # %
        self.memory_critical_threshold = 90.0  # %
    
    async def start_monitoring(self):
        """Start the event loop monitoring task."""
        if self.is_monitoring:
            logger.warning("Event loop monitoring is already running")
            return
        
        self.is_monitoring = True
        logger.info("Starting event loop health monitoring")
        asyncio.create_task(self._monitor_loop())
    
    def stop_monitoring(self):
        """Stop the event loop monitoring."""
        self.is_monitoring = False
        logger.info("Stopped event loop health monitoring")
    
    async def _monitor_loop(self):
        """Main monitoring loop that runs continuously."""
        while self.is_monitoring:
            try:
                await self._collect_metrics()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"Error in event loop monitoring: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _collect_metrics(self):
        """Collect event loop and system metrics."""
        # Measure event loop lag
        start_time = time.perf_counter()
        await asyncio.sleep(0.001)  # Minimal sleep to yield control
        actual_sleep = time.perf_counter() - start_time
        lag_ms = max(0, (actual_sleep - 0.001) * 1000)
        
        self.lag_samples.append(lag_ms)
        
        # Get system metrics - normalize CPU to container limits
        raw_cpu_percent = self.process.cpu_percent()
        # Normalize to container CPU limits (assuming 2-4 CPU cores available)
        cpu_cores_available = psutil.cpu_count()
        cpu_percent = raw_cpu_percent / cpu_cores_available if cpu_cores_available > 1 else raw_cpu_percent
        
        memory_info = self.process.memory_info()
        memory_percent = (memory_info.rss / psutil.virtual_memory().total) * 100
        
        # Get asyncio task metrics
        loop = asyncio.get_running_loop()
        all_tasks = asyncio.all_tasks(loop)
        active_tasks = len([t for t in all_tasks if not t.done()])
        pending_tasks = len([t for t in all_tasks if not t.done() and not t.cancelled()])
        
        # Calculate averages
        avg_lag_ms = sum(self.lag_samples) / len(self.lag_samples) if self.lag_samples else 0
        max_lag_ms = max(self.lag_samples) if self.lag_samples else 0
        
        # Create metrics object
        metrics = EventLoopMetrics(
            avg_lag_ms=avg_lag_ms,
            max_lag_ms=max_lag_ms,
            cpu_percent=cpu_percent,
            memory_percent=memory_percent,
            active_tasks=active_tasks,
            pending_tasks=pending_tasks,
            timestamp=time.time()
        )
        
        self.metrics_history.append(metrics)
        
        # Check thresholds and log warnings
        self._check_thresholds(metrics)
        
        # Log periodic health summary less frequently
        if len(self.metrics_history) % 300 == 0:  # Every 5 minutes instead of 30 seconds
            self._log_health_summary(metrics)
    
    def _check_thresholds(self, metrics: EventLoopMetrics):
        """Check if any metrics exceed warning/critical thresholds."""
        
        # Only log critical issues to reduce noise
        # Event loop lag checks
        if metrics.avg_lag_ms > self.lag_critical_threshold:
            logger.error(
                f"CRITICAL: Event loop lag {metrics.avg_lag_ms:.1f}ms "
                f"(max: {metrics.max_lag_ms:.1f}ms). Consider reducing concurrency!"
            )
        
        # CPU usage checks - only log critical
        if metrics.cpu_percent > self.cpu_critical_threshold:
            logger.error(f"CRITICAL: CPU usage {metrics.cpu_percent:.1f}%. Reduce load!")
        
        # Memory usage checks - only log critical
        if metrics.memory_percent > self.memory_critical_threshold:
            logger.error(f"CRITICAL: Memory usage {metrics.memory_percent:.1f}%. Check for leaks!")
        
        # Task count checks - only log if very high
        if metrics.active_tasks > 2000:
            logger.warning(f"HIGH: {metrics.active_tasks} active tasks. Possible task accumulation.")
    
    def _log_health_summary(self, metrics: EventLoopMetrics):
        """Log a periodic health summary."""
        logger.info(
            f"Event Loop Health - "
            f"Lag: {metrics.avg_lag_ms:.1f}ms avg, {metrics.max_lag_ms:.1f}ms max | "
            f"CPU: {metrics.cpu_percent:.1f}% | "
            f"Memory: {metrics.memory_percent:.1f}% | "
            f"Tasks: {metrics.active_tasks} active, {metrics.pending_tasks} pending"
        )
    
    def get_current_metrics(self) -> EventLoopMetrics:
        """Get the most recent metrics."""
        if not self.metrics_history:
            return EventLoopMetrics(0, 0, 0, 0, 0, 0, time.time())
        return self.metrics_history[-1]
    
    def get_health_status(self) -> Dict[str, str]:
        """Get overall health status."""
        if not self.metrics_history:
            return {"status": "unknown", "message": "No metrics available"}
        
        metrics = self.metrics_history[-1]
        
        # Determine overall status
        if (metrics.avg_lag_ms > self.lag_critical_threshold or 
            metrics.cpu_percent > self.cpu_critical_threshold or 
            metrics.memory_percent > self.memory_critical_threshold):
            return {
                "status": "critical",
                "message": "System is under critical load. Reduce concurrency immediately."
            }
        elif (metrics.avg_lag_ms > self.lag_warning_threshold or 
              metrics.cpu_percent > self.cpu_warning_threshold or 
              metrics.memory_percent > self.memory_warning_threshold):
            return {
                "status": "warning", 
                "message": "System is under high load. Monitor closely before increasing concurrency."
            }
        else:
            return {
                "status": "healthy",
                "message": "System is operating within normal parameters."
            }
    
    def get_metrics_summary(self, minutes: int = 5) -> Dict:
        """Get metrics summary for the last N minutes."""
        if not self.metrics_history:
            return {}
        
        cutoff_time = time.time() - (minutes * 60)
        recent_metrics = [m for m in self.metrics_history if m.timestamp > cutoff_time]
        
        if not recent_metrics:
            return {}
        
        return {
            "time_window_minutes": minutes,
            "sample_count": len(recent_metrics),
            "avg_lag_ms": sum(m.avg_lag_ms for m in recent_metrics) / len(recent_metrics),
            "max_lag_ms": max(m.max_lag_ms for m in recent_metrics),
            "avg_cpu_percent": sum(m.cpu_percent for m in recent_metrics) / len(recent_metrics),
            "max_cpu_percent": max(m.cpu_percent for m in recent_metrics),
            "avg_memory_percent": sum(m.memory_percent for m in recent_metrics) / len(recent_metrics),
            "max_memory_percent": max(m.memory_percent for m in recent_metrics),
            "avg_active_tasks": sum(m.active_tasks for m in recent_metrics) / len(recent_metrics),
            "max_active_tasks": max(m.active_tasks for m in recent_metrics),
        }

# Global monitor instance
event_loop_monitor = EventLoopHealthMonitor()