import logging
from typing import Optional
from services.redis_service import redis_client


class RedisKeyUtils:
    """Utility class for Redis key management with namespace wrapping."""
    
    SESSION_NAMESPACE_KEY = "SessionNamespaceVersion"
    
    @staticmethod
    async def wrap_key(key: str) -> str:
        """
        Wrap a key with the current namespace.
        Equivalent to C# Keys.WrapKey(key)
        """
        namespace = await RedisKeyUtils.get_current_namespace()
        return f"{namespace}:{key}"
    
    @staticmethod
    async def get_current_namespace() -> str:
        """
        Get the current session namespace.
        Equivalent to C# RedisUtil.GetCurrentNamespace()
        """
        try:
            version = await redis_client.get(RedisKeyUtils.SESSION_NAMESPACE_KEY)
            if version is None:
                # If no version exists, initialize with 1
                version = "1"
                await redis_client.set_with_expiry(RedisKeyUtils.SESSION_NAMESPACE_KEY, version, 86400)  # 24 hours
                logging.info(f"Initialized session namespace version: {version}")
            
            return f"Session:{version}"
        except Exception as e:
            logging.error(f"Failed to get current namespace: {e}")
            # Fallback to default namespace
            return "Session:1"
    
    @staticmethod
    async def entity_user_key(entity_id: str) -> str:
        """
        Generate wrapped EntityUser key.
        """
        key = f"EUser:{entity_id}"
        return await RedisKeyUtils.wrap_key(key)
    
    @staticmethod
    async def authorization_workspace_key(user_external_id: str) -> str:
        """
        Generate wrapped AuthorizationWorkspace key.
        """
        key = f"WorkspaceId:{user_external_id}"
        return await RedisKeyUtils.wrap_key(key)