import ast
import asyncio
import json
import logging
import re
import sentry_sdk
from typing import Optional
from aiohttp import ClientResponseError
from rest_framework.exceptions import PermissionDenied
from clients.rest_client import BaseRestClient, RestClientOptions, AsyncBaseRestClient
from document_service.models import UserPermissions, FetchWorkSpaceResponse, CachedUserDetails


class AuthorizationService(AsyncBaseRestClient):
    AuthHeader = "sid"
    WorkSpaceHeader = "x-workspace-id"
    CleartaxProductHeader = "x-cleartax-product"
    UserExternalIdHeader = "x-cleartax-user"

    def __init__(self, base_url: str):
        options = RestClientOptions.build_with_defaults()
        super().__init__(base_url, options)

    async def get_auth_permissions_v2(
        self, session_id: str, resource: str, scope: str, logged_in_user_id: str
    ) -> Optional[UserPermissions]:
        """
        Fetch user permissions for a specific resource and scope.
        """
        try:
            request_url = "/v0/users/internal/resource-scope-permissions"
            
            workspace_id = await self._get_workspace_id_with_cache(scope, logged_in_user_id, session_id)

            if not workspace_id:
                logging.error(f"[WORKSPACE DEBUG] No workspace ID found for user: {logged_in_user_id}, scope: {scope}")
                raise PermissionDenied("Workspace not found for user.")

            headers = {
                "Cookie": f"{self.AuthHeader}={session_id}",
                self.WorkSpaceHeader: workspace_id,
                self.CleartaxProductHeader: "CONSUMER_ITR",
                self.UserExternalIdHeader: str(logged_in_user_id),
            }
            query_params = {"resource": resource, "scopeId": scope}

            response = await self.do_get(request_url, params=query_params, headers=headers)

            if response.status_code != 200:
                error_body = response.json()
                logging.error(
                    f"Authorization Error: Bad response from Auth service. "
                    f"Status: {response.status}, Response: {error_body}"
                )
                return None

            response_json =response.json()

            if not response_json or not response_json[0]:
                logging.error(f"Authorization Error: No permissions found for user: {logged_in_user_id}")
                raise PermissionDenied("User does not have required permissions to access this resource.")

            return UserPermissions.model_validate(response_json[0])

        except ClientResponseError as e:
            logging.error(
                f"Authorization Error: HTTP ClientResponseError for user {logged_in_user_id}. "
                f"Message: {e.message}, Status: {e.status}, URL: {e.request_info.url}"
            )
            return None
        except asyncio.CancelledError:
            logging.error("Authorization Error: Request was cancelled.")
            raise  # Allow cancellation to propagate
        except Exception as e:
            logging.error(f"Authorization Error: Unexpected exception occurred: {str(e)}")
            return None

    @staticmethod
    def jsv_to_dict(jsv_str: str) -> dict:
        # Quote keys
        s = re.sub(r'([{,])(\s*)(\w+)(\s*):', r'\1"\3":', jsv_str)
        # Quote string values (unless already quoted or nested)
        s = re.sub(r':(?!\s*[{"])([\w@.\-]+)', r':"\1"', s)
        return ast.literal_eval(s)

    async def get_workspace_id_for_user(self, logged_in_user_id: str, session_id: str) -> Optional[str]:
        """
        Retrieve the workspace ID for a user associated with the CONSUMER_ITR product.
        """

        try:
            workspaces = await self.fetch_workspaces(session_id, logged_in_user_id)
            if workspaces and workspaces.workspaces:
                workspace = next(
                    (
                        ws.workspaceNode
                        for ws in workspaces.workspaces
                        if "CONSUMER_ITR" in ws.workspaceNode.productAssociated
                    ),
                    None,
                )
                if workspace:
                    return workspace.id
                else:
                    logging.warning(f"[WORKSPACE DEBUG] No CONSUMER_ITR workspace found for user {logged_in_user_id}")
            else:
                logging.warning(f"[WORKSPACE DEBUG] No workspaces returned for user {logged_in_user_id}")
                
            logging.warning(f"No valid workspace found for user {logged_in_user_id}.")
            return None

        except Exception as e:
            logging.error(f"Failed to fetch workspace ID for user {logged_in_user_id}: {str(e)}")
            return None

    async def _get_workspace_id_with_cache(self, scope: str, logged_in_user_id: str, session_id: str) -> Optional[str]:
        """
        Get workspace ID using cache-first approach with entity ID from scope.
        Scope format: shortGuid_Year
        """
        from services.redis_service import redis_client
        from services.redis_key_utils import RedisKeyUtils
        from document_service.helpers.shortuuid_utils import shortguid_to_string

        try:
            # Step 1: Extract entity ID from scope (scope format: shortGuid_Year)
            if scope and '_' in scope:
                entity_id = shortguid_to_string(scope.rsplit('_', 1)[0])
                # Step 2: Try to get user details from cache using EntityUser pattern with proper key wrapping
                entity_user_key = await RedisKeyUtils.entity_user_key(entity_id)
                cached_user_details = await redis_client.get(entity_user_key)

                if cached_user_details:
                    try:
                        # Parse the cached data - handle both JSON and JavaScript object notation
                        import json
                        import re
                        
                        user_details = self.jsv_to_dict(cached_user_details)
                        # Use the CachedUserDetails model to validate the parsed data
                        user_details = CachedUserDetails.model_validate(user_details)

                        if (user_details.username and
                            user_details.userId and
                            user_details.userId != '00000000-0000-0000-0000-000000000000'):
                            
                            # Step 3: Try to get workspace ID from cache using AuthorizationWorkspace pattern with proper key wrapping
                            workspace_cache_key = await RedisKeyUtils.authorization_workspace_key(user_details.userId)

                            cached_workspace_id = await redis_client.get(workspace_cache_key)
                            if cached_workspace_id:
                                return cached_workspace_id
                        else:
                            logging.warning(f"[WORKSPACE DEBUG] Invalid user details for entity {entity_id}")
                                
                    except Exception as e:
                        sentry_sdk.capture_exception(e)
                        logging.warning(f"[WORKSPACE DEBUG] Failed to parse cached user details for entity {entity_id}: {e}")
            
            # Step 4: Fallback to existing method
            return await self.get_workspace_id_for_user(logged_in_user_id, session_id)
            
        except Exception as e:
            
            logging.error(f"Error in cache-based workspace lookup: {e}")
            # Fallback to existing
            sentry_sdk.capture_exception(e)
            return await self.get_workspace_id_for_user(logged_in_user_id, session_id)

    async def fetch_workspaces(self, session_id: str, entity_user_id: str) -> Optional[FetchWorkSpaceResponse]:
        """
        Fetch all workspaces associated with a user.
        """
        try:
            request_url = f"/api/internal/{entity_user_id}/workspaces"
            headers = {
                "Cookie": f"{self.AuthHeader}={session_id}"
            }

            response = await self.do_get(request_url, headers=headers)

            if response.status_code != 200:
                error_body = await response.text()
                logging.error(
                    f"FetchWorkSpaces Error: Failed to get workspace for {entity_user_id} - {session_id}. "
                    f"Status: {response.status}, Response: {error_body}"
                )
                return None

            response_json = response.json()
            if not response_json:
                logging.error(f"FetchWorkSpaces Error: Empty response received for user {entity_user_id}.")
                return None

            return FetchWorkSpaceResponse.model_validate(response_json)

        except ClientResponseError as e:
            logging.error(
                f"FetchWorkSpaces Error: HTTP ClientResponseError for {entity_user_id} - {session_id}. "
                f"Message: {e.message}, Status: {e.status}, URL: {e.request_info.url}"
            )
            return None
        except asyncio.CancelledError:
            logging.error("FetchWorkSpaces Error: Request was cancelled.")
            raise  # Allow cancellation to propagate
        except Exception as e:
            logging.error(f"FetchWorkSpaces Error: Unexpected exception occurred: {str(e)}")
            return None