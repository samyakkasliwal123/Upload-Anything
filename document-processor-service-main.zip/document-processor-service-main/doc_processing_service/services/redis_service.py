import redis
import redis.asyncio as aioredis
import asyncio
import logging
from threading import Lock
from configuration import Config
from redis.cluster import RedisCluster, ClusterNode

logger = logging.getLogger(__name__)

class RedisClient:
    """
    Singleton Redis client with optimized connection pooling.
    """
    _instance = None
    _lock = Lock()
    
    def __new__(cls, decode_responses=True):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, decode_responses=True):
        if self._initialized:
            return
            
        if Config.CURRENT_ENVIRONMENT == 'Production':
            startup_nodes = [
                ClusterNode(host=Config.REDIS_HOST, port=Config.REDIS_PORT)
            ]
            self.client = RedisCluster(
                startup_nodes=startup_nodes,
                decode_responses=decode_responses,
                socket_timeout=5,
                socket_connect_timeout=5,
                health_check_interval=30,
                retry_on_timeout=True,
                max_connections_per_node=50
            )
        else:
            self.pool = redis.ConnectionPool(
                host=Config.REDIS_HOST,
                port=Config.REDIS_PORT,
                decode_responses=decode_responses,
                max_connections=400,  # Increased for high RPS
                socket_timeout=3,     # Reduced timeout for faster failure
                socket_connect_timeout=3,  # Faster connection timeout
                socket_keepalive=True,
                socket_keepalive_options={},
                health_check_interval=30,
                retry_on_timeout=True,
                retry_on_error=[redis.ConnectionError, redis.TimeoutError]
            )
            self.client = redis.StrictRedis(connection_pool=self.pool)
        
        self._initialized = True
        logger.info("RedisClient singleton initialized with optimized connection pool")

    async def get(self, key: str):
        """Retrieve the result from Redis using the specified key."""
        import time
        start_time = time.perf_counter()
        try:
            result = await asyncio.to_thread(self.client.get, key)
            duration = time.perf_counter() - start_time
            if duration > 2.0:
                logger.error(f"SLOW REDIS GET: key {key} took {duration:.2f}s")
            return result
        except (redis.ConnectionError, redis.TimeoutError) as e:
            duration = time.perf_counter() - start_time
            logger.error(f"Redis GET error for key {key} after {duration:.2f}s: {e}")
            return None

    async def set(self, key: str, value):
        """Set the result in Redis using the specified key."""
        import time
        start_time = time.perf_counter()
        try:
            result = await asyncio.to_thread(self.client.set, key, value)
            duration = time.perf_counter() - start_time
            if duration > 2.0:
                logger.error(f"SLOW REDIS SET: key {key} took {duration:.2f}s")
            return result
        except (redis.ConnectionError, redis.TimeoutError) as e:
            duration = time.perf_counter() - start_time
            logger.error(f"Redis SET error for key {key} after {duration:.2f}s: {e}")
            return False

    async def remove(self, key: str):
        """Remove the result from Redis using the specified key."""
        try:
            return await asyncio.to_thread(self.client.delete, key)
        except (redis.ConnectionError, redis.TimeoutError) as e:
            logger.error(f"Redis DELETE error for key {key}: {e}")
            return False

    async def set_with_expiry(self, key, value, expiry):
        """Set the result in Redis using the specified key and expiry time."""
        try:
            return await asyncio.to_thread(self.client.setex, key, expiry, value)
        except (redis.ConnectionError, redis.TimeoutError) as e:
            logger.error(f"Redis SETEX error for key {key}: {e}")
            return False

    def close(self):
        """Close the Redis connection (optional, depending on usage)."""
        pass  # Redis client handles connections automatically

    @staticmethod
    async def set_static(key: str, value):
        """Static async method for setting values in Redis."""
        client = RedisClient()
        return await client.set(key, value)
    
    def get_connection_info(self):
        """Get connection pool information for monitoring."""
        if hasattr(self, 'pool'):
            return {
                'max_connections': self.pool.max_connections,
                'created_connections': self.pool.created_connections,
                'available_connections': len(self.pool._available_connections),
                'in_use_connections': len(self.pool._in_use_connections)
            }
        return {}

# Global singleton instance
redis_client = RedisClient()
