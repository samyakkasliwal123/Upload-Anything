from prometheus_client import Histogram
from contextlib import contextmanager, asynccontextmanager
import time
import functools
import asyncio

# Define a generic histogram
LATENCY_HISTOGRAM = Histogram(
    'service_operation_latency_seconds',
    'Latency for operations across services',
    ['service', 'operation', 'status']
)

class LatencyTracker:
    def __init__(self, service_name: str):
        self.service_name = service_name

    @contextmanager
    def track(self, operation: str, status: str = "success"):
        start = time.perf_counter()
        try:
            yield
            LATENCY_HISTOGRAM.labels(self.service_name, operation, status).observe(time.perf_counter() - start)
        except Exception:
            LATENCY_HISTOGRAM.labels(self.service_name, operation, "failure").observe(time.perf_counter() - start)
            raise

    @asynccontextmanager
    async def track_async(self, operation: str, status: str = "success"):
        start = time.perf_counter()
        try:
            yield
            LATENCY_HISTOGRAM.labels(self.service_name, operation, status).observe(time.perf_counter() - start)
        except Exception:
            LATENCY_HISTOGRAM.labels(self.service_name, operation, "failure").observe(time.perf_counter() - start)
            raise

    def wrap(self, operation: str, status: str = "success"):
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                with self.track(operation, status):
                    return func(*args, **kwargs)
            return wrapper
        return decorator

    def wrap_async(self, operation: str, status: str = "success"):
        def decorator(func):
            @functools.wraps(func)
            async def wrapper(*args, **kwargs):
                async with self.track_async(operation, status):
                    return await func(*args, **kwargs)
            return wrapper
        return decorator
