import json
import logging
from typing import Optional
from clients.rest_client import BaseRestClient, RestClientOptions
from document_service.models import User


class UserServiceHttpClient(BaseRestClient):
    API_TOKEN_HEADER_NAME = "X-Api-Token"

    def __init__(self, base_url: str, api_token: str):
        options = RestClientOptions.build_with_defaults()
        options.extra_headers = {self.API_TOKEN_HEADER_NAME: api_token}
        options.timeout = 10  # Custom timeout for UserService
        super().__init__(base_url, options)

    def get_user_from_session_id(self, session_id: str) -> Optional[User]:
        if not session_id:
            raise ValueError("sessionId cannot be null or empty.")

        response = self.do_get(f"/isAuthenticated/{session_id}")

        if response is None:
            logging.error("Network error in connecting to User Service")
            return None

        try:
            user_service_response = response.json()
            if user_service_response.get('success'):
                user_info = User.model_validate(user_service_response.get('response'))
                user_info.is_authenticated = True
                return user_info
            else:
                logging.error(f"User service error: {user_service_response.get('errorMessage')}")
                return None
        except json.JSONDecodeError:
            logging.error(f"Failed to parse JSON response: {response.text}")
            return None