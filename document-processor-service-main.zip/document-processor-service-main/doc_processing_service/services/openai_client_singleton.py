"""
OpenAI Client Singleton for memory optimization.
Prevents multiple AsyncOpenAI client instances from consuming memory.
"""
import logging
from typing import Optional
from openai import AsyncOpenAI
from configuration import Config


class OpenAIClientSingleton:
    """Singleton pattern for AsyncOpenAI client to reduce memory usage."""
    
    _instance: Optional[AsyncOpenAI] = None
    _lock = False  # Simple lock for async safety
    
    @classmethod
    async def get_client(cls) -> AsyncOpenAI:
        """Get the singleton AsyncOpenAI client instance."""
        if cls._instance is None and not cls._lock:
            cls._lock = True
            try:
                if cls._instance is None:  # Double-check after acquiring lock
                    logging.info("Creating singleton AsyncOpenAI client")
                    cls._instance = AsyncOpenAI(
                        api_key=Config.OPENAPI_KEY,
                        timeout=15.0,  # Reasonable timeout
                        max_retries=1,  # Reduce retries for faster failure
                        # Connection pool settings for memory optimization
                        http_client=None  # Use default httpx client with connection pooling
                    )
                    logging.info("AsyncOpenAI singleton client created successfully")
            finally:
                cls._lock = False
        
        return cls._instance
    
    @classmethod
    async def close_client(cls):
        """Close the singleton client (for cleanup during shutdown)."""
        if cls._instance is not None:
            try:
                await cls._instance.close()
                logging.info("AsyncOpenAI singleton client closed")
            except Exception as e:
                logging.warning(f"Error closing AsyncOpenAI client: {e}")
            finally:
                cls._instance = None
    
    @classmethod
    def is_initialized(cls) -> bool:
        """Check if the singleton client is initialized."""
        return cls._instance is not None