import logging
import functools
import time
from typing import Any, Callable


class LoggingService:
    """Centralized logging utility for consistent logging across the application."""
    
    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        """Get a configured logger instance."""
        return logging.getLogger(name)
    
    @staticmethod
    def log_activity_start(logger: logging.Logger, workflow_id: str, document_id: int, activity_name: str):
        """Log the start of an activity with consistent format."""
        logger.info(f"[WF:{workflow_id} | DOC:{document_id}] Starting {activity_name}")
    
    @staticmethod
    def log_activity_complete(logger: logging.Logger, workflow_id: str, document_id: int, activity_name: str):
        """Log the completion of an activity with consistent format."""
        logger.info(f"[WF:{workflow_id} | DOC:{document_id}] Completed {activity_name}")
    
    @staticmethod
    def log_activity_error(logger: logging.Logger, workflow_id: str, document_id: int, activity_name: str, error: Exception):
        """Log an activity error with consistent format."""
        logger.error(f"[WF:{workflow_id} | DOC:{document_id}] Error in {activity_name}: {error}", exc_info=True)


def log_function_call(logger_name: str = None):
    """Decorator to log function calls with execution time."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            logger = logging.getLogger(logger_name or func.__module__)
            start_time = time.perf_counter()
            
            try:
                result = func(*args, **kwargs)
                duration = time.perf_counter() - start_time
                logger.info(f"{func.__name__} completed in {duration:.2f}s")
                return result
            except Exception as e:
                duration = time.perf_counter() - start_time
                logger.error(f"{func.__name__} failed after {duration:.2f}s: {e}")
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs) -> Any:
            logger = logging.getLogger(logger_name or func.__module__)
            start_time = time.perf_counter()
            
            try:
                result = await func(*args, **kwargs)
                duration = time.perf_counter() - start_time
                logger.info(f"{func.__name__} completed in {duration:.2f}s")
                return result
            except Exception as e:
                duration = time.perf_counter() - start_time
                logger.error(f"{func.__name__} failed after {duration:.2f}s: {e}")
                raise
        
        # Return appropriate wrapper based on function type
        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return wrapper
    
    return decorator