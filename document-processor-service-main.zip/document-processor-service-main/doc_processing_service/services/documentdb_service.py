import asyncio

from asgiref.sync import sync_to_async
from django.db import IntegrityError, OperationalError, transaction
from django.utils import timezone
import logging
from document_service.models import Document, DocumentTypeConfiguration
from temporal_service.utils.metrics.decorator import temporal_metric

# Connection pool optimization
from django.db import connections
from django.core.management.color import no_style
from django.db.utils import DEFAULT_DB_ALIAS


class DocumentService:

    @staticmethod
    @temporal_metric("save_document_duration", "Duration of save_document")
    async def save_document(user_id, workflow_id, product, scope, section, s3_url, password, document_name, status="PENDING"):
        import time
        start_time = time.perf_counter()
        
        document = Document(
            user_id=user_id,
            workflow_id=workflow_id,
            product=product,
            scope=scope,
            section=section,
            s3_url=s3_url,
            password=password,
            status=status,
            document_name=document_name
        )

        try:
            await document.asave()
            
            duration = time.perf_counter() - start_time
            if duration > 2.0:
                logging.error(f"SLOW DB SAVE: save_document took {duration:.2f}s (workflow: {workflow_id})")
            
            return document
        except IntegrityError as e:
            duration = time.perf_counter() - start_time
            logging.error(f"Database Integrity Error after {duration:.2f}s: {e}")
            raise Exception("Failed to save document due to integrity constraint.")
        except OperationalError as e:
            duration = time.perf_counter() - start_time
            logging.error(f"Database Operational Error after {duration:.2f}s: {e}")
            raise Exception("Database operation failed. Please try again later.")
        except Exception as e:
            duration = time.perf_counter() - start_time
            logging.error(f"Unexpected error while saving document after {duration:.2f}s: {e}")
            raise Exception("An unexpected error occurred while saving the document.")

    @staticmethod
    @temporal_metric("get_document_duration", "Duration of get_document")
    async def get_document(document_id):
        """
        Get the document from the database asynchronously with related objects.

        Args:
            document_id: The ID of the document to get.
        """
        try:
            return await Document.objects.select_related('document_type_configuration').aget(document_id=document_id)
        except Document.DoesNotExist:
            logging.error(f"No document found with ID {document_id}.")
            raise ValueError(f"No document found with ID {document_id}.")
        except Exception as e:
            logging.error(f"Error getting document: {e}")
            raise Exception("Failed to get document from the database.")

    @staticmethod
    @temporal_metric("get_all_doc_type_configs_duration", "Duration of get_all_document_type_configs")
    async def get_all_document_type_configs():
        try:
            query_list = []
            async for doc_type_config in DocumentTypeConfiguration.objects.all().aiterator():
                query_list.append(doc_type_config)
            return query_list
        except Exception as e:
            logging.error(f"Error getting document type configs: {e}")
            raise Exception("Failed to get document type configurations from the database.")

    @staticmethod
    @temporal_metric("update_document_duration", "Duration of update_document")
    async def update_document(document_id, related_fields=None, **kwargs):
        try:
            if not kwargs and not related_fields:
                raise ValueError("No fields to update were provided.")

            # Batch related field lookups to reduce database queries
            if related_fields:
                related_lookups = []
                for field_name, (related_model, filter_kwargs) in related_fields.items():
                    related_lookups.append((field_name, related_model, filter_kwargs))
                
                # Execute all related lookups concurrently
                async def get_related_instance(field_name, related_model, filter_kwargs):
                    try:
                        return field_name, await related_model.objects.aget(**filter_kwargs)
                    except related_model.DoesNotExist:
                        logging.error(f"{related_model.__name__} instance not found for filter {filter_kwargs}.")
                        raise ValueError(f"{related_model.__name__} instance not found for filter {filter_kwargs}.")
                
                related_results = await asyncio.gather(*[
                    get_related_instance(field_name, related_model, filter_kwargs)
                    for field_name, related_model, filter_kwargs in related_lookups
                ])
                
                for field_name, related_instance in related_results:
                    kwargs[field_name] = related_instance

            kwargs['updated_at'] = timezone.now()

            # Optimized update without unnecessary transaction wrapper for single updates
            updated_rows = await Document.objects.filter(document_id=document_id).aupdate(**kwargs)
            if updated_rows == 0:
                logging.error(f"No document found with ID {document_id}.")
                raise ValueError(f"No document found with ID {document_id}.")

        except ValueError as ve:
            raise ve
        except Exception as e:
            logging.error(f"Error updating document: {e}")
            raise Exception("Failed to update document in the database.")
    
    @staticmethod
    @temporal_metric("bulk_update_documents_duration", "Duration of bulk_update_documents")
    async def bulk_update_documents(updates: list):
        """
        Bulk update multiple documents in a single transaction for better performance.
        
        Args:
            updates: List of tuples (document_id, update_fields)
        """
        try:
            if not updates:
                return
            
            @sync_to_async
            def bulk_update_in_transaction():
                with transaction.atomic():
                    updated_count = 0
                    for document_id, update_fields in updates:
                        update_fields['updated_at'] = timezone.now()
                        rows_updated = Document.objects.filter(document_id=document_id).update(**update_fields)
                        updated_count += rows_updated
                    return updated_count
            
            updated_count = await bulk_update_in_transaction()
            logging.info(f"Bulk updated {updated_count} documents")
            return updated_count
            
        except Exception as e:
            logging.error(f"Error in bulk update: {e}")
            raise Exception("Failed to bulk update documents in the database.")

    @staticmethod
    @temporal_metric("get_doc_from_wf_id_duration", "Duration of get_document_from_workflow_id")
    async def get_document_from_workflow_id(workflow_id):
        try:
            document = await sync_to_async(Document.objects.get)(workflow_id=workflow_id)
            return document
        except Document.DoesNotExist:
            logging.error(f"No document found with workflow ID {workflow_id}.")
            raise ValueError(f"No document found with workflow ID {workflow_id}.")
        except Exception as e:
            logging.error(f"Error getting document: {e}")
            raise Exception("Failed to get document from the database.")
    
    @staticmethod
    async def ensure_connection_health():
        """
        Ensure database connection is healthy and close stale connections.
        Critical for preventing connection pool exhaustion under high load.
        """
        try:
            connection = connections[DEFAULT_DB_ALIAS]
            if connection.connection is not None:
                # Test connection health
                await sync_to_async(connection.ensure_connection)()
                
                # Close connection if it's been idle too long
                if hasattr(connection, 'close_if_unusable_or_obsolete'):
                    await sync_to_async(connection.close_if_unusable_or_obsolete)()
        except Exception as e:
            logging.warning(f"Database connection health check failed: {e}")
            # Force close and recreate connection
            try:
                await sync_to_async(connection.close)()
            except:
                pass