import logging
from typing import Any, Callable, Optional, Type, Union
from functools import wraps


class ErrorHandler:
    """Centralized error handling utility for consistent error management."""
    
    @staticmethod
    def handle_database_error(error: Exception, operation: str, entity_id: Optional[str] = None) -> Exception:
        """Handle database-related errors with consistent logging and messaging."""
        logger = logging.getLogger(__name__)
        entity_info = f" for {entity_id}" if entity_id else ""
        logger.error(f"Database error during {operation}{entity_info}: {error}")
        return Exception(f"Database operation failed: {operation}")
    
    @staticmethod
    def handle_s3_error(error: Exception, operation: str, s3_key: Optional[str] = None) -> Exception:
        """Handle S3-related errors with consistent logging and messaging."""
        logger = logging.getLogger(__name__)
        key_info = f" for key {s3_key}" if s3_key else ""
        logger.error(f"S3 error during {operation}{key_info}: {error}")
        return Exception(f"S3 operation failed: {operation}")
    
    @staticmethod
    def handle_temporal_error(error: Exception, workflow_id: str, operation: str) -> Exception:
        """Handle Temporal workflow errors with consistent logging and messaging."""
        logger = logging.getLogger(__name__)
        logger.error(f"Temporal error in workflow {workflow_id} during {operation}: {error}")
        return Exception(f"Workflow operation failed: {operation}")


def with_error_handling(
    error_types: Union[Type[Exception], tuple] = Exception,
    default_return: Any = None,
    reraise: bool = True,
    log_error: bool = True
):
    """
    Decorator for consistent error handling across functions.
    
    Args:
        error_types: Exception type(s) to catch
        default_return: Value to return if error occurs and reraise=False
        reraise: Whether to reraise the exception after handling
        log_error: Whether to log the error
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except error_types as e:
                if log_error:
                    logger = logging.getLogger(func.__module__)
                    logger.error(f"Error in {func.__name__}: {e}", exc_info=True)
                
                if reraise:
                    raise
                return default_return
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except error_types as e:
                if log_error:
                    logger = logging.getLogger(func.__module__)
                    logger.error(f"Error in {func.__name__}: {e}", exc_info=True)
                
                if reraise:
                    raise
                return default_return
        
        # Return appropriate wrapper based on function type
        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return wrapper
    
    return decorator