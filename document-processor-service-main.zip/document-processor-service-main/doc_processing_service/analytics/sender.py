import shlex
import uuid
import json
import logging
from dataclasses import dataclass, fields, is_dataclass
from typing import Optional, get_type_hints, get_origin, get_args, Union
import aiohttp

from doc_processing_service.analytics.models import DocumentEvent, BaseEvent
from doc_processing_service.configuration import Config
from doc_processing_service.services.redis_service import RedisClient


def avro_type(py_type):
    origin = get_origin(py_type)
    args = get_args(py_type)

    # Detect Optional[T], which is Union[T, NoneType]
    if origin is Union and type(None) in args:
        # Extract the actual type inside Optional
        non_none_args = [arg for arg in args if arg is not type(None)]
        if non_none_args:
            py_type = non_none_args[0]
        origin = get_origin(py_type)

    if py_type is str:
        return 'string'
    elif py_type is int:
        return 'int'
    elif py_type is float:
        return 'float'
    elif py_type is bool:
        return 'boolean'
    elif origin is dict:
        return {'type': 'map', 'values': 'string'}
    elif origin is list:
        return {'type': 'array', 'items': 'string'}

    return 'string'

def generate_avro_schema_from_dataclass(cls, schema_name: str):
    return {
        "type": "record",
        "name": schema_name,
        "fields": [
            {"name": f.name, "type": avro_type(get_type_hints(cls).get(f.name, str))}
            for f in fields(cls)
        ]
    }

async def ensure_schema_exists(cls, schema_name: str, sample_data: dict, username: str, priority: str = "P1") -> str:
    redis_key = f"analytics:{schema_name}:table_id"
    redis_client = RedisClient()
    cached_table_id = await redis_client.get(redis_key)
    if cached_table_id:
        return cached_table_id
    # Next try from config settings which is a fallback and dictionary
    if not cached_table_id:
         cached_table_id = json.loads(Config.ANALYTICS_TABLE_ID).get(schema_name)
         if cached_table_id:
            return cached_table_id

    schema = generate_avro_schema_from_dataclass(cls, schema_name)

    payload = {
        "databaseName": "documentservice",
        "tableName": schema_name,
        "schema": json.dumps(schema),
        "sampleData": json.dumps(sample_data),
        "timestampKey": "created_at",
        "primaryKeys": ["_id"],
        "partitionKeys": [],
        "priority": priority,
    }

    headers = {
        "username": username,
        "Content-Type": "application/json",
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{Config.ANALYTICS_URL}/api/analytics/schemas", json=payload, headers=headers
        ) as resp:
            logging.info(f"Schema creation response: {resp.status} - {await resp.text()}")
            if resp.status != 200:
                body = await resp.text()
                raise Exception(f"Schema creation failed: {resp.status} - {body}")
            result = await resp.json()
            table_id = result.get("data", {}).get("tableProperties", {}).get("id")
            if not table_id:
                raise Exception("table_id missing from schema creation response")
            await RedisClient.set_static(redis_key, table_id)
            return table_id

async def send_event(event: BaseEvent):
    try:
        schema_name = event.__class__.__name__.lower()
        username = getattr(event, "username", "lakshay.duggal@clear.in")
        if not username:
            raise ValueError("username is required in Event to send analytics")


        table_id = await ensure_schema_exists(
            event.__class__,
            schema_name=schema_name,
            sample_data=event.to_dict(),
            username=username
        )

        payload = [event.to_kafka_payload(table_id)]

        headers = {
            "username": username,
            "Content-Type": "application/json",
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{Config.ANALYTICS_URL}/api/analytics/events",
                json=payload,
                headers=headers
            ) as response:
                if response.status != 200:
                    body = await response.text()
                    raise Exception(f"Failed to send analytics: {response.status} - {body}")

    except Exception as e:
        logging.exception(f"Exception sending analytics event: {e}")
        raise

