import asyncio
import logging
from doc_processing_service.analytics.models import BaseEvent
from doc_processing_service.analytics.sender import send_event

class EventQueue:
    _instance = None

    def __init__(self):
        self.queue = asyncio.Queue()
        self._worker_task = None

    @classmethod
    def get_instance(cls) -> "EventQueue":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def start_worker(self):
        if self._worker_task is None:
            self._worker_task = asyncio.create_task(self._consume())

    async def _consume(self):
        while True:
            try:
                event: BaseEvent = await self.queue.get()
                await send_event(event)
            except Exception as e:
                logging.exception(f"[AnalyticsWorker] Error: {e}")

    def add_event(self, event: BaseEvent):
        self.queue.put_nowait(event)