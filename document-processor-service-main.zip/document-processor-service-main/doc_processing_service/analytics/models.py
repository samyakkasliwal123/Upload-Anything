from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Optional
import uuid
import json

@dataclass
class BaseEvent:
    _id: str = field(init=False)
    created_at: str = field(init=False)
    event_source: str = field(init=False)

    def __post_init__(self):
        self._id = str(uuid.uuid4())
        self.created_at = datetime.utcnow().isoformat()
        self.event_source = "TemporalWorkflow"

    def to_dict(self):
        return asdict(self)

    def to_kafka_payload(self, table_id: str):
        return {
            "analyticsId": self._id,
            "tableId": table_id,
            "data": json.dumps(self.to_dict())  # Ensure JSON string inside Kafka API
        }

@dataclass
class DocumentEvent(BaseEvent):
    workflow_id: str
    user_id: str
    scope_id: str
    file_name: str
    product: str
    file_url: str
    classified_type: Optional[str] = None
    classified_subtype: Optional[str] = None
    llm_classified: Optional[bool] = None
    llm_parsed: Optional[bool] = None
    file_password: Optional[str] = None
    error: Optional[str] = None
    document_id: Optional[int] = None
    status: Optional[str] = None
    action: Optional[str] = None
    metadata: Optional[dict] = None
