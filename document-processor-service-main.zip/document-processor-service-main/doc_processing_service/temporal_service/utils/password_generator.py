from datetime import datetime
import re


class PasswordGenerator:
    @staticmethod
    def generate_passwords(pan: str, dob: str, first_name: str = "") -> list:
        """
        Generate all possible password combinations based on PAN, DOB, and FIRSTNAME.

        Args:
            pan (str): PAN number.
            dob (str): Date of birth in the format 'DDMMYYYY' (special characters will be removed).
            first_name (str): First name of the user (optional).

        Returns:
            list: A list of all possible passwords.
        """
        if not pan and not dob and not first_name:
            return []

        # Clean and prepare inputs
        ais_random_string = "GQ39%*g"
        pan_upper = pan.upper() if pan else ""
        pan_lower = pan.lower() if pan else ""
        first_name_cap = first_name.capitalize() if first_name else ""
        dob_cleaned = PasswordGenerator._clean_dob(dob)
        dob_formats = PasswordGenerator._generate_dob_formats(dob_cleaned)

        # Generate password combinations
        passwords = set()

        for dob_format in dob_formats:
            passwords.add(f"{pan_upper}{dob_format}")
            passwords.add(f"{dob_format}{pan_upper}")
            passwords.add(f"{pan_lower}{dob_format}")
            passwords.add(f"{dob_format}{pan_lower}")
            passwords.add(f"{pan_lower}{ais_random_string}{dob_format}")

        # Add combinations with first name and without DOB
        passwords.add(f"{first_name_cap}{pan_upper}")
        passwords.add(f"{pan_upper}")
        passwords.add(f"{pan_lower}")
        passwords.add(first_name_cap)

        # Remove empty strings and return as a list
        return [password for password in passwords if password]

    @staticmethod
    def _clean_dob(dob: str) -> str:
        """
        Remove special characters from DOB.

        Args:
            dob (str): Original DOB string.

        Returns:
            str: Cleaned DOB string containing only digits.
        """
        return re.sub(r"[^0-9]", "", dob) if dob else ""

    @staticmethod
    def _generate_dob_formats(dob: str) -> list:
        """
        Generate all supported DOB formats from a base string.

        Args:
            dob (str): Cleaned date of birth in 'DDMMYYYY' format.

        Returns:
            list: A list of formatted DOB strings.
        """
        if not dob or len(dob) != 8:
            return []

        try:
            date_obj = datetime.strptime(dob, "%d%m%Y")
            return [
                date_obj.strftime("%d%m%Y"),   # DDMMYYYY
                date_obj.strftime("%d-%m-%Y"),  # DD-MM-YYYY
                date_obj.strftime("%d/%m/%Y"),  # DD/MM/YYYY
            ]
        except ValueError:
            return []
