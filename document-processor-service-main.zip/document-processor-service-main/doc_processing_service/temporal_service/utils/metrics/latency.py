from contextlib import contextmanager
from datetime import datetime
from typing import Dict, Optional

from temporalio import activity


class NoOpHistogram:
    """No-operation histogram for when not in activity context"""
    def record(self, value, additional_attributes=None):
        pass


class ActivityMetricTimer:
    def __init__(self, metric_name: str, description: str, unit: str = "milliseconds"):
        self.metric_name = metric_name
        self.description = description
        self.unit = unit
        self._histogram = None

    def _ensure_histogram(self):
        if self._histogram is None:
            try:
                meter = activity.metric_meter()
                self._histogram = meter.create_histogram(
                    name=self.metric_name,
                    description=self.description,
                    unit=self.unit,
                )
            except Exception:
                # Not in activity context (e.g., during testing)
                # Use a no-op histogram that doesn't record metrics
                self._histogram = NoOpHistogram()

    @contextmanager
    def time(self, attributes: Optional[Dict[str, str]] = None):
        self._ensure_histogram()
        start_time = datetime.utcnow()
        try:
            yield
        finally:
            end_time = datetime.utcnow()
            duration = end_time - start_time
            duration_ms = int(duration.total_seconds() * 1000)
            if attributes is None:
                attributes = {}
            self._histogram.record(duration_ms, additional_attributes=attributes)

    from functools import wraps
