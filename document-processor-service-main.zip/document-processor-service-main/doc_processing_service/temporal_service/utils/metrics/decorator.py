from functools import wraps
from doc_processing_service.temporal_service.utils.metrics.latency import ActivityMetricTimer

def temporal_metric(metric_name: str, description: str, unit: str = "milliseconds"):
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            timer = ActivityMetricTimer(metric_name, description, unit)
            with timer.time({"activity": func.__name__}):
                return await func(*args, **kwargs)

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            timer = ActivityMetricTimer(metric_name, description, unit)
            with timer.time({"activity": func.__name__}):
                return func(*args, **kwargs)

        return async_wrapper if hasattr(func, "__await__") else sync_wrapper

    return decorator