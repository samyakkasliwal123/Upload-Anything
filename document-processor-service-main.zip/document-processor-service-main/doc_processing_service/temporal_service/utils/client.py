import dataclasses
from threading import Lock
from temporalio.client import Client
from temporalio.converter import default
from configuration import Config
from temporal_service.data_converter import EncryptionCodec


class TemporalClientSingleton:
    """Singleton class for managing Temporal client connections."""
    _instance = None
    _lock = Lock()

    @classmethod
    async def get_client(cls):
        """Get or create a Temporal client instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:  # Double-check locking
                    cls._instance = await Client.connect(
                        Config.TEMPORAL_SERVICE_ADDRESS,
                        namespace=Config.TEMPORAL_NAMESPACE,
                        data_converter=dataclasses.replace(
                            default(),
                            payload_codec=EncryptionCodec()
                        )
                    )
        return cls._instance

    @classmethod
    def reset(cls):
        """Reset the singleton instance (useful for testing)."""
        with cls._lock:
            cls._instance = None