from typing import Optional
import uuid
from dataclasses import dataclass

@dataclass
class Metadata:
    data_assignment_index: Optional[int] = None

@dataclass
class ValidateFileStep:
    s3_key: str
    file_extension: str
    user_id: uuid.UUID
    file_name: str
    product: str
    scope: str
    workflow_id: str
    meta_data: dict = None


@dataclass
class ParseDocumentStep:
    document_id: int

@dataclass
class UnifiedLLMProcessingStep:
    """Data class for unified LLM processing step"""
    document_id: int
    s3_key: str
    file_extension: str
    password: Optional[str]
    product: str
    user_sid: str
    metadata: Optional[Metadata] = None
