from document_service.models import Document
from services.documentdb_service import DocumentService
from services.logging_utils import LoggingService
from temporalio import activity
from doc_processing_service.analytics.eventQueue import EventQueue
from doc_processing_service.analytics.models import DocumentEvent


@activity.defn(name="send_analytics_activity")
async def send_analytics_activity(document_id: int, error: str, status: str, activity_name: str):
    """Send analytics event for document processing activity."""
    logger = LoggingService.get_logger(__name__)
    
    # Fetch document from DB
    try:
        document = await DocumentService.get_document(document_id)
    except Document.DoesNotExist:
        logger.error(f"Document with id {document_id} does not exist.")
        return
    except Exception as e:
        logger.error(f"Error fetching document with id {document_id}: {e}")
        return

    logger.info(f"Sending analytics for document id: {document.document_id}")

    event = DocumentEvent(
            document_id=document.document_id,
            user_id=str(document.user_id),
            file_name=document.document_name,
            file_password=document.password,
            product=document.product,
            workflow_id=document.workflow_id,
            scope_id=document.scope,
            file_url=document.s3_url,
            classified_type=document.document_category,
            classified_subtype=document.document_subcategory,
            llm_parsed=document.llm_parsed,
            llm_classified=document.llm_classified,
            error=error,
            status=f"{activity_name} : {status}",
        )
    EventQueue.get_instance().add_event(event)
