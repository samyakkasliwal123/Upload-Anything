# Helper functions for determining next activity details
# Extracted from classify_document.py to support unified LLM processor

from typing import Optional
from document_service.models import NextActivityDetails, Document, DocumentTypeConfiguration
from document_service.text_choices import DocumentCategory
from temporal_service.activities.dataclasses import Metadata
from document_service.helpers.document_type_mapper import DocumentTypeMapper
from configuration import Config


async def _get_next_activity_and_request(document: Document, user_sid: str, metadata: Optional[Metadata] = None) -> NextActivityDetails:
    """Maps document types to next activity names and task queues.

    Parameters
    ----------
    document : Document
        The document object with document_type_configuration
    user_sid : str
        User session ID
    metadata : Optional[Metadata]
        Optional metadata for the request
    """
    # Check if document has proper type configuration
    if not document.document_type_configuration:
        # Handle documents without proper classification - use DOC_ADDITIONAL_DOC enum value
        next_activity_details = NextActivityDetails(
            parser_activity_name=None,
            parser_activity_request_data=None,
            parser_task_queue=None,
            classified_type=DocumentCategory.DOC_ADDITIONAL_DOC.value,  # Use enum value instead of None
            notify_activity_name=None,
            notify_activity_request_data=None,
            notify_task_queue=None,
        )
        return next_activity_details
    
    document_type_configuration = document.document_type_configuration
    activity_name = document_type_configuration.parser_activity
    next_activity_details = NextActivityDetails()
    if activity_name:
        # Standard case: use configured parser activity
        parser_activity_request_data = DocumentTypeMapper.prepare_parser_request(document, activity_name)
        next_activity_details = NextActivityDetails(
            parser_activity_name=activity_name,
            parser_activity_request_data=parser_activity_request_data,
            parser_task_queue=Config.PARSING_WORKER_TASK_QUEUE,
            classified_type=document.document_category or DocumentCategory.DOC_ADDITIONAL_DOC.value,
        )

    # Special handling for specific document types
    if document.document_category == DocumentCategory.DOC_FORM_26_AS.value or document.document_category == DocumentCategory.DOC_TAX_CHALLAN.value:
        next_activity_details.parser_activity_request_data = DocumentTypeMapper.prepare_form_26_as_parser_request(document)
        next_activity_details.parser_task_queue = Config.NOTIFY_WORKER_TASK_QUEUE

    # Set up notification activity if configured
    if document_type_configuration.notify_activity:
        next_activity_details.notify_activity_name = document_type_configuration.notify_activity
        next_activity_details.notify_activity_request_data = DocumentTypeMapper.prepare_notify_request(document, user_sid, metadata)
        next_activity_details.notify_task_queue = Config.NOTIFY_WORKER_TASK_QUEUE
        
    return next_activity_details