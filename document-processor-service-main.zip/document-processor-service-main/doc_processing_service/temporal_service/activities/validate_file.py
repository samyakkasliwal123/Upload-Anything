import asyncio
import inspect
from time import perf_counter

from document_service.models import ValidateDocumentRequest, ValidateDocumentResponse
from document_service.password_checker import PasswordCheckerFactory
from document_service.serializers import MetaDataSerializer
from exceptions import (
    PasswordNeededException,
    PasswordIncorrectException,
    FileTooBigException,
    InvalidFileException
)
from services.aws_utils import download_file
from services.documentdb_service import DocumentService
from services.logging_utils import LoggingService
from temporalio import activity
from temporal_service.activities.dataclasses import ValidateFileStep
from temporal_service.utils.password_generator import PasswordGenerator
from temporal_service.workflows.workflow_status import Status
from doc_processing_service.temporal_service.utils.metrics.latency import ActivityMetricTimer

# Reusable metrics helper
validate_file_timer = ActivityMetricTimer(
    "validate_file_latency_ms",
    "Latency for validate uploaded file activity steps"
)


@activity.defn(name="validate_and_save_uploaded_file")
async def validate_and_save_uploaded_file(validate_file_step: ValidateFileStep) -> ValidateDocumentResponse:
    workflow_id = validate_file_step.workflow_id
    logger = LoggingService.get_logger(__name__)
    logger.info(f"[WF:{workflow_id}] Starting file validation for user {validate_file_step.user_id}")

    try:
        with validate_file_timer.time({
            "step": "total",
            "workflow_id": workflow_id,
        }):

            file_bytes = await download_file(validate_file_step.s3_key, workflow_id)

            # Step 2: Initialize validators and request
            validators = [_is_valid_file_size, _is_valid_file_extension, _validate_metadata, _validate_password]
            req = ValidateDocumentRequest(
                meta_data=validate_file_step.meta_data,
                file_extension=validate_file_step.file_extension,
                file_bytes=file_bytes
            )
            res = ValidateDocumentResponse()

            # Step 3: Run all validators
            with validate_file_timer.time({
                "step": "run_validators",
                "workflow_id": workflow_id,
            }):
                for validator in validators:
                    if inspect.iscoroutinefunction(validator):
                        validator_res = await validator(req, res)
                    else:
                        validator_res = validator(req, res)

                    if validator_res and validator_res.status:
                        break

            document = await DocumentService.save_document(
                    user_id=validate_file_step.user_id,
                    workflow_id=workflow_id,
                    product=validate_file_step.product,
                    scope=validate_file_step.scope,
                    section=res.validated_meta_data.get("section", "") if res.validated_meta_data else "",
                    s3_url=validate_file_step.s3_key,
                    password=res.validated_password if res.validated_password else "",
                    document_name=validate_file_step.file_name,
                    status="RUNNING",
                )

            # Step 5: Return result
            res.document_id = document.document_id
            logger.info(f"[WF:{workflow_id}] File validation completed successfully.")
            return res

    except Exception as e:
        logger.error(f"[WF:{workflow_id}] Error during file validation: {e}", exc_info=True)
        raise
def _validate_metadata(req: ValidateDocumentRequest, res: ValidateDocumentResponse) -> ValidateDocumentResponse:
    """
    Deserialize and validate metadata.

    Args:
        meta_data (dict): Metadata dictionary.

    Returns:
        dict: Validated metadata.
    """
    try:
        serializer = MetaDataSerializer(data=req.meta_data)
        serializer.is_valid(raise_exception=True)
        res.validated_meta_data = serializer.validated_data
        return res
    except Exception:
        res.status = Status.INVALID_META_DATA
        res.error = "Invalid file metadata"
        return res


async def _validate_password(
    req: ValidateDocumentRequest,
    res: ValidateDocumentResponse,
) -> ValidateDocumentResponse:
    user_password = res.validated_meta_data.get('password', "")
    pan = res.validated_meta_data.get('pan', "")
    dob = res.validated_meta_data.get('dob', "")
    password_checker = PasswordCheckerFactory.get_password_checker(req.file_extension)

    if not password_checker:
        res.status = Status.INVALID_FILE
        res.error = "Invalid file extension"
        return res

    # Check if file is password protected (offloaded)
    is_protected = await asyncio.to_thread(password_checker.is_password_protected, req.file_bytes)
    if not is_protected:
        res.validated_password = ""
        return res

    # Try user-provided password
    if user_password:
        is_correct = await asyncio.to_thread(password_checker.is_password_correct, req.file_bytes, user_password)
        if is_correct:
            res.validated_password = user_password
            return res

    # Try generated passwords
    possible_passwords = PasswordGenerator.generate_passwords(pan, dob)
    for generated_password in possible_passwords:
        is_correct = await asyncio.to_thread(password_checker.is_password_correct, req.file_bytes, generated_password)
        if is_correct:
            res.validated_password = generated_password
            return res

    if user_password:
        res.status = Status.PASSWORD_INCORRECT
        res.error = "User-provided password is incorrect"
        return res

    res.status = Status.PASSWORD_REQUIRED
    res.error = "Document is password-protected, and no valid password could be found."
    return res


def _is_valid_file_size(
    req: ValidateDocumentRequest,
    res: ValidateDocumentResponse,
) -> ValidateDocumentResponse:
    """
    Validate file size.

    Args:
        file_bytes (bytes): File content in bytes.
    """
    max_file_size = 10 * 1024 * 1024  # 10 MB in bytes
    if len(req.file_bytes) > max_file_size:
        res.status = Status.TOO_BIG_FILE
        res.error = "File size exceeds the limit of 10 MB."
        return res

    return res


def _is_valid_file_extension(
        req: ValidateDocumentRequest,
        res: ValidateDocumentResponse,
) -> ValidateDocumentResponse:
    """
    Validate file extension.

    Args:
        file_extension (str): File extension.
    """
    # Allow document files and image files for LLM processing
    allowed_extensions = [".pdf", ".json", ".txt", ".xlsx", ".xls", ".csv", ".jpg", ".jpeg", ".png", ".bmp"]
    if req.file_extension not in allowed_extensions:
        res.status = Status.INVALID_FILE
        res.error = "Invalid file extension"
        return res

    return res
