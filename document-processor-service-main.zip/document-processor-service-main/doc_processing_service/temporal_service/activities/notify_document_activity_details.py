from document_service.models import NextActivityDetails
from document_service.helpers.document_type_mapper import DocumentTypeMapper
from services.documentdb_service import DocumentService
from services.logging_utils import LoggingService
from configuration import Config
from temporalio import activity


@activity.defn(name="get_notify_document_activity_details")
async def get_notify_document_activity_details(document_id: int, user_sid: str) -> NextActivityDetails:
    """
    Get the activity to notify the document status to product.
    """
    logger = LoggingService.get_logger(__name__)

    try:
        document = await DocumentService.get_document(document_id)
        next_activity_details = NextActivityDetails(
            notify_activity_name='SaveDocumentProcessingStatus',
            notify_activity_request_data=DocumentTypeMapper.prepare_notify_request(document, user_sid, None),
            notify_task_queue=Config.NOTIFY_WORKER_TASK_QUEUE,
        )
        return next_activity_details
    except Exception as e:
        logger.error(f"Error getting notify activity details for document {document_id}: {e}", exc_info=True)
        raise Exception("Error getting notify activity details.")
