import gc
import logging
from typing import Optional, Any
from temporalio import activity

from document_service.text_choices import DocumentCategory, DocumentSubCategory, Product
from document_service.models import NextActivityDetails, Document, DocumentTypeConfiguration
from document_service.llm.enhanced_parser import EnhancedLLMDataParserClassifier
from document_service.llm.document_dataclass_mapper import get_llm_dataclass
from document_service.llm.llm_dataclasses import TaxDocumentClassification
from document_service.helpers.document_type_mapper import DocumentTypeMapper
from document_service.classification import RegexClassifier, DocumentClassificationContext
from document_service.processor import DocumentProcessorFactory
from services.documentdb_service import DocumentService
from services.compression_utils import CompressionService
from services.logging_utils import LoggingService
from services.aws_utils import download_file
from temporal_service.activities.dataclasses import Metadata, UnifiedLLMProcessingStep
from configuration import Config
from doc_processing_service.temporal_service.utils.metrics.latency import ActivityMetricTimer

# Reusable metrics helper
unified_llm_timer = ActivityMetricTimer(
    "unified_llm_processor_latency_ms",
    "Latency for unified LLM processor activity steps"
)


@activity.defn(name="unified_llm_classify_transform_activity")
async def unified_llm_classify_transform_activity(processing_step: UnifiedLLMProcessingStep) -> NextActivityDetails:
    """
    Unified activity that processes any file type directly with LLM for both classification and transformation.
    Skips traditional text extraction and does everything in a single LLM call.
    """
    info = activity.info()
    workflow_id = info.workflow_id
    document_id = processing_step.document_id
    
    logger = LoggingService.get_logger(__name__)
    LoggingService.log_activity_start(logger, workflow_id, document_id, "unified LLM classify and transform")
    
    file_bytes = None
    try:
        # Ensure database connection health before heavy operations
        await DocumentService.ensure_connection_health()
        
        # Step 1: Download the file
        with unified_llm_timer.time({
            "step": "download_file",
            "workflow_id": workflow_id,
            "document_id": str(document_id),
        }):
            file_bytes = await download_file(processing_step.s3_key, workflow_id)
        
        # Step 2: Try regex classification first, then LLM if needed
        with unified_llm_timer.time({
            "step": "classification_and_processing",
            "workflow_id": workflow_id,
            "document_id": str(document_id),
        }):
            classification_result, extracted_data, llm_used = await _unified_classify_and_process_file(
                file_bytes, processing_step.product, processing_step.file_extension, processing_step.password
            )
        
        # Step 3: Update document with classification and extracted data
        with unified_llm_timer.time({
            "step": "update_document",
            "workflow_id": workflow_id,
            "document_id": str(document_id),
        }):
            await _update_document_with_results(
                processing_step, classification_result, extracted_data, llm_used
            )
        
        # Step 4: Determine next activity
        with unified_llm_timer.time({
            "step": "determine_next_activity",
            "workflow_id": workflow_id,
            "document_id": str(document_id),
        }):
            next_activity = await _determine_next_activity(
                processing_step.document_id, processing_step.user_sid, processing_step.metadata
            )
        
        LoggingService.log_activity_complete(logger, workflow_id, document_id, "unified LLM classify and transform")
        return next_activity
        
    except Exception as e:
        # Ensure connection cleanup on error
        await DocumentService.ensure_connection_health()
        LoggingService.log_activity_error(logger, workflow_id, document_id, "unified LLM classify and transform", e)
        raise
    finally:
        # Always cleanup file_bytes and force garbage collection
        file_bytes = None
        gc.collect()


async def _unified_classify_and_process_file(file_bytes: bytes, product: str, file_extension: str, password: Optional[str] = None) -> tuple[TaxDocumentClassification, Optional[Any], bool]:
    """
    First try regex classification with text extraction, then fall back to LLM if needed.
    For files that don't support text extraction (like images), skip regex and go directly to LLM.
    Returns classification result, extracted data, and whether LLM was used.
    """
    product_enum = Product[product]
    llm_used = False
    
    # Check if this file type supports traditional text extraction
    if not DocumentProcessorFactory.supports_text_extraction(file_extension):
        logging.info(f"File type {file_extension} doesn't support text extraction, using LLM directly")
        llm_used = True
        
        # Create unified prompt that combines classification and transformation
        unified_prompt = await _create_unified_prompt(product)
        
        # Send file directly to LLM (with vision capabilities for images)
        classification_result, extracted_data = await _perform_llm_processing(
            file_bytes,
            unified_prompt,
            product_enum,
            file_extension,
            password
        )
        
        return classification_result, extracted_data, llm_used
    
    # Step 1: Try regex classification first (fast and efficient) for text-extractable files
    try:
        # Extract text using traditional processors
        processor = DocumentProcessorFactory.get_processor(file_extension)
        processor_result = await processor.process(file_bytes, password, file_extension)
        extracted_text = processor_result
        
        # Skip regex classification if the processor returned a placeholder (like for images)
        if extracted_text.startswith("[IMAGE FILE:"):
            logging.info(f"Processor returned image placeholder, falling back to LLM")
            raise Exception("Image file detected by processor")
        
        # Try regex classification
        document_category, document_subcategory = await DocumentClassificationContext(RegexClassifier()).classify_document(
            extracted_text, product, file_extension
        )
        
        # If regex classification succeeded (not MISCELLANEOUS), use it
        if document_category != DocumentCategory.DOC_ADDITIONAL_DOC.name:
            logging.info(f"Regex classification succeeded: {document_category} - {document_subcategory}")
            
            # Create classification result from regex
            # document_category and document_subcategory are strings from database config
            try:
                doc_type = DocumentCategory[document_category]
            except KeyError:
                logging.warning(f"Invalid document category from regex: {document_category}")
                doc_type = DocumentCategory.DOC_ADDITIONAL_DOC
            
            # Handle document subcategory - must be DocumentSubCategory enum, not DocumentCategory
            doc_subtype = DocumentSubCategory.NOT_INITIALIZED  # Default value
            if document_subcategory and document_subcategory.strip():
                try:
                    doc_subtype = DocumentSubCategory[document_subcategory]
                except KeyError:
                    logging.warning(f"Invalid document subcategory from regex: {document_subcategory}")
                    doc_subtype = DocumentSubCategory.NOT_INITIALIZED
            
            classification_result = TaxDocumentClassification(
                reasonForClassification=f"Regex classification based on document patterns",
                docType=doc_type,
                docTypeSub=doc_subtype
            )
            
            # For regex-classified documents, don't extract data here
            # Let the original parser activities handle data extraction on their configured servers
            # This maintains the distributed architecture where different parsers run on different servers
            extracted_data = None
            llm_used = False  # Only regex was used for classification
            
            return classification_result, extracted_data, llm_used
            
    except Exception as e:
        logging.warning(f"Regex classification failed: {e}, falling back to LLM")
    
    # Step 2: Fall back to unified LLM processing if regex failed
    logging.info("Using unified LLM processing for classification and extraction - sending file directly to LLM")
    llm_used = True
    
    # Create unified prompt that combines classification and transformation
    unified_prompt = await _create_unified_prompt(product)
    
    # Send file directly to LLM
    classification_result, extracted_data = await _perform_llm_processing(
        file_bytes,
        unified_prompt,
        product_enum,
        file_extension,
        password
    )
    
    return classification_result, extracted_data, llm_used


async def _get_document_type_configurations(product: str) -> str:
    """Fetch and format document type configurations for LLM prompt"""
    try:
        configs = await DocumentService.get_all_document_type_configs()
        if not configs:
            return "No document type configurations available."
        
        # Group by category
        categories = {}
        for config in configs:
            cat = config.document_category
            sub = config.document_subcategory or ""
            categories.setdefault(cat, set()).add(sub)
        
        # Format concisely
        lines = ["### Available Document Types:"]
        for category, subcategories in categories.items():
            subs = ", ".join(sorted(subcategories))
            lines.append(f"- **{category}**: {subs}")
        
        lines.append("\n**Use ONLY these categories and subcategories. If no match, use DOC_ADDITIONAL_DOC.**")
        return "\n".join(lines)
        
    except Exception as e:
        logging.error(f"Error fetching document configurations: {e}")
        return "Error loading configurations."


async def _create_unified_prompt(product: str) -> str:
    """Create a unified prompt that combines classification and data extraction"""
    document_types = await _get_document_type_configurations(product)
    
    return f"""
You are an expert financial document processor that can both classify and extract data from documents.

### Task:
1. First, analyze the document content and classify it into the most appropriate document type and document sub type.
2. Then, extract relevant structured data from the document according to the classification.

{document_types}

### Classification Rules:
1. You MUST choose ONLY from the document categories and subcategories listed in the "Available Document Types" section above.
2. Do NOT create new categories and subcategory combination that is not explicitly listed.
3. Match the document to the most appropriate category-subcategory combination from the available options.
4. Use the exact category and subcategory names as shown in the available types list.
5. If no perfect match exists in the available options, classify as "DOC_ADDITIONAL_DOC" with "NOT_INITIALIZED" subcategory and explain why.

### Section 80C Document Classification Guidelines:
Pay special attention to these Section 80C investment document types:
- **DOC_PPF_STATEMENT**: Look for "PPF", "Public Provident Fund", account numbers containing "PPF", "NB Subscription", deposit amounts, 15-year tenure mentions
- **DOC_LIFE_INSURANCE_PREMIUM**: Life insurance premium receipts, policy numbers, premium amounts, insurance company names
- **DOC_ELSS_MUTUAL_FUND**: ELSS schemes, "Tax Saver" funds, folio numbers, 3-year lock-in period mentions
- **DOC_ULIP_CERTIFICATE**: ULIP policies, unit-linked insurance plans, fund allocation details
- **DOC_EPF_STATEMENT**: EPF statements, UAN numbers, employee contributions, EPFO references
- **DOC_NSC_CERTIFICATE**: National Savings Certificates, 5-year tenure, post office investments
- **DOC_SUKANYA_SAMRIDHI**: Sukanya Samridhi accounts, girl child beneficiary, 21-year tenure
- **DOC_NPS_STATEMENT**: NPS statements, PRAN numbers, employee contributions, 80CCD(1) and 80CCD(1B) references

### Section 80E Document Classification Guidelines:
- **DOC_EDUCATION_LOAN_INTEREST_CERTIFICATE**: Education loan interest certificates, loan account numbers, interest paid for higher education, Section 80E references, educational institution details

### Section 80D Document Classification Guidelines:
- **DOC_MEDICAL_INSURANCE_POLICY**: Medical insurance policies, health insurance cards, premium receipts, policy numbers, insurer names, Section 80D references, health coverage details

**IMPORTANT**: If you see account numbers containing "PPF", transactions like "NB Subscription", or references to Public Provident Fund, classify as "DOC_PPF_STATEMENT", NOT "savings_bank_interest".

### Data Extraction Rules:
1. After classification, extract relevant data according to the document type.
2. For dates, use YYYY-MM-DD format when possible.
3. For amounts, extract numeric values without currency symbols.
4. **Financial Year Extraction**:
   - Financial year in India runs from April 1st to March 31st
   - For FY 2024-25, the financial year value should be 2024 (the starting year)
   - If document shows dates like "26/12/2024 to 25/06/2025", this is FY 2024-25, so financialYear = 2024
   - If document shows "01/04/2024 to 31/03/2025", this is FY 2024-25, so financialYear = 2024
   - Always use the starting year of the financial year, not the ending year
5. For home loan certificates, pay special attention to:
   - **CRITICAL**: Interest amounts are typically LARGER than principal amounts in home loan certificates
   - **Interest amounts** (for Section 24b deduction): Look for columns labeled "Interest (Paid)", "Interest Payable", "Interest Component", or similar. These are usually the larger amounts in EMI breakdowns.
   - **Principal amounts** (for Section 80C deduction): Look for columns labeled "Principal (Paid)", "Principal Payable", "Principal Component", or similar. These are usually the smaller amounts in EMI breakdowns.
   - When you see a table with Interest and Principal columns, ensure you're reading the correct column headers
   - If there's a "Total" row, use the totals from the correct columns
   - Loan account numbers and borrower details
   - Bank information and property details
   - LoanTakenFrom field: Output 'B' for scheduled commercial banks (names containing 'Bank'), 'I' for housing finance companies/NBFCs
   - BorrowerName: Extract only the first/primary borrower name
   - CoOwners: Extract additional borrowers/co-owners as separate entries with names and PAN if available
   - StateInIndia: Use exact enum values like UTTARPRADESH, KARNATAKA, MAHARASHTRA (all caps, no spaces)
   - PrincipalAmount: Should be the total of principal component + principal prepayment
   - **Double-check**: In most home loans, interest paid is significantly higher than principal paid, especially in early years
   - **Address Extraction**: For HouseAddress, extract meaningful values for each field:
    * TownCityDistrict: Extract the city/town name (e.g., "BANGALORE", "MUMBAI", "DELHI")
    * FlatDoorBlockNumber: Extract flat/apartment/door number (e.g., "FLAT 101", "APT A-404", "DOOR 25")
    * PremiseBuildingVillageName: Extract building/society/complex name (e.g., "PRESTIGE TOWERS", "DLF PHASE 2")
    * RoadStreetPostOffice: Extract road/street name (e.g., "MG ROAD", "MAIN STREET", "SECTOR 15")
    * AreaLocality: Extract area/locality/sector (e.g., "KORAMANGALA", "BANDRA WEST", "SECTOR 74")
    * StateInIndia: Use exact enum values (e.g., "KARNATAKA", "MAHARASHTRA", "DELHI")
    * Country: Use "India" for Indian addresses
    * PinCodeOrZipCode: Extract the postal code (e.g., "560001", "400050")
    * **IMPORTANT**: If any address component is not clearly available in the document, intelligently distribute the available address information across all required fields. For example, if only "123 Main Street, Bangalore 560001" is available, extract "123" as FlatDoorBlockNumber, "Main Street" as RoadStreetPostOffice, "Bangalore" as TownCityDistrict, and "560001" as PinCodeOrZipCode. Never use placeholder values.
6. For education loan interest certificates, extract:
   - Loan account number and borrower details
   - Bank or institution information
   - LoanTakenFrom field: Output 'B' for banks, 'O' for other institutions
   - Date of loan sanction
   - Original loan amount and outstanding amount
   - Interest paid under Section 80E
   - Financial year information
7. For medical insurance policies/health cards, extract:
   - Name of the insurance company (insurer)
   - Policy number or health card number
   - Health insurance premium amount paid
   - Policy holder name and PAN
   - Financial year information
   - Policy type if available
   - **Section 80D Classification Flags**:
     * IsPolicyForSelf: True if policy covers taxpayer/spouse, False if covers parents
     * IsPolicyForParents: True if policy covers parents, False if covers self/spouse
     * IsSelfOrSpouseSeniorCitizen: True if taxpayer/spouse is 60+ years old
     * AreParentsSeniorCitizen: True if parents are 60+ years old
     * CoveredMembers: List who is covered (e.g., "Self, Spouse", "Father, Mother")
     * RelationshipToPolicyHolder: Relationship of covered members to policy holder
8. For NPS (National Pension System) statements, extract:
   - **PRAN Number**: Permanent Retirement Account Number (usually 12 digits)
   - **Subscriber Name**: Name of the NPS account holder
   - **Subscriber PAN**: PAN number of the subscriber
   - **Employer Name**: Name of the employer (for corporate NPS accounts)
   - **Financial Year**: Extract from statement period or contribution dates
   - **Total NPS Contribution**: Look for "Total Contribution in your account" or similar fields in Investment Summary
   - **Employee Contribution (80CCD(1))**:
     * Look for employee contributions, self contributions, or Tier I contributions
     * This is typically the main contribution amount eligible under Section 80CCD(1)
     * If only total contribution is available and no breakdown is provided, use the total amount as employee contribution
   - **Employer Contribution (80CCD(2))**:
     * Look for employer contributions or company contributions
     * May be separately mentioned in corporate NPS statements
     * If not explicitly mentioned, this field can be left empty
   - **Additional Contribution (80CCD(1B))**:
     * Look for additional voluntary contributions or Tier I additional contributions
     * This is typically up to Rs. 50,000 and eligible for separate deduction
     * If not explicitly mentioned, this field can be left empty
   - **Statement Period**: Extract the period for which the statement is generated

### Output:
First classify the document, then extract the structured data according to the document type.
"""

async def _perform_llm_processing(file_bytes: bytes, unified_prompt: str, product: Product,
                                                 file_extension: str, password: Optional[str] = None) -> tuple[TaxDocumentClassification, Optional[Any]]:
    """
    Fallback method using enhanced parser (which does text extraction first).
    Only used if direct file processing fails.
    """
    import time
    
    try:
        # Use the unified schema that combines classification with SchemaCommonModel
        from document_service.llm.llm_dataclasses import UnifiedClassificationAndDataSchema
        
        # Create enhanced LLM parser with unified schema for single call
        enhanced_parser = EnhancedLLMDataParserClassifier(
            "gpt-4o",
            0,
            UnifiedClassificationAndDataSchema,
            unified_prompt
        )
        
        # Log LLM call start time
        start_time = time.time()
        logging.info(f"Starting LLM processing for file extension: {file_extension}")
        
        # Single LLM call that does both classification and data extraction
        unified_result = await enhanced_parser.return_schema_from_file(file_bytes, file_extension, password)
        
        # Log LLM call completion time
        end_time = time.time()
        processing_time = end_time - start_time
        logging.info(f"LLM processing completed in {processing_time:.2f} seconds")
        
        # Log the raw LLM response for debugging
        logging.info(f"LLM Classification Result: {unified_result.docType}")
        logging.info(f"LLM Reason: {unified_result.reasonForClassification}")
        logging.info(f"LLM Extracted Data: {unified_result.extractedData}")
        
        # Extract classification from unified result
        classification_result = TaxDocumentClassification(
            reasonForClassification=unified_result.reasonForClassification,
            docType=unified_result.docType,
            docTypeSub=unified_result.docTypeSub
        )
        
        # Extract data - the LLM already structured it in SchemaCommonModel format
        extracted_data = None
        if classification_result.docType != DocumentCategory.DOC_ADDITIONAL_DOC and unified_result.extractedData:
            logging.info(f"Converting extracted data for document type: {classification_result.docType}")
            # Convert SchemaCommonModel to document-specific format using existing mapper
            extracted_data = _convert_common_model_to_document_data(unified_result.extractedData, classification_result.docType)
            logging.info(f"Converted extracted data: {extracted_data}")
        else:
            logging.warning(f"No extracted data found. Document type: {classification_result.docType}, Extracted data: {unified_result.extractedData}")
        
        return classification_result, extracted_data
    
    finally:
        # Force garbage collection after LLM processing to free memory
        gc.collect()


def _convert_common_model_to_document_data(common_model, document_type: DocumentCategory) -> Optional[Any]:
    """Convert SchemaCommonModel to document-specific data format"""
    try:
        # For home loan certificates, extract the SchemaHomeLoanInterest object directly
        if document_type == DocumentCategory.DOC_HOME_LOAN_INTEREST_CERTIFICATE:
            if common_model.Deductions and common_model.Deductions.DeductionsUsSec24B:
                # Return the SchemaHomeLoanInterest object directly, not a common model
                return common_model.Deductions.DeductionsUsSec24B[0]
        elif document_type == DocumentCategory.DOC_80_G:
            if common_model.Deductions and common_model.Deductions.DeductionsUsSec80G:
                # Return the SchemaDeductionUsSec80G object directly
                return common_model.Deductions.DeductionsUsSec80G[0]
        elif document_type == DocumentCategory.SAVINGS_BANK_INTEREST:
            if common_model.OtherIncome and common_model.OtherIncome.SavingsBankInterestIncome:
                # Return the SchemaBasicAmountHead object directly
                return common_model.OtherIncome.SavingsBankInterestIncome[0]
        # Handle Section 80C document types
        elif document_type == DocumentCategory.DOC_EDUCATION_LOAN_INTEREST_CERTIFICATE:
            if common_model.Deductions and common_model.Deductions.DeductionsUsSec80E:
                # Return the SchemaEducationLoanInterest object directly
                return common_model.Deductions.DeductionsUsSec80E[0]
        elif document_type == DocumentCategory.DOC_MEDICAL_INSURANCE_POLICY:
            if common_model.Deductions and common_model.Deductions.DeductionsUsSec80D:
                # Return the SchemaMedicalInsurance object directly
                return common_model.Deductions.DeductionsUsSec80D[0]
        elif document_type == DocumentCategory.DOC_NPS_STATEMENT:
            if common_model.Deductions and common_model.Deductions.NPS:
                # Return the SchemaNPS object directly
                return common_model.Deductions.NPS[0]
        elif document_type in [
            DocumentCategory.DOC_PPF_STATEMENT,
            DocumentCategory.DOC_LIFE_INSURANCE_PREMIUM,
            DocumentCategory.DOC_ELSS_MUTUAL_FUND,
            DocumentCategory.DOC_ULIP_CERTIFICATE,
            DocumentCategory.DOC_EPF_STATEMENT,
            DocumentCategory.DOC_NSC_CERTIFICATE,
            DocumentCategory.DOC_SUKANYA_SAMRIDHI
        ]:
            if common_model.Deductions and common_model.Deductions.DeductionsUsSec80C:
                # Return the Schema80CInvestment object directly
                return common_model.Deductions.DeductionsUsSec80C[0]
        
        # If no specific extraction logic, return the common model as-is
        return common_model
            
    except Exception as e:
        logging.warning(f"Failed to convert common model to document-specific format: {e}")
        return common_model

async def _update_document_with_results(processing_step: UnifiedLLMProcessingStep,
                                      classification_result: TaxDocumentClassification,
                                      extracted_data: Optional[Any],
                                      llm_used: bool):
    """Update document with both classification and extracted data"""
    try:
        document_category = classification_result.docType.name
        # Convert NOT_INITIALIZED to empty string for database storage
        if classification_result.docTypeSub and classification_result.docTypeSub.name != "NOT_INITIALIZED":
            document_subcategory = classification_result.docTypeSub.name
        else:
            document_subcategory = ""
        
        logging.info(f"Updating document ID {processing_step.document_id} to type {document_category} - {document_subcategory}.")
        
        # Get or validate document type configuration
        try:
            config = await DocumentTypeConfiguration.objects.aget(
                document_category=document_category,
                document_subcategory=document_subcategory,
                product=processing_step.product
            )
        except DocumentTypeConfiguration.DoesNotExist:
            if document_subcategory:
                logging.warning(f"Document type configuration for {document_category} - {document_subcategory} not found for product {processing_step.product}. Trying category only.")
                document_subcategory = ""
                try:
                    config = await DocumentTypeConfiguration.objects.aget(
                        document_category=document_category,
                        document_subcategory="",
                        product=processing_step.product
                    )
                except DocumentTypeConfiguration.DoesNotExist:
                    logging.warning(f"No document type configuration found for {document_category} in product {processing_step.product}. Falling back to DOC_ADDITIONAL_DOC.")
                    # Fallback to DOC_ADDITIONAL_DOC
                    try:
                        config = await DocumentTypeConfiguration.objects.aget(
                            document_category=DocumentCategory.DOC_ADDITIONAL_DOC.name,
                            document_subcategory="",
                            product=processing_step.product
                        )
                    except DocumentTypeConfiguration.DoesNotExist:
                        logging.error(f"Critical error: DOC_ADDITIONAL_DOC configuration not found for product {processing_step.product}")
                        raise Exception(f"Critical error: DOC_ADDITIONAL_DOC configuration not found for product {processing_step.product}")
            else:
                logging.warning(f"No document type configuration found for {document_category} in product {processing_step.product}. Falling back to DOC_ADDITIONAL_DOC.")
                # Fallback to DOC_ADDITIONAL_DOC
                config = await DocumentTypeConfiguration.objects.aget(
                        document_category=DocumentCategory.DOC_ADDITIONAL_DOC.name,
                        document_subcategory="",
                        product=processing_step.product
                    )
              
        
        # Prepare data for database update
        update_data = {
            'document_type_configuration': config,
            'llm_classified': llm_used,  # True only if LLM was used for classification
            'llm_parsed': bool(extracted_data),  # True if we have structured data
        }
        
        # Store the extracted data
        if extracted_data:
            # Compress the structured extracted data
            compressed_structured_data = await CompressionService.compress_data_async(extracted_data.model_dump())
            update_data['extracted_data'] = compressed_structured_data
        
        # Update document with all information
        await DocumentService.update_document(processing_step.document_id, **update_data)
        
    except Exception as e:
        logging.error(f"Failed to update document with unified result for document_id {processing_step.document_id}: {e}")
        raise Exception("Error updating document with unified result in the database.")


async def _determine_next_activity(document_id: int, user_sid: str, metadata: Optional[Metadata] = None) -> NextActivityDetails:
    """Determine the next activity based on the document type and prepare the request data."""
    # Import the helper function for determining next activity
    from temporal_service.activities.next_activity_helper import _get_next_activity_and_request
    
    # Get document with updated information
    document = await DocumentService.get_document(document_id)
    
    # Check if this document was processed by unified LLM and has structured data ready (LLM was used for both classification AND parsing)
    if document.llm_classified and document.llm_parsed and document.extracted_data:
        # For documents where LLM did both classification and parsing, we skip the parser activities
        # since we already have the structured data
        decompressed_data = await CompressionService.decompress_data_async(document.extracted_data)
        document_type = DocumentCategory[document.document_type_configuration.document_category]
        from document_service.llm.document_dataclass_mapper import wrap_llm_modeled_data_common_model
        transformed_data = wrap_llm_modeled_data_common_model(decompressed_data, document_type)

        # Get the standard next activity details
        next_activity_details = await _get_next_activity_and_request(document, user_sid, metadata)
        
        # Override to skip parsing since we already have the data
        # The workflow will check if parser_activity_name is None and skip parsing step
        # Note: parser_activity_request_data now contains the final transformed data, not request data
        next_activity_details.parser_activity_name = None
        next_activity_details.llm_transformed_data = transformed_data
        next_activity_details.parser_task_queue = None

        return next_activity_details
    else:
        # For regex-classified documents (llm_classified=False) or documents without extracted data,
        # use the standard logic which will schedule appropriate parser activities on their configured servers
        return await _get_next_activity_and_request(document, user_sid, metadata)