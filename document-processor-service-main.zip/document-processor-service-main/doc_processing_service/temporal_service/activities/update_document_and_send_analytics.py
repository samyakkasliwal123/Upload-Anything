# temporal_service/activities/update_document_and_send_analytics.py
import logging
from temporalio import activity

from document_service.models import NextActivityDetails, Document
from services.documentdb_service import DocumentService
from services.compression_utils import CompressionService
from services.logging_utils import LoggingService
from configuration import Config
from doc_processing_service.temporal_service.utils.metrics.latency import ActivityMetricTimer
from doc_processing_service.analytics.eventQueue import EventQueue
from doc_processing_service.analytics.models import DocumentEvent

# Initialize metric timer
update_and_analytics_timer = ActivityMetricTimer(
    "update_and_analytics_latency_ms",
    "Latency for combined update parsed data and send analytics activity steps"
)

@activity.defn(name="update_parsed_data_and_send_analytics_activity")
async def update_parsed_data_and_send_analytics_activity(
    document_id: int, 
    parsed_data: dict, 
    status: str, 
    error: str = "", 
    activity_name: str = "FinalDocumentUpdate"
) -> NextActivityDetails:
    """
    Combined activity that updates document with parsed data and sends analytics event.
    
    Args:
        document_id: The ID of the document to update.
        parsed_data: The parsed document data to store.
        status: The status to set for the document.
        error: Error message for analytics (optional).
        activity_name: Name of the activity for analytics tracking.
    """
    logger = LoggingService.get_logger(__name__)
    
    try:
        # Step 1: Update document with parsed data
        with update_and_analytics_timer.time({
            "step": "compress_data",
            "document_id": str(document_id),
        }):
            compressed_data = await CompressionService.compress_data_async(parsed_data)

        with update_and_analytics_timer.time({
            "step": "update_database",
            "document_id": str(document_id),
        }):
            await DocumentService.update_document(
                document_id,
                extracted_data=compressed_data,
                status=status
            )

        logger.info(f"Successfully updated document {document_id} with parsed data and status {status}")

        # Step 2: Send analytics event
        with update_and_analytics_timer.time({
            "step": "send_analytics",
            "document_id": str(document_id),
        }):
            await _send_analytics_for_document(document_id, error, status, activity_name, logger)

        logger.info(f"Successfully sent analytics for document {document_id}")

    except Exception as e:
        logger.error(f"Error in combined update and analytics for document {document_id}: {e}")
        # Still try to send analytics about the failure
        try:
            await _send_analytics_for_document(document_id, str(e), "FAILED", activity_name, logger)
        except Exception as analytics_error:
            logger.error(f"Failed to send analytics about failure for document {document_id}: {analytics_error}")
        
        raise Exception("Failed to update parsed data and send analytics.")


async def _send_analytics_for_document(document_id: int, error: str, status: str, activity_name: str, logger):
    """Helper function to send analytics event for a document."""
    try:
        # Fetch document from DB
        document = await DocumentService.get_document(document_id)
        
        logger.info(f"Sending analytics for document id: {document.document_id}")

        event = DocumentEvent(
            document_id=document.document_id,
            user_id=str(document.user_id),
            file_name=document.document_name,
            file_password=document.password,
            product=document.product,
            workflow_id=document.workflow_id,
            scope_id=document.scope,
            file_url=document.s3_url,
            classified_type=document.document_category,
            classified_subtype=document.document_subcategory,
            llm_parsed=document.llm_parsed,
            llm_classified=document.llm_classified,
            error=error,
            status=f"{activity_name} : {status}",
        )
        EventQueue.get_instance().add_event(event)
        
    except Document.DoesNotExist:
        logger.error(f"Document with id {document_id} does not exist.")
        raise
    except Exception as e:
        logger.error(f"Error sending analytics for document with id {document_id}: {e}")
        raise