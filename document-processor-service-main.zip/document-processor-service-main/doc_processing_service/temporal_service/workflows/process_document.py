import json
import logging
import uuid
from datetime import timedelta
from typing import cast

from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ActivityError, ApplicationError

from .workflow_status import Status

with workflow.unsafe.imports_passed_through():
    from doc_processing_service.temporal_service.activities import (
        validate_file,
        notify_document_activity_details,
        send_analytics,
    )
    from doc_processing_service.temporal_service.activities.update_document_and_send_analytics import (
        update_parsed_data_and_send_analytics_activity
    )
    from doc_processing_service.temporal_service.activities.unified_llm_processor import (
        unified_llm_classify_transform_activity, UnifiedLLMProcessingStep
    )
    from doc_processing_service.temporal_service.activities.dataclasses import (
        ValidateFileStep,
        Metadata,
    )


@workflow.defn
class DocumentProcessingWorkflow:
    def __init__(self):
        self.status = Status.INITIATING.name
        self.error_message = None
        self.document_name = None
        self.document_id = None
        self.user_session_id = None
        self._failure_handled = False
        self._notifying_failure = False  # Recursion guard

    def _update_status(self, new_status: Status):
        self.status = new_status.name

    def _set_context(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def _record_error(self, err: Exception):
        if isinstance(err, ActivityError) and isinstance(err.cause, Exception):
            cause = cast(Exception, err.cause)
            if isinstance(cause, ApplicationError):
                self.error_message = f"{cause.type}: {cause.message}"
            else:
                self.error_message = f"{type(cause).__name__}: {str(cause)}"
        elif isinstance(err, ApplicationError):
            self.error_message = f"{type(err).__name__}: {str(err)}"
        else:
            self.error_message = str(err)

    async def _send_analytics_immediate(self, activity_name: str):
        try:
            # Only send analytics for critical events to reduce overhead
            if self.status in ['COMPLETED', 'INVALID_FILE', 'CLASSIFYING_DOCUMENT_FAILED']:
                logging.info(f"Sending analytics for {activity_name} - {self.status} - {self.error_message}")
                await workflow.execute_activity(
                    send_analytics.send_analytics_activity,
                    args=[self.document_id, self.error_message, self.status, activity_name],
                    retry_policy=RetryPolicy(maximum_attempts=1),
                    start_to_close_timeout=timedelta(seconds=5),  # Reduced timeout
                    task_queue="document-activity-queue"
                )
            else:
                # For non-critical events, just log locally
                logging.debug(f"Skipping analytics for intermediate status: {activity_name} - {self.status}")
        except Exception as e:
            workflow.logger.warning(f"Analytics reporting failed for {activity_name}: {e}")

    async def _run_activity_with_error_capture(self, activity_func, args, status_on_failure, activity_name,
                                               timeout, retry_count=2, non_retryable_errors=None, **kwargs):
        try:
            return await workflow.execute_activity(
                activity_func,
                args=args,
                retry_policy=RetryPolicy(maximum_attempts=retry_count,
                                         non_retryable_error_types=non_retryable_errors or []),
                start_to_close_timeout=timeout,
                **kwargs,
            )
        except Exception as e:
            if isinstance(e, ActivityError):
                if (
                        e.failure
                        and e.failure.cause
                        and hasattr(e.failure.cause, "application_failure_info")
                        and e.failure.cause.application_failure_info
                        and e.failure.cause.application_failure_info.type == "InvalidFileException"
                ):
                    self._update_status(Status.INVALID_FILE)
            else :
                self._update_status(status_on_failure)

            self._record_error(e)
            await self._send_analytics_immediate(activity_name)

            # Prevent recursion
            if not self._notifying_failure:
                await self.notify_failure()
            raise

    @workflow.run
    async def run(self, s3_key: str, user_id: uuid.UUID, file_name: str, file_extension: str,
                  product: str, scope: str, meta_data: dict, user_sid: str) -> None:
        self._set_context(document_name=file_name, user_session_id=user_sid)
        self._update_status(Status.INITIATING)
        # log workflow started with workflow id
        workflow.logger.info(f"Workflow started with ID: {workflow.info().workflow_id}")

        try:
            # Step 1: Validate the file
            validation_res = await self._validate_file(
                s3_key, user_id, file_name, file_extension, product, scope, meta_data
            )
            if validation_res.status :
                if validation_res.status == Status.INVALID_FILE:
                    await self.notify_failure()
                return

            # Step 2: Use unified processor (tries regex first, then LLM if needed)
            next_activity_details = await self._unified_llm_classify_and_transform(
                validation_res, s3_key, file_extension, product
            )
            
            # If classification failed, fail the workflow
            if (next_activity_details.classified_type and
                next_activity_details.classified_type.lower() == "doc_additional_doc"):
                self._update_status(Status.CLASSIFYING_DOCUMENT_FAILED)
                await self.notify_failure()
                return

            # Step 3: Parse (skip if unified LLM already processed)
            if next_activity_details.parser_activity_name is not None:
                parsed_result = await self._parse_document(next_activity_details)
            else:
                # Unified LLM processor already provided the transformed data
                parsed_result = next_activity_details.llm_transformed_data

            # Step 4: Send to product
            transformed_data = await self._update_to_product(next_activity_details, parsed_result)
            if not transformed_data:
                raise ApplicationError("No Transformed Data received for final update")

            # Step 5: Final update
            await self._final_document_update(transformed_data)
        finally:
            # Analytics is now handled by the combined activity in _final_document_update
            # Only send analytics here if there was an error and we didn't reach final update
            if self.error_message and self.status != Status.COMPLETED.name:
                await self._send_analytics_immediate("Workflow.Final")

    async def _validate_file(self, s3_key, user_id, file_name, file_extension, product, scope, meta_data):
        self._update_status(Status.VALIDATING_DOCUMENT)
        validate_step = ValidateFileStep(
            s3_key=s3_key,
            file_extension=file_extension,
            meta_data=meta_data,
            user_id=user_id,
            file_name=file_name,
            product=product,
            scope=scope,
            workflow_id=str(workflow.info().workflow_id)
        )
        res = await self._run_activity_with_error_capture(
            validate_file.validate_and_save_uploaded_file,
            [validate_step],
            Status.VALIDATION_FAILED,
            "ValidateFile",
            timedelta(seconds=10),
            retry_count=1,
            non_retryable_errors=["PasswordNeededException", "PasswordIncorrectException", "InvalidFileException", "FileTooBigException"],
            task_queue = "document-activity-queue"
        )
        self.document_id = res.document_id
        if res.status:
            # Convert Status enum to string for database storage
            self._update_status(res.status)
            # Also update the document status in database immediately for validation failures
            if res.status in [Status.PASSWORD_REQUIRED, Status.PASSWORD_INCORRECT, Status.INVALID_FILE,
                             Status.TOO_BIG_FILE, Status.INVALID_META_DATA]:
                try:
                    await workflow.execute_activity(
                        update_parsed_data_and_send_analytics_activity,
                        args=[self.document_id, {}, res.status.name, res.error or "", "ValidationFailed"],
                        retry_policy=RetryPolicy(maximum_attempts=1),
                        start_to_close_timeout=timedelta(seconds=5),
                        task_queue="document-activity-queue"
                    )
                except Exception as e:
                    workflow.logger.warning(f"Failed to update document status for validation failure: {e}")
        return res

    async def _unified_llm_classify_and_transform(self, validation_res, s3_key, file_extension, product):
        """Use unified LLM processor when regex classification fails"""
        self._update_status(Status.EXTRACTING_TEXT)  # Reuse same status
        metadata = Metadata(data_assignment_index=validation_res.validated_meta_data.get("index")) \
            if validation_res.validated_meta_data and "index" in validation_res.validated_meta_data else None

        unified_step = UnifiedLLMProcessingStep(
            document_id=self.document_id,
            s3_key=s3_key,
            file_extension=file_extension,
            password=validation_res.validated_password,
            product=product,
            user_sid=self.user_session_id,
            metadata=metadata,
        )

        return await self._run_activity_with_error_capture(
            unified_llm_classify_transform_activity,
            [unified_step],
            Status.TEXT_EXTRACTION_FAILED,
            "UnifiedLLMClassifyTransform",
            timedelta(seconds=60),  # Longer timeout for LLM processing
            non_retryable_errors=["PasswordNeededException", "InvalidFileException", "LLMClassificationFailed"],
            task_queue="document-activity-queue",
        )

    async def _parse_document(self, next_activity_details):
        self._update_status(Status.PARSING_DOCUMENT)
        return await self._run_activity_with_error_capture(
            next_activity_details.parser_activity_name,
            [next_activity_details.parser_activity_request_data],
            Status.PARSING_DOCUMENT_FAILED,
            "ParseDocument",
            timedelta(seconds=10),
            task_queue=next_activity_details.parser_task_queue,
        )

    async def _update_to_product(self, next_activity_details, parsed_result):
        self._update_status(Status.UPDATING_DOCUMENT_TO_PRODUCT)
        try:
            # Check if notify_activity_request_data exists before trying to set DocumentData
            if next_activity_details.notify_activity_request_data is None:
                document_type = next_activity_details.classified_type or "Unknown"
                raise ApplicationError(f"No notify activity configured for document type: {document_type}")
            next_activity_details.notify_activity_request_data.DocumentData = json.dumps(parsed_result)
        except json.JSONDecodeError:
            raise ApplicationError("Invalid JSON data received from the parser activity")

        return await self._run_activity_with_error_capture(
            next_activity_details.notify_activity_name,
            [next_activity_details.notify_activity_request_data],
            Status.UPDATING_DOCUMENT_TO_PRODUCT_FAILED,
            "UpdateToProduct",
            timedelta(seconds=10),
            task_queue=next_activity_details.notify_task_queue,
        )

    async def _final_document_update(self, transformed_data):
        self._update_status(Status.UPDATING_DOCUMENT_WITH_PARSED_DATA)
        await self._run_activity_with_error_capture(
            update_parsed_data_and_send_analytics_activity,
            [self.document_id, transformed_data, Status.COMPLETED.name, "", "FinalDocumentUpdate"],
            Status.UPDATING_DOCUMENT_FAILED,
            "FinalDocumentUpdate",
            timedelta(seconds=10),  # Increased timeout since we're doing two operations
            task_queue="document-activity-queue",
        )
        self._update_status(Status.COMPLETED)

    async def notify_failure(self) -> bool:
        if self._failure_handled or not self.document_id:
            return self._failure_handled

        self._notifying_failure = True

        try:
            notify_activity_details = await self._run_activity_with_error_capture(
                notify_document_activity_details.get_notify_document_activity_details,
                [self.document_id, self.user_session_id],
                Status.NOTIFY_FAILED,
                "NotifyDocumentDetails",
                timedelta(seconds=10),
                task_queue="document-activity-queue",
            )

            status_response = await self._run_activity_with_error_capture(
                notify_activity_details.notify_activity_name,
                [notify_activity_details.notify_activity_request_data],
                Status.NOTIFY_FAILED,
                "NotifyActivity",
                timedelta(seconds=10),
                task_queue=notify_activity_details.notify_task_queue,
            )

            if status_response:
                await self._run_activity_with_error_capture(
                    update_parsed_data_and_send_analytics_activity,
                    [self.document_id, status_response, self.status, self.error_message or "", "NotifyUpdateDocument"],
                    Status.NOTIFY_FAILED,
                    "NotifyUpdateDocument",
                    timedelta(seconds=15),  # Increased timeout since we're doing two operations
                    task_queue="document-activity-queue",
                )
        except Exception as e:
            workflow.logger.error(f"Failed to notify failure: {e}")
        finally:
            self._failure_handled = True
            self._notifying_failure = False
            return self._failure_handled

    @workflow.query
    def get_last_status_and_document_name(self) -> str:
        return self.status