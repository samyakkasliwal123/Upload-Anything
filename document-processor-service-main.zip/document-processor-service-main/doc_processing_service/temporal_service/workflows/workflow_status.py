from enum import Enum


class Status(str, Enum):
    INITIATING = "Initiating"
    VALIDATING_DOCUMENT = "Validating document"
    VALIDATION_FAILED = "Validation failed"
    UPLOADING_FILE = "Uploading file"
    EXTRACTING_TEXT = "Extracting text from the document"
    CLASSIFYING_DOCUMENT = "Classifying document"
    PARSING_DOCUMENT = "Parsing document"
    UPDATING_DOCUMENT_TO_PRODUCT = "Updating document to product"
    UPDATING_DOCUMENT_WITH_PARSED_DATA = "Updating document with parsed data"
    FILE_UPLOADING_FAILED = "File Uploading Failed"
    PASSWORD_REQUIRED = "Password Required"
    PASSWORD_INCORRECT = "Password Incorrect"
    TEXT_EXTRACTION_FAILED = "Text Extraction Failed"
    CLASSIFYING_DOCUMENT_FAILED = "Failed classifying document"
    PARSING_DOCUMENT_FAILED = "Failed parsing document"
    UPDATING_DOCUMENT_FAILED = "Failed updating document to product"
    TOO_BIG_FILE = "File is too big"
    INVALID_FILE = "Invalid file"
    INVALID_META_DATA = "Invalid file meta data"
    COMPLETED = "Completed"
    UPDATING_DOCUMENT_TO_PRODUCT_FAILED = "Updating document to product failed"
    FAILED = "Failed"
    NOTIFY_FAILED = "Notify failed"

