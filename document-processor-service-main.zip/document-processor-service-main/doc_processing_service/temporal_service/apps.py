from django.apps import AppConfig


class TemporalServiceConfig(AppConfig):
    name = 'temporal_service'
