import os
from typing import List
from temporalio.api.common.v1 import Payload
from temporalio.converter import PayloadCodec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from configuration import Config

NONCE_SIZE = 12
TAG_SIZE = 16
ENCODING = "binary/encrypted"


class EncryptionCodec(PayloadCodec):
    DefaultKeyID = Config.PAYLOAD_KEY_ID
    DefaultKey = str.encode(Config.PAYLOAD_ENCRYPTION_KEY)  # 32 bytes key (AES-256)

    def __init__(self, key_id: str = DefaultKeyID, key: bytes = None):
        self.key_id = key_id
        self.key_id_bytes = key_id.encode('utf-8')  # keyID as bytes
        self.key = key or self.DefaultKey
        self.encoding_byte_string = ENCODING.encode('utf-8')
    async def encode(self, payloads: List[Payload]) -> List[Payload]:
        encoded_payloads = []
        for payload in payloads:
            if not payload.data:  # Handle empty payloads
                encoded_payloads.append(payload)
                continue

            encrypted_data = self.encrypt(payload.SerializeToString())
            new_payload = Payload(
                metadata={
                    "encoding": self.encoding_byte_string,
                    "encryption-key-id": self.key_id_bytes,
                },
                data=encrypted_data,
            )
            encoded_payloads.append(new_payload)
        return encoded_payloads

    async def decode(self, payloads: List[Payload]) -> List[Payload]:
        decoded_payloads = []
        for payload in payloads:
            if not payload.data:
                decoded_payloads.append(payload)
                continue

            if payload.metadata.get("encoding") != self.encoding_byte_string:
                decoded_payloads.append(payload)
                continue

            key_id = payload.metadata.get("encryption-key-id")
            if key_id != self.key_id_bytes:
                raise ValueError(f"Unrecognized key ID {key_id}, expected {self.key_id}")

            decrypted_data = self.decrypt(payload.data)
            decrypted_payload = Payload.FromString(decrypted_data)
            decoded_payloads.append(decrypted_payload)
        return decoded_payloads

    def encrypt(self, data: bytes) -> bytes:
        nonce = os.urandom(NONCE_SIZE)
        aesgcm = AESGCM(self.key)
        ciphertext = aesgcm.encrypt(nonce, data, None)  # Tag is automatically appended
        return nonce + ciphertext

    def decrypt(self, data: bytes) -> bytes:
        nonce = data[:NONCE_SIZE]
        ciphertext = data[NONCE_SIZE:]
        aesgcm = AESGCM(self.key)
        return aesgcm.decrypt(nonce, ciphertext, None)
