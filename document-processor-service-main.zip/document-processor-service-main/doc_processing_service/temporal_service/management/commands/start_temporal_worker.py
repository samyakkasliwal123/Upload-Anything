import asyncio
import dataclasses
import gc
import multiprocessing
import os
import signal
import logging
import socket
from concurrent.futures import ThreadPoolExecutor # Import ProcessPoolExecutor
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
import sentry_sdk
from temporalio import workflow
from temporalio.worker import Worker
from temporalio.client import Client
from temporalio.converter import default
from temporalio.runtime import Runtime, TelemetryConfig, PrometheusConfig

from configuration import Config
from temporal_service.activities import (
    validate_file,
    notify_document_activity_details,
)
from temporal_service.activities.unified_llm_processor import unified_llm_classify_transform_activity
from doc_processing_service.temporal_service.activities.update_document_and_send_analytics import (
    update_parsed_data_and_send_analytics_activity
)
from doc_processing_service.analytics.eventQueue import EventQueue
from doc_processing_service.services.event_loop_monitor import event_loop_monitor
from doc_processing_service.temporal_service.activities import send_analytics
from temporal_service.data_converter import EncryptionCodec
from temporal_service.workflows.process_document import DocumentProcessingWorkflow


with workflow.unsafe.imports_passed_through():
    from django.core.management.base import BaseCommand

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Task Queues - Simplified since all activities are now async
WORKFLOW_TASK_QUEUE = "document-workflow-queue"
ACTIVITY_TASK_QUEUE = "document-activity-queue"

async def create_temporal_client():
    logger.info("Connecting to Temporal service...")
    logger.info(f"Temporal service address: {Config.TEMPORAL_SERVICE_ADDRESS}")
    new_runtime = Runtime(
        telemetry=TelemetryConfig(
            metrics=PrometheusConfig(bind_address="0.0.0.0:9464")
        )
    )
    return await Client.connect(
        Config.TEMPORAL_SERVICE_ADDRESS,
        namespace=Config.TEMPORAL_NAMESPACE,
        data_converter=dataclasses.replace(default(), payload_codec=EncryptionCodec()),
        runtime=new_runtime,
        rpc_metadata={"connection-pool-size": "20"}  # Reduced from 50 to 10 to match activity concurrency
    )

async def start_workers(client):
    hostname = socket.gethostname()
    pid = multiprocessing.current_process().pid

    logger.info(f"[{hostname}] Starting workers (PID {pid})")
    
    # Workflow worker - Optimized for higher throughput
    workflow_worker = Worker(
        client,
        task_queue=WORKFLOW_TASK_QUEUE,
        workflows=[DocumentProcessingWorkflow],
        activities=[],
        max_concurrent_workflow_task_polls=Config.TEMPORAL_MAX_WORKFLOW_TASK_POLLS,
        max_concurrent_workflow_tasks=Config.TEMPORAL_MAX_CONCURRENT_WORKFLOWS,
        # Add workflow task timeout to prevent hanging
    )
    
    # Unified Activity Worker - Optimized for async operations and higher concurrency
    activity_worker = Worker(
        client,
        task_queue=ACTIVITY_TASK_QUEUE,
        workflows=[],
        activities=[
            # Database and I/O activities
            update_parsed_data_and_send_analytics_activity,
            notify_document_activity_details.get_notify_document_activity_details,
            send_analytics.send_analytics_activity,
            validate_file.validate_and_save_uploaded_file,
            # Processing activities (now async)
            unified_llm_classify_transform_activity,
        ],
        # Memory-optimized thread pool: Match thread count to concurrent activities
        activity_executor=ThreadPoolExecutor(
            max_workers=Config.TEMPORAL_THREAD_POOL_SIZE,
            thread_name_prefix="temporal-activity"
        ),
        max_concurrent_activity_task_polls=Config.TEMPORAL_MAX_ACTIVITY_TASK_POLLS,
        max_concurrent_activities=Config.TEMPORAL_MAX_CONCURRENT_ACTIVITIES
    )

    logger.info(f"[{hostname}] Workflow worker registered for queue '{WORKFLOW_TASK_QUEUE}'")
    logger.info(f"[{hostname}] Activity worker registered for queue '{ACTIVITY_TASK_QUEUE}' with {Config.TEMPORAL_THREAD_POOL_SIZE} threads (memory optimized)")
    logger.info(f"[{hostname}] Max concurrent activities: {Config.TEMPORAL_MAX_CONCURRENT_ACTIVITIES} (memory optimized)")
    logger.info(f"[{hostname}] Max concurrent workflows: {Config.TEMPORAL_MAX_CONCURRENT_WORKFLOWS} (memory optimized)")

    EventQueue.get_instance().start_worker()
    
    # Start event loop monitoring
    await event_loop_monitor.start_monitoring()
    logger.info(f"[{hostname}] Event loop monitoring started")
    
    # Start periodic memory cleanup task
    async def periodic_memory_cleanup():
        """Periodic memory cleanup to prevent memory leaks."""
        while True:
            try:
                await asyncio.sleep(300)  # Run every 5 minutes
                collected = gc.collect()
                if collected > 0:
                    logger.info(f"[{hostname}] Periodic cleanup freed {collected} objects")
            except Exception as e:
                logger.warning(f"[{hostname}] Memory cleanup error: {e}")
    
    # Start the cleanup task
    asyncio.create_task(periodic_memory_cleanup())
    logger.info(f"[{hostname}] Periodic memory cleanup started (every 5 minutes)")

    async def shutdown_workers():
        logger.info(f"[{hostname}] Shutting down workers...")
        event_loop_monitor.stop_monitoring()
        await asyncio.gather(
            workflow_worker.shutdown(),
            activity_worker.shutdown(),
        )
        sentry_sdk.capture_message("All Temporal workers shut down")

    loop = asyncio.get_event_loop()
    loop.add_signal_handler(signal.SIGTERM, lambda: asyncio.create_task(shutdown_workers()))

    logger.info(f"[{hostname}] Running Temporal workers now")
    sentry_sdk.capture_message("Temporal workers started")

    await asyncio.gather(
        workflow_worker.run(),
        activity_worker.run(),
    )

class HealthCheckHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/ht/":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")
        elif self.path == "/health/":
            self._handle_health_check()
        elif self.path == "/metrics/":
            self._handle_metrics()
        else:
            self.send_response(404)
            self.end_headers()
    
    def _handle_health_check(self):
        """Enhanced health check with event loop metrics."""
        try:
            import json
            health_status = event_loop_monitor.get_health_status()
            current_metrics = event_loop_monitor.get_current_metrics()
            
            response = {
                "status": health_status["status"],
                "message": health_status["message"],
                "timestamp": current_metrics.timestamp,
                "metrics": {
                    "event_loop_lag_ms": round(current_metrics.avg_lag_ms, 2),
                    "cpu_percent": round(current_metrics.cpu_percent, 2),
                    "memory_percent": round(current_metrics.memory_percent, 2),
                    "active_tasks": current_metrics.active_tasks,
                    "pending_tasks": current_metrics.pending_tasks
                }
            }
            
            # Set HTTP status based on health
            if health_status["status"] == "critical":
                self.send_response(503)  # Service Unavailable
            elif health_status["status"] == "warning":
                self.send_response(200)  # OK but with warnings
            else:
                self.send_response(200)  # Healthy
            
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response, indent=2).encode())
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_response = {"status": "error", "message": str(e)}
            self.wfile.write(json.dumps(error_response).encode())
    
    def _handle_metrics(self):
        """Detailed metrics endpoint."""
        try:
            import json
            metrics_5min = event_loop_monitor.get_metrics_summary(5)
            metrics_1min = event_loop_monitor.get_metrics_summary(1)
            
            response = {
                "last_5_minutes": metrics_5min,
                "last_1_minute": metrics_1min,
                "current": event_loop_monitor.get_current_metrics().__dict__
            }
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response, indent=2, default=str).encode())
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_response = {"status": "error", "message": str(e)}
            self.wfile.write(json.dumps(error_response).encode())

def start_health_check_server():
    server = HTTPServer(("0.0.0.0", 8000), HealthCheckHandler)
    logger.info("Health check server started on port 8000")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Health check server shutting down...")
        server.server_close()

def configure_sentry():
    sentry_enabled = os.getenv("SENTRY_ENABLED", "false")
    if sentry_enabled.lower() == "true":
        dsn = os.getenv("SENTRY_DSN")
        environment = os.getenv("CURRENT_ENVIRONMENT", "development")
        release = os.getenv("RELEASE_VERSION", "unknown")

        sentry_sdk.init(
            dsn=dsn,
            environment=environment,
            release=release,
            server_name="temporal-worker",
        )

def setup_asyncio_exception_logging():
    def handle_exception(loop, context):
        msg = context.get("exception", context["message"])
        logger.error(f"Caught unhandled exception: {msg}", exc_info=True)
        if sentry_sdk.Hub.current.client is not None:
            sentry_sdk.capture_exception(context.get("exception"))

    asyncio.get_event_loop().set_exception_handler(handle_exception)

async def main():
    Thread(target=start_health_check_server, daemon=True).start()
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    import django
    django.setup()

    configure_sentry()
    setup_asyncio_exception_logging()
    
    # Set memory-optimized default thread pool for asyncio.to_thread() operations
    # This will be used by S3, Redis, compression operations
    loop = asyncio.get_running_loop()
    # Use smaller thread pool for default executor to reduce memory usage
    default_thread_pool_size = min(Config.TEMPORAL_THREAD_POOL_SIZE, 15)  # Cap at 15 threads
    default_executor = ThreadPoolExecutor(
        max_workers=default_thread_pool_size,
        thread_name_prefix="asyncio-default"
    )
    loop.set_default_executor(default_executor)
    logger.info(f"Set memory-optimized default thread pool size to {default_thread_pool_size} for asyncio.to_thread() operations")

    try:
        client = await create_temporal_client()
        await start_workers(client)
    except Exception as e:
        logger.error("Failed to run workers", exc_info=e)
        if sentry_sdk.Hub.current.client is not None:
            sentry_sdk.capture_exception(e)

class Command(BaseCommand):
    help = "Start Temporal Python Django-aware Worker"

    def handle(self, *args, **options):
        asyncio.run(main())