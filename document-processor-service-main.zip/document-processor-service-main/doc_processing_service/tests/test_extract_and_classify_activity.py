import os
import pytest
import logging
from unittest.mock import AsyncMock, patch, MagicMock

from doc_processing_service.temporal_service.activities.dataclasses import UnifiedLLMProcessingStep, Metadata
from doc_processing_service.temporal_service.activities.unified_llm_processor import _unified_classify_and_process_file
from doc_processing_service.tests.classification_test_cases import classification_cases


@pytest.mark.asyncio
@pytest.mark.parametrize("test_case", classification_cases)
@patch("doc_processing_service.services.documentdb_service.DocumentService.ensure_connection_health", new_callable=AsyncMock)
async def test_classify_multiple_documents(mock_ensure_connection, test_case):
    file_path = os.path.join(os.path.dirname(__file__), test_case["file_path"])
    with open(file_path, "rb") as f:
        file_bytes = f.read()

    # Extract metadata from test case
    s3_key = f"test/{os.path.basename(file_path)}"
    file_extension = os.path.splitext(file_path)[1]
    product = "ITR"

    processing_step = UnifiedLLMProcessingStep(
        document_id=1,
        s3_key=s3_key,
        file_extension=file_extension,
        product=product,
        password=test_case["password"],
        user_sid="user-xyz",
        metadata=Metadata()
    )

    # Use the unified classification function
    classification_result, extracted_data, llm_used = await _unified_classify_and_process_file(
        file_bytes, processing_step.product, processing_step.file_extension, processing_step.password
    )

    # Extract the actual category and subcategory names
    document_category = classification_result.docType.name
    document_subcategory = classification_result.docTypeSub.name if classification_result.docTypeSub.name != "NOT_INITIALIZED" else ""

    assert document_category == test_case["expected_category"], f"Expected category {test_case['expected_category']} but got {document_category}"
    assert document_subcategory == test_case["expected_subcategory"], f"Expected subcategory {test_case['expected_subcategory']} but got {document_subcategory}"
    assert llm_used == False, f"Expected LLM usage to be False but got {llm_used}"


    logging.info(f"✅ Classified {file_path} as: {document_category} / {document_subcategory} | LLM: {llm_used}")