# doc_processing_service/permissions.py
import asyncio
import logging

from asgiref.sync import async_to_sync

from rest_framework.permissions import BasePermission
from rest_framework.exceptions import PermissionDenied
from configuration import Config
from document_service.models import PermissionType, Document
from services.user_authorization_service import AuthorizationService


class CustomAuthorizationPermission(BasePermission):

    def has_permission(self, request, view):
        session_id = request.COOKIES.get('sid')
        if not session_id:
            return False

        user_info = request.user
        if not user_info:
            return False

        auth_service = AuthorizationService(Config.AUTH_SERVICE_BASEURL)
        scope = request.GET.get('scope') if request.GET.get('scope') else request.data.get('scope')
        
        async def get_permissions():
            return await auth_service.get_auth_permissions_v2(
                session_id, "TAX_RECORD", scope, user_info.externalId
            )

        user_permissions = async_to_sync(get_permissions)()

        if not user_permissions or not any(
                per.name in [PermissionType.READ, PermissionType.WRITE] for per in user_permissions.permissions):
            # Log the permission check failure
            logging.error(f"Permission denied for user {user_info.externalId} on scope {scope}. "
                          f"Permissions: {user_permissions.permissions if user_permissions else 'None'}")
            raise PermissionDenied("User does not have required permissions to access this resource.")

        return True


class MultipleScopePermissionCheck(BasePermission):

    def has_permission(self, request, view):
        workflow_ids = request.GET.getlist('workflow_id')
        session_id = request.COOKIES.get('sid')
        if not session_id:
            return False

        user_info = request.user
        if not user_info:
            return False

        auth_service = AuthorizationService(Config.AUTH_SERVICE_BASEURL)
        documents = Document.objects.filter(workflow_id__in=workflow_ids).iterator()
        scopes = {doc.scope for doc in documents}
        if len(scopes) == 0:
            return True

        async def get_permissions(scope_id):
            return await auth_service.get_auth_permissions_v2(
                session_id, "TAX_RECORD", scope_id, user_info.externalId
            )
        for scope in scopes:
            user_permissions = async_to_sync(get_permissions)(scope)
            if not user_permissions or not any(
                    per.name in [PermissionType.READ, PermissionType.WRITE] for per in user_permissions.permissions):
                raise PermissionDenied("User does not have required permissions to access this resource.")
        return True
