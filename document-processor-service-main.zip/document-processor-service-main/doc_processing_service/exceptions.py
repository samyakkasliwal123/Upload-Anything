class PasswordNeededException(Exception):
    pass


class PasswordIncorrectException(Exception):
    pass


class InvalidFileException(Exception):
    pass


class FileTooBigException(Exception):
    pass


class LLMClassificationFailed(Exception):
    pass
